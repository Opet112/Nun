package dev.zenith;

import dev.zenith.config.ConfigManager;
import dev.zenith.hud.HudRenderer;
import dev.zenith.module.Module;
import dev.zenith.module.ModuleManager;
import dev.zenith.module.impl.HudModule;
import dev.zenith.module.impl.Printer;
import dev.zenith.module.impl.Spammer;
import dev.zenith.module.impl.Xray;
import dev.zenith.util.KeyUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZenithClient implements ClientModInitializer {
    public static final String NAME = "Zenith";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);
    public static final String PREFIX = ".";

    private static final ModuleManager MODULES = new ModuleManager();
    private static final ConfigManager CONFIG = new ConfigManager();

    private static final Set<String> FRIENDS = new TreeSet<>();
    private static boolean silent;

    private static volatile long lastTickNanos = System.nanoTime();

    /** Progress (0..1) through the current game tick, for interpolating positions in the HUD. */
    public static float partial() {
        return (float) Math.max(0.0, Math.min(1.0, (System.nanoTime() - lastTickNanos) / 50_000_000.0));
    }

    public static Set<String> friends() { return FRIENDS; }
    public static ModuleManager modules() { return MODULES; }
    public static ConfigManager config() { return CONFIG; }

    @Override
    public void onInitializeClient() {
        MODULES.init();
        dev.zenith.hud.ZeusScreens.init();
        CONFIG.load();

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            lastTickNanos = System.nanoTime();
            MODULES.preTick();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> MODULES.tick());
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                dev.zenith.module.impl.AutoReconnect.remember(client.getCurrentServerEntry()));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            for (Module m : MODULES.all()) {
                try { m.onShutdown(); } catch (Throwable ignored) { }
            }
            CONFIG.save();
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("zenith", "hud"),
                (context, tickCounter) -> HudRenderer.render(context));

        // ".command" messages never reach the server.
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.startsWith(PREFIX)) return true;
            handleCommand(message.substring(PREFIX.length()).trim());
            return false;
        });

        LOGGER.info("{} {} loaded - press Right Shift in-game to open the ClickGUI", NAME, VERSION);
    }

    /** Called by Module.setEnabled; prints the "enabled/disabled" chat line. */
    public static void toggled(Module m) {
        if (silent) return;
        HudModule hud = MODULES.get(HudModule.class);
        if (hud != null && hud.toggleMessages.get() && m != hud) {
            info(m.name + (m.isEnabled() ? " §aenabled" : " §cdisabled"));
        }
    }

    public static void info(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("§b[Zenith] §f" + message), false);
    }

    private void handleCommand(String line) {
        String[] args = line.split("\\s+");
        if (args.length == 0 || args[0].isEmpty()) { help(); return; }
        switch (args[0].toLowerCase()) {
            case "help", "?" -> help();
            case "list", "modules" -> {
                StringBuilder sb = new StringBuilder();
                for (Module m : MODULES.all()) sb.append(m.isEnabled() ? "§a" : "§7").append(m.name).append("§f, ");
                info(sb.toString());
            }
            case "toggle", "t" -> {
                Module m = args.length > 1 ? MODULES.byName(args[1]) : null;
                if (m == null) { info("Usage: .toggle <module>"); return; }
                m.toggle();
                CONFIG.save();
            }
            case "bind" -> {
                Module m = args.length > 2 ? MODULES.byName(args[1]) : null;
                int key = args.length > 2 ? KeyUtil.parse(args[2]) : -2;
                if (m == null || key == -2) { info("Usage: .bind <module> <key|none>"); return; }
                m.setKey(key);
                info(m.name + " bound to " + KeyUtil.name(key));
                CONFIG.save();
            }
            case "panic" -> {
                silent = true;
                for (Module m : MODULES.all()) if (m.isEnabled() && !(m instanceof HudModule)) m.setEnabled(false);
                silent = false;
                info("All modules disabled.");
            }
            case "friend", "f" -> friendCommand(args);
            case "xray" -> {
                String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";
                String block = args.length > 2 ? args[2] : null;
                switch (sub) {
                    case "add" -> {
                        if (block == null) info("Usage: .xray add <block>   e.g. .xray add diamond_ore");
                        else if (Xray.addCustom(block)) { info("Added " + block + " (use Preset: Custom)"); CONFIG.save(); }
                        else info("Unknown block: " + block);
                    }
                    case "remove", "del" -> {
                        if (block == null) info("Usage: .xray remove <block>");
                        else if (Xray.removeCustom(block)) { info("Removed " + block); CONFIG.save(); }
                        else info("Not in your custom list: " + block);
                    }
                    default -> info("Xray custom blocks: " + (Xray.custom().isEmpty() ? "none" : String.join(", ", Xray.custom())));
                }
            }
            case "wp", "waypoint" -> {
                String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";
                String wname = args.length > 2 ? args[2] : null;
                switch (sub) {
                    case "add" -> {
                        if (wname == null) info("Usage: .wp add <name>");
                        else { dev.zenith.module.impl.Waypoints.add(wname); CONFIG.save(); info("Waypoint " + wname + " saved."); }
                    }
                    case "del", "remove" -> {
                        if (wname != null && dev.zenith.module.impl.Waypoints.remove(wname)) { CONFIG.save(); info("Removed " + wname); }
                        else info("Usage: .wp del <name>");
                    }
                    default -> {
                        StringBuilder sb = new StringBuilder();
                        for (var p : dev.zenith.module.impl.Waypoints.points()) sb.append(p.name).append(" (").append(Math.round(p.x)).append(' ').append(Math.round(p.y)).append(' ').append(Math.round(p.z)).append("), ");
                        info("Waypoints: " + (sb.length() == 0 ? "none" : sb));
                    }
                }
            }
            case "schem", "schematic" -> {
                Printer pr = MODULES.get(Printer.class);
                String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";
                switch (sub) {
                    case "load" -> {
                        String file = line.length() > args[0].length() + args[1].length() + 1 ? line.substring(args[0].length()).trim().substring(args[1].length()).trim() : "";
                        if (file.isEmpty()) info("Usage: .schem load <file>   (folder: " + Printer.folder() + ")");
                        else info(pr.load(file));
                    }
                    case "builtin", "b" -> {
                        String bn = args.length > 2 ? args[2] : null;
                        if (bn == null) {
                            for (var en : dev.zenith.util.BuiltinSchematics.INFO.entrySet()) info("§e" + en.getKey() + "§f - " + en.getValue());
                            info("Load one with .schem builtin <name>");
                        } else info(pr.load("builtin:" + bn));
                    }
                    case "here" -> info(pr.loaded() ? pr.anchorHere() : "Load a schematic first.");
                    case "start" -> { if (!pr.isEnabled()) pr.setEnabled(true); }
                    case "stop" -> { pr.setEnabled(false); info("Stopped. " + pr.status()); }
                    case "info" -> info(pr.status());
                    default -> {
                        java.util.List<String> f = Printer.files();
                        info("Schematics in " + Printer.folder() + ": " + (f.isEmpty() ? "none" : String.join(", ", f)));
                    }
                }
            }
            case "spammer" -> {
                String text = line.length() > args[0].length() ? line.substring(args[0].length()).trim() : "";
                if (text.isEmpty()) { info("Usage: .spammer <message>   (current: " + Spammer.message + ")"); return; }
                Spammer.message = text;
                info("Spammer message set.");
            }
            case "save" -> { CONFIG.save(); info("Config saved."); }
            case "load" -> { CONFIG.load(); info("Config loaded."); }
            default -> info("Unknown command. Try .help");
        }
    }

    private void friendCommand(String[] args) {
        String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";
        String name = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : null;
        switch (sub) {
            case "add" -> {
                if (name == null) { info("Usage: .friend add <name>"); return; }
                FRIENDS.add(name);
                CONFIG.save();
                info("Added friend " + name);
            }
            case "remove", "del" -> {
                if (name == null) { info("Usage: .friend remove <name>"); return; }
                FRIENDS.remove(name);
                CONFIG.save();
                info("Removed friend " + name);
            }
            default -> info("Friends: " + (FRIENDS.isEmpty() ? "none" : String.join(", ", FRIENDS)));
        }
    }

    private void help() {
        info("Commands: .list  .toggle <module>  .bind <module> <key|none>  .friend add|remove|list <name>");
        info(".panic (disable all)  .spammer <text>  .xray add|remove|list <block>  .wp add|del|list <name>  .schem list|builtin|load|here|start|stop|info  .save  .load");
        info("Right Shift opens the ClickGUI.");
    }
}
