package dev.zenith.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.zenith.ZenithClient;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("zenith.json");
    }

    // ---- named profiles (config/zenith/configs/<name>.json) ----
    public static Path profileDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("zenith").resolve("configs");
    }

    private static String clean(String name) {
        String n = name.trim().replaceAll("[^A-Za-z0-9 _.-]", "");
        return n.isEmpty() ? "config" : n;
    }

    public java.util.List<String> profiles() {
        java.util.List<String> out = new java.util.ArrayList<>();
        try {
            Files.createDirectories(profileDir());
            try (var st = Files.list(profileDir())) {
                st.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5)).sorted().forEach(out::add);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public String profileInfo(String name) {
        try {
            var t = Files.getLastModifiedTime(profileDir().resolve(clean(name) + ".json")).toInstant();
            return "saved " + java.time.LocalDateTime.ofInstant(t, java.time.ZoneId.systemDefault())
                    .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
        } catch (Exception e) { return ""; }
    }

    public void saveProfile(String name) { saveTo(profileDir().resolve(clean(name) + ".json")); }

    public boolean loadProfile(String name) {
        Path p = profileDir().resolve(clean(name) + ".json");
        if (!Files.exists(p)) return false;
        loadFrom(p);
        return true;
    }

    public void deleteProfile(String name) {
        try { Files.deleteIfExists(profileDir().resolve(clean(name) + ".json")); } catch (Exception ignored) { }
    }

    public void save() { saveTo(file()); }

    public void load() { loadFrom(file()); }

    private void saveTo(Path target) {
        try {
            Files.createDirectories(target.getParent());
            JsonObject root = new JsonObject();
            for (Module m : ZenithClient.modules().all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled() && m.persistEnabled());
                o.addProperty("key", m.getKey());
                JsonObject s = new JsonObject();
                for (Setting setting : m.getSettings()) s.add(setting.name, setting.toJson());
                o.add("settings", s);
                root.add(m.name, o);
            }
            JsonArray friends = new JsonArray();
            for (String f : ZenithClient.friends()) friends.add(f);
            root.add("_friends", friends);
            JsonArray xray = new JsonArray();
            for (String b : dev.zenith.module.impl.Xray.custom()) xray.add(b);
            root.add("_xray", xray);
            JsonArray wps = new JsonArray();
            for (String w : dev.zenith.module.impl.Waypoints.serialize()) wps.add(w);
            root.add("_waypoints", wps);
            Files.writeString(target, GSON.toJson(root));
        } catch (Exception e) {
            ZenithClient.LOGGER.error("Could not save config", e);
        }
    }

    private void loadFrom(Path file) {
        if (!Files.exists(file)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(file), JsonObject.class);
            if (root == null) return;
            if (root.has("_friends")) {
                ZenithClient.friends().clear();
                root.getAsJsonArray("_friends").forEach(e -> ZenithClient.friends().add(e.getAsString()));
            }
            if (root.has("_xray")) {
                java.util.List<String> ids = new java.util.ArrayList<>();
                root.getAsJsonArray("_xray").forEach(e -> ids.add(e.getAsString()));
                dev.zenith.module.impl.Xray.setCustom(ids);
            }
            if (root.has("_waypoints")) {
                java.util.List<String> wl = new java.util.ArrayList<>();
                root.getAsJsonArray("_waypoints").forEach(e -> wl.add(e.getAsString()));
                dev.zenith.module.impl.Waypoints.load(wl);
            }
            for (Module m : ZenithClient.modules().all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting setting : m.getSettings()) {
                        if (!s.has(setting.name)) continue;
                        try {
                            setting.fromJson(s.get(setting.name));
                        } catch (Exception ignored) {
                            // keep the default if the stored value is malformed
                        }
                    }
                }
                if (o.has("enabled") && m.persistEnabled()) m.setEnabledSilently(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) {
            ZenithClient.LOGGER.error("Could not load config", e);
        }
    }
}
