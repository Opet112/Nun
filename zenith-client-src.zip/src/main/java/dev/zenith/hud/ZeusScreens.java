package dev.zenith.hud;

import dev.zenith.ZenithClient;
import dev.zenith.gui.ClickGuiScreen;
import dev.zenith.util.GlassScene;
import dev.zenith.util.ZeusTheme;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.ReconfiguringScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;
import net.minecraft.client.gui.widget.ClickableWidget;

/** Painted storm scene behind the title and loading screens, gold frames on the title buttons. */
public final class ZeusScreens {
    private ZeusScreens() {}

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> titleOverlay(ctx, s));
            }
        });
    }

    private static boolean loading(Screen s) {
        return s instanceof ConnectScreen || s instanceof LevelLoadingScreen
                || s instanceof ReconfiguringScreen || s instanceof ProgressScreen;
    }

    /** Called from ScreenBackgroundMixin after the vanilla background, before the widgets are drawn. */
    public static void background(Screen s, DrawContext ctx) {
        var tr = MinecraftClient.getInstance().textRenderer;
        if (s instanceof TitleScreen) GlassScene.title(ctx, tr, s.width, s.height);
        else if (loading(s)) GlassScene.loading(ctx, tr, s.width, s.height);
    }

    private static void titleOverlay(DrawContext ctx, Screen s) {
        for (ClickableWidget b : Screens.getButtons(s)) {
            int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
            boolean hov = b.isHovered();
            int col = hov ? 0xFFB57EDC : GlassScene.INDIGO;
            int a = hov ? 0xE0 : 0x80;
            int c = (a << 24) | (col & 0xFFFFFF);
            ctx.fill(x + 2, y, x + w - 2, y + 1, c);
            ctx.fill(x + 2, y + h - 1, x + w - 2, y + h, c);
            ctx.fill(x, y + 2, x + 1, y + h - 2, c);
            ctx.fill(x + w - 1, y + 2, x + w, y + h - 2, c);
            ctx.fill(x + 1, y + 1, x + 2, y + 2, c);
            ctx.fill(x + w - 2, y + 1, x + w - 1, y + 2, c);
            ctx.fill(x + 1, y + h - 2, x + 2, y + h - 1, c);
            ctx.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, c);
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        String tag = ZenithClient.NAME + " Client " + ZenithClient.VERSION;
        ctx.drawText(mc.textRenderer, tag, s.width - mc.textRenderer.getWidth(tag) - 4, s.height - 12, 0xFF8E95A8, true);
    }

    /** Start-up loading screen (replaces the Mojang logo). */
    public static void splash(DrawContext ctx, int w, int h, float progress) {
        MinecraftClient mc = MinecraftClient.getInstance();
        GlassScene.background(ctx, w, h);
        GlassScene.wordmark(ctx, mc.textRenderer, w / 2, h * 36 / 100, 3.0f, "ZENITH");
        ctx.drawCenteredTextWithShadow(mc.textRenderer, "C L I E N T", w / 2, h * 36 / 100 + 32, 0xFF8E95A8);
        int bw = Math.min(240, w * 6 / 10);
        GlassScene.progress(ctx, mc.textRenderer, w / 2, h * 60 / 100, bw, progress, "Loading...");
    }
}
