package dev.zenith.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Base class for module settings. */
public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);

    /** On/off option. */
    public static class Bool extends Setting {
        private boolean value;

        public Bool(String name, boolean def) {
            super(name);
            this.value = def;
        }

        public boolean get() { return value; }
        public void set(boolean v) { value = v; }
        public void toggle() { value = !value; }

        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
    }

    /** Numeric slider. */
    public static class Num extends Setting {
        private double value;
        public final double min, max, step;

        public Num(String name, double def, double min, double max, double step) {
            super(name);
            this.value = def;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public double get() { return value; }
        public int getInt() { return (int) Math.round(value); }
        public float getFloat() { return (float) value; }

        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            if (step > 0) v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }

        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { set(e.getAsDouble()); }
    }

    /** One-of-many option. */
    public static class Mode extends Setting {
        public final String[] modes;
        private int index;

        public Mode(String name, String def, String... modes) {
            super(name);
            this.modes = modes;
            for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(def)) index = i;
        }

        public String get() { return modes[index]; }
        public int index() { return index; }
        public boolean is(String m) { return modes[index].equalsIgnoreCase(m); }
        public void cycle() { index = (index + 1) % modes.length; }

        @Override public JsonElement toJson() { return new JsonPrimitive(modes[index]); }
        @Override public void fromJson(JsonElement e) {
            String s = e.getAsString();
            for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(s)) index = i;
        }
    }

    /** A set of block ids chosen in the GUI (stored as "minecraft:diamond_ore" strings). */
    public static class BlockSet extends Setting {
        private final java.util.Set<String> ids = new java.util.TreeSet<>();
        private int version;

        public BlockSet(String name, String... defaults) {
            super(name);
            ids.addAll(java.util.Arrays.asList(defaults));
        }

        public java.util.Set<String> ids() { return java.util.Collections.unmodifiableSet(ids); }
        public int version() { return version; }
        public boolean has(String id) { return ids.contains(id); }
        public void toggle(String id) { if (!ids.remove(id)) ids.add(id); version++; }
        public void clear() { ids.clear(); version++; }

        @Override public JsonElement toJson() {
            com.google.gson.JsonArray a = new com.google.gson.JsonArray();
            for (String s : ids) a.add(s);
            return a;
        }

        @Override public void fromJson(JsonElement e) {
            ids.clear();
            if (e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) ids.add(x.getAsString());
            version++;
        }
    }
}
