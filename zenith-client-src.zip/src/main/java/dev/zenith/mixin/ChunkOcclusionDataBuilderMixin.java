package dev.zenith.mixin;

import dev.zenith.module.impl.Freecam;
import dev.zenith.module.impl.Xray;
import net.minecraft.client.render.chunk.ChunkOcclusionDataBuilder;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Without this, chunk sections that are "hidden" behind solid rock by the cave-culling graph never render. */
@Mixin(ChunkOcclusionDataBuilder.class)
public abstract class ChunkOcclusionDataBuilderMixin {
    @Inject(method = "markClosed", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$noCaveCulling(BlockPos pos, CallbackInfo ci) {
        if (Xray.active() || Freecam.active()) ci.cancel();
    }
}
