package dev.zenith.mixin;

import dev.zenith.hud.ZeusScreens;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {
    /** Paints the Zenith scene over the vanilla panorama/dirt background (title and loading screens only). */
    @Inject(method = "renderBackground", at = @At("TAIL"), require = 0)
    private void zenith$scene(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            ZeusScreens.background((Screen) (Object) this, context);
        } catch (Throwable ignored) { }
    }
}
