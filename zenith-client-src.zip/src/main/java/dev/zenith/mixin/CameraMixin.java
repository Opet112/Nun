package dev.zenith.mixin;

import dev.zenith.module.impl.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private boolean thirdPerson;

    @Shadow protected abstract void setPos(double x, double y, double z);

    @Shadow protected abstract void setRotation(float yaw, float pitch);

    /** Freecam: after vanilla placed the camera, move it to the free position. */
    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void zenith$freecam(CallbackInfo ci) {
        if (!Freecam.active()) return;
        float t = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
        setPos(Freecam.camX(t), Freecam.camY(t), Freecam.camZ(t));
        setRotation(Freecam.camYaw(), Freecam.camPitch());
        thirdPerson = true; // so your own player model is drawn
    }
}
