package dev.zenith.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Reads the real camera position (needed for third person, where it is not at the player's eyes). */
@Mixin(Camera.class)
public interface CameraAccessor {
    @Accessor("pos")
    Vec3d zenith$getPos();
}
