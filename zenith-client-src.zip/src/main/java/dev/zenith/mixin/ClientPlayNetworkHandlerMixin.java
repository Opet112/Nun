package dev.zenith.mixin;

import dev.zenith.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.CommandSuggestionsS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Velocity: remember the player's motion before the knockback packet is applied and scale the
 * difference afterwards. This avoids touching packet internals.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), require = 0)
    private void zenith$velBefore(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        var p = MinecraftClient.getInstance().player;
        if (p != null && packet.getEntityId() == p.getId()) Velocity.capture();
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("RETURN"), require = 0)
    private void zenith$velAfter(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        Velocity.apply();
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), require = 0)
    private void zenith$explosionBefore(ExplosionS2CPacket packet, CallbackInfo ci) {
        Velocity.capture();
    }

    @Inject(method = "onExplosion", at = @At("RETURN"), require = 0)
    private void zenith$explosionAfter(ExplosionS2CPacket packet, CallbackInfo ci) {
        Velocity.apply();
    }

    /**
     * StorageEsp: anti-ESP servers swap far chests for stone, but the chunk packet can still list the block entities.
     * Read them before the client discards them (a block entity on a stone block is dropped by the client).
     */
    @Inject(method = "onChunkData", at = @At("HEAD"), require = 0)
    private void zenith$chunkStorage(ChunkDataS2CPacket packet, CallbackInfo ci) {
        try {
            int cx = packet.getChunkX(), cz = packet.getChunkZ();
            packet.getChunkData().getBlockEntities(cx, cz).accept((pos, type, nbt) -> dev.zenith.module.impl.StorageEsp.packetSeen(pos, type));
        } catch (Throwable ignored) { }
    }

    @Inject(method = "onBlockEntityUpdate", at = @At("HEAD"), require = 0)
    private void zenith$beStorage(BlockEntityUpdateS2CPacket packet, CallbackInfo ci) {
        try { dev.zenith.module.impl.StorageEsp.packetSeen(packet.getPos(), packet.getBlockEntityType()); }
        catch (Throwable ignored) { }
    }

    /** Chest/barrel/shulker open-close animations reveal the exact position even when the chunk data is scrubbed. */
    @Inject(method = "onBlockEvent", at = @At("HEAD"), require = 0)
    private void zenith$blockEventStorage(BlockEventS2CPacket packet, CallbackInfo ci) {
        try { dev.zenith.module.impl.StorageEsp.blockEventSeen(packet.getPos(), packet.getBlock()); }
        catch (Throwable ignored) { }
    }

    /** PopCounter: status 35 is "totem used". */
    @Inject(method = "onEntityStatus", at = @At("HEAD"), require = 0)
    private void zenith$totemPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
        try {
            if (packet.getStatus() != 35) return;
            net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc.world != null) dev.zenith.module.impl.PopCounter.popped(packet.getEntity(mc.world));
        } catch (Throwable ignored) { }
    }

    /** Answers to ProbeCenter requests (the server resyncs a refused block action with the true state). */
    @Inject(method = "onBlockUpdate", at = @At("HEAD"), require = 0)
    private void zenith$probeAnswer(BlockUpdateS2CPacket packet, CallbackInfo ci) {
        try { dev.zenith.util.ProbeCenter.answered(packet.getPos(), packet.getState()); }
        catch (Throwable ignored) { }
    }

    /** AntiVanish name probe: completion replies list hidden players too. */
    @Inject(method = "onCommandSuggestions", at = @At("HEAD"), require = 0)
    private void zenith$suggestions(CommandSuggestionsS2CPacket packet, CallbackInfo ci) {
        try {
            java.util.List<String> names = new java.util.ArrayList<>();
            for (var sug : packet.getSuggestions().getList()) names.add(sug.getText());
            dev.zenith.module.impl.AntiVanish.suggestions(names);
        } catch (Throwable ignored) { }
    }

    /** AntiVanish sensors: sounds, particles, tab removals and chat lines that no visible player explains. */
    @Inject(method = "onPlaySound", at = @At("HEAD"), require = 0)
    private void zenith$vanishSound(net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket packet, CallbackInfo ci) {
        try { dev.zenith.module.impl.AntiVanish.sound(packet.getSound().getIdAsString(), packet.getX(), packet.getY(), packet.getZ()); }
        catch (Throwable ignored) { }
    }

    @Inject(method = "onParticle", at = @At("HEAD"), require = 0)
    private void zenith$vanishParticle(net.minecraft.network.packet.s2c.play.ParticleS2CPacket packet, CallbackInfo ci) {
        try {
            var id = net.minecraft.registry.Registries.PARTICLE_TYPE.getId(packet.getParameters().getType());
            if (id != null) dev.zenith.module.impl.AntiVanish.particle(id.getPath(), packet.getX(), packet.getY(), packet.getZ());
        } catch (Throwable ignored) { }
    }

    @Inject(method = "onPlayerRemove", at = @At("HEAD"), require = 0)
    private void zenith$vanishTab(net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket packet, CallbackInfo ci) {
        try {
            // record accessor names are not stable across mappings: take the only no-arg method that returns a List
            for (java.lang.reflect.Method m : packet.getClass().getDeclaredMethods()) {
                if (m.getParameterCount() != 0 || !java.util.List.class.isAssignableFrom(m.getReturnType())) continue;
                m.setAccessible(true);
                for (Object o : (java.util.List<?>) m.invoke(packet)) {
                    if (!(o instanceof java.util.UUID id)) continue;
                    var en = ((ClientPlayNetworkHandler) (Object) this).getPlayerListEntry(id);
                    dev.zenith.module.impl.AntiVanish.tabRemoved(id, en == null ? null : en.getProfile());
                }
                break;
            }
        } catch (Throwable ignored) { }
    }

    @Inject(method = "onGameMessage", at = @At("HEAD"), require = 0)
    private void zenith$vanishChat(net.minecraft.network.packet.s2c.play.GameMessageS2CPacket packet, CallbackInfo ci) {
        try {
            for (java.lang.reflect.Method m : packet.getClass().getDeclaredMethods()) {
                if (m.getParameterCount() != 0 || !net.minecraft.text.Text.class.isAssignableFrom(m.getReturnType())) continue;
                m.setAccessible(true);
                dev.zenith.module.impl.AntiVanish.chat(((net.minecraft.text.Text) m.invoke(packet)).getString());
                break;
            }
        }
        catch (Throwable ignored) { }
    }
}
