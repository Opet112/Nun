package dev.zenith.mixin;

import dev.zenith.module.impl.Xray;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockShouldDrawMixin {
    /** Xray: whitelisted blocks always draw every face, all other blocks draw none. Runs on chunk-builder threads. */
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true, require = 0)
    private static void zenith$xray(BlockState state, BlockState sideState, Direction side, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.active()) cir.setReturnValue(Xray.shouldDraw(state));
    }
}
