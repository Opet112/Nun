package dev.zenith.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int zenith$getItemUseCooldown();

    @Accessor("itemUseCooldown")
    void zenith$setItemUseCooldown(int value);
}
