package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoReplenish extends Module {
    private final Setting.Num threshold = add(new Setting.Num("Refill at", 8, 1, 32, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 4, 1, 20, 1));
    private final Setting.Bool swapTools = add(new Setting.Bool("Swap breaking tools", true));
    private final Setting.Num toolLeft = add(new Setting.Num("Tool uses left", 8, 1, 50, 1));
    private int wait;

    public AutoReplenish() {
        super("AutoReplenish", "Refills low hotbar stacks from your inventory.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;
        if (swapTools.get() && swapTool(p)) { wait = delay.getInt(); return; }
        for (int h = 0; h < 9; h++) {
            ItemStack s = p.getInventory().getStack(h);
            if (s.isEmpty() || s.getMaxCount() <= 1 || s.getCount() > threshold.getInt()) continue;
            for (int i = 9; i < 36; i++) {
                ItemStack other = p.getInventory().getStack(i);
                if (!other.isEmpty() && other.isOf(s.getItem())) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                    wait = delay.getInt();
                    return;
                }
            }
        }
    }

    /** Replaces the tool in your hand with a healthier copy of the same item before it breaks. */
    private boolean swapTool(net.minecraft.client.network.ClientPlayerEntity p) {
        int h = p.getInventory().getSelectedSlot();
        ItemStack held = p.getInventory().getStack(h);
        if (held.isEmpty() || !held.isDamageable() || held.getMaxDamage() - held.getDamage() > toolLeft.getInt()) return false;
        for (int i = 9; i < 36; i++) {
            ItemStack other = p.getInventory().getStack(i);
            if (other.isOf(held.getItem()) && other.getMaxDamage() - other.getDamage() > toolLeft.getInt() * 2) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, h, SlotActionType.SWAP, p);
                return true;
            }
        }
        return false;
    }
}
