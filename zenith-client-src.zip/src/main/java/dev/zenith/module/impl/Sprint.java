package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.entity.effect.StatusEffects;

public class Sprint extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Legit", "Legit", "Omni"));
    private final Setting.Bool whileUsing = add(new Setting.Bool("While using item", false));

    public Sprint() {
        super("Sprint", "Sprints automatically. Omni also sprints sideways/backwards (stricter anti-cheats may flag it).", Category.MOVEMENT);
    }

    @Override
    public String getSuffix() { return mode.get(); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean fwd = mc.options.forwardKey.isPressed();
        boolean any = fwd || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        boolean want = mode.is("Omni") ? any : fwd;
        if (!want || p.isSneaking() || p.horizontalCollision || p.isTouchingWater()
                || p.hasStatusEffect(StatusEffects.BLINDNESS)
                || (!whileUsing.get() && p.isUsingItem())
                || p.getHungerManager().getFoodLevel() <= 6) return;
        p.setSprinting(true);
    }
}
