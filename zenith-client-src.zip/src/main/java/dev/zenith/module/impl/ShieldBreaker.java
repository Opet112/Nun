package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** Swaps to an axe and hits when the player under your crosshair is blocking with a shield. */
public class ShieldBreaker extends Module {
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));

    public ShieldBreaker() {
        super("ShieldBreaker", "Axes a blocking player's shield: swaps to an axe and attacks.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!(mc.targetedEntity instanceof PlayerEntity t) || !t.isBlocking() || EntityUtil.isFriend(t)) return;
        int axe = InventoryUtil.findHotbar(st -> net.minecraft.registry.Registries.ITEM.getId(st.getItem()).getPath().endsWith("_axe"));
        if (axe < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        InventoryUtil.select(axe);
        if (p.getAttackCooldownProgress(0.5f) >= 0.95f) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            if (switchBack.get()) InventoryUtil.select(prev);
        }
    }
}
