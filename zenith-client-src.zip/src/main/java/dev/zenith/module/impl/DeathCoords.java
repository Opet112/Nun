package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.DeathScreen;

public class DeathCoords extends Module {
    private final Setting.Bool waypoint = add(new Setting.Bool("Add waypoint", true));
    private boolean reported;

    public DeathCoords() {
        super("DeathCoords", "Prints the coordinates where you died.", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (mc.currentScreen instanceof DeathScreen) {
            if (!reported) {
                reported = true;
                if (waypoint.get()) Waypoints.add("death");
                ZenithClient.info("You died at §e" + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ()
                        + " §7(" + mc.world.getRegistryKey().getValue().getPath() + ")");
            }
        } else {
            reported = false;
        }
    }
}
