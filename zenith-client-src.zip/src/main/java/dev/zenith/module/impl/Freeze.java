package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class Freeze extends Module {
    private final Setting.Bool offOnHurt = add(new Setting.Bool("Disable on damage", true));

    public Freeze() {
        super("Freeze", "Holds you in mid-air (client-side).", Category.MISC);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (offOnHurt.get() && mc.player.hurtTime > 0) { setEnabled(false); return; }
        mc.player.setVelocity(Vec3d.ZERO);
    }
}
