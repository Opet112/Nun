package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Name, health, distance and ping above players, plus left hand | armor | right hand with durability. Visible through walls. */
public class NameTags extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 128, 8, 256, 8));
    private final Setting.Bool health = add(new Setting.Bool("Health", true));
    private final Setting.Bool distance = add(new Setting.Bool("Distance", true));
    private final Setting.Bool ping = add(new Setting.Bool("Ping", false));
    private final Setting.Bool items = add(new Setting.Bool("Items & armor", true));
    private final Setting.Bool durability = add(new Setting.Bool("Durability", true));
    private final Setting.Bool enchants = add(new Setting.Bool("Enchant count", true));
    private final Setting.Bool sneakTag = add(new Setting.Bool("Sneak marker", true));
    private final Setting.Bool sortFar = add(new Setting.Bool("Far first", true));

    public NameTags() {
        super("NameTags", "Name, armor and both hand items above players (visible through walls).", Category.RENDER);
    }

    private static int healthColor(float hp) {
        if (hp > 14) return 0xFF2FD27E;
        if (hp > 7) return 0xFFFFB347;
        return 0xFFE8344F;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        TextRenderer tr = mc.textRenderer;
        List<PlayerEntity> players = new ArrayList<>(mc.world.getPlayers());
        if (sortFar.get()) players.sort((a, b) -> Float.compare(mc.player.distanceTo(b), mc.player.distanceTo(a)));
        for (PlayerEntity e : players) {
            if (e == mc.player || mc.player.distanceTo(e) > range.get()) continue;
            Vec3d head = e.getLerpedPos(partial).add(0, e.getHeight() + 0.35, 0);
            double[] s = pr.project(head);
            if (s == null) continue;

            String name = (sneakTag.get() && e.isSneaking() ? "[S] " : "") + e.getName().getString();
            float hp = e.getHealth() + e.getAbsorptionAmount();
            String hpText = health.get() ? " " + (int) Math.ceil(hp) : "";
            String extra = "";
            if (distance.get()) extra += " " + (int) mc.player.distanceTo(e) + "m";
            if (ping.get() && mc.getNetworkHandler() != null) {
                var entry = mc.getNetworkHandler().getPlayerListEntry(e.getUuid());
                if (entry != null) extra += " " + entry.getLatency() + "ms";
            }
            int nameW = tr.getWidth(name), hpW = tr.getWidth(hpText), exW = tr.getWidth(extra);
            int total = nameW + hpW + exW;
            int cx = (int) s[0];
            int y = (int) s[1] - 12;

            // item row: left hand, helmet..boots, right hand
            List<ItemStack> row = new ArrayList<>();
            if (items.get()) {
                boolean rightMain = e.getMainArm() == Arm.RIGHT;
                row.add(rightMain ? e.getOffHandStack() : e.getMainHandStack());
                row.add(e.getEquippedStack(EquipmentSlot.HEAD));
                row.add(e.getEquippedStack(EquipmentSlot.CHEST));
                row.add(e.getEquippedStack(EquipmentSlot.LEGS));
                row.add(e.getEquippedStack(EquipmentSlot.FEET));
                row.add(rightMain ? e.getMainHandStack() : e.getOffHandStack());
            }

            int x = cx - total / 2;
            ctx.fill(x - 3, y - 1, x + total + 3, y + 10, 0xA0101216);
            ctx.fill(x - 3, y + 9, x + total + 3, y + 10, EntityUtil.isFriend(e) ? 0xFF35D6E8 : ColorUtil.accent(0));
            ctx.drawText(tr, name, x, y + 1, EntityUtil.isFriend(e) ? 0xFF35D6E8 : ColorUtil.TEXT, true);
            if (!hpText.isEmpty()) ctx.drawText(tr, hpText, x + nameW, y + 1, healthColor(hp), true);
            if (!extra.isEmpty()) ctx.drawText(tr, extra, x + nameW + hpW, y + 1, ColorUtil.TEXT_DIM, true);

            if (!row.isEmpty()) {
                int slotW = 17;
                int rx = cx - (row.size() * slotW) / 2;
                int ry = y - 19;
                for (ItemStack st : row) {
                    if (!st.isEmpty()) {
                        ctx.fill(rx, ry, rx + slotW - 1, ry + 17, 0x70101216);
                        ctx.drawItem(st, rx, ry);
                        if (st.getCount() > 1) ctx.drawStackOverlay(tr, st, rx, ry);
                        if (enchants.get() && st.hasEnchantments()) {
                            String n = String.valueOf(st.getEnchantments().getSize());
                            ctx.drawText(tr, n, rx + 1, ry - 8, 0xFFB57EDC, true);
                        }
                        if (durability.get() && st.isDamageable()) {
                            float left = 1f - st.getDamage() / (float) Math.max(1, st.getMaxDamage());
                            ctx.fill(rx, ry + 15, rx + slotW - 1, ry + 17, 0xFF1B1F27);
                            ctx.fill(rx, ry + 15, rx + (int) ((slotW - 1) * left), ry + 17, healthColor(left * 20f));
                        }
                    }
                    rx += slotW;
                }
            }
        }
    }
}
