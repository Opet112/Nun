package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** While drawing a bow, aims at the nearest player with lead and arrow drop compensation. */
public class BowAimbot extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 50, 10, 100, 5));
    private final Setting.Num speed = add(new Setting.Num("Turn speed", 40, 5, 90, 5));
    private final Setting.Bool visibleOnly = add(new Setting.Bool("Only visible targets", true));
    private final Setting.Bool lead = add(new Setting.Bool("Predict movement", true));
    private final Map<UUID, Vec3d> last = new HashMap<>();

    public BowAimbot() {
        super("BowAimbot", "Aims drawn arrows at the nearest player, compensating for drop and movement.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        Map<UUID, Vec3d> now = new HashMap<>();
        for (PlayerEntity e : mc.world.getPlayers()) now.put(e.getUuid(), e.getPos());
        Map<UUID, Vec3d> prev = new HashMap<>(last);
        last.clear();
        last.putAll(now);

        if (!p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return;
        PlayerEntity t = EntityUtil.nearestPlayer(range.get());
        if (t == null || (visibleOnly.get() && !p.canSee(t))) return;
        double charge = Math.min(20, p.getItemUseTime()) / 20.0;
        double v = Math.max(0.6, (charge * charge + charge * 2.0) / 3.0 * 3.0); // arrow speed in blocks/tick
        Vec3d aim = t.getPos().add(0, t.getHeight() * 0.7, 0);
        double dist = p.getEyePos().distanceTo(aim);
        double ticks = dist / v;
        if (lead.get() && prev.containsKey(t.getUuid())) {
            Vec3d vel = now.get(t.getUuid()).subtract(prev.get(t.getUuid()));
            aim = aim.add(vel.x * ticks, 0, vel.z * ticks);
        }
        aim = aim.add(0, 0.5 * 0.05 * ticks * ticks, 0); // gravity drop: aim above the target
        float[] r = EntityUtil.rotationsTo(p, aim);
        RotationManager.request(p, r[0], r[1], (float) speed.get(), true);
    }
}
