package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Module {
    private final dev.zenith.setting.Setting.Num delay = add(new dev.zenith.setting.Setting.Num("Delay (ticks)", 20, 0, 100, 5));
    private int timer;

    public AutoRespawn() {
        super("AutoRespawn", "Respawns immediately after dying.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) {
            if (++timer >= delay.getInt()) { timer = 0; mc.player.requestRespawn(); }
        } else {
            timer = 0;
        }
    }
}
