package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class AutoJump extends Module {
    private final Setting.Bool sprintOnly = add(new Setting.Bool("Only while sprinting", false));

    public AutoJump() {
        super("AutoJump", "Jumps constantly while you move.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null || p.isSneaking() || p.isTouchingWater()) return;
        if (sprintOnly.get() && !p.isSprinting()) return;
        if (p.isOnGround() && EntityUtil.isMoving()) p.jump();
    }
}
