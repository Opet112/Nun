package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.hit.EntityHitResult;

public class WTap extends Module {
    private final Setting.Num chance = add(new Setting.Num("Chance %", 100, 10, 100, 5));
    private boolean attackWas;
    private int resprint;

    public WTap() {
        super("WTap", "Resets your sprint on every hit for extra knockback.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        // after dropping the sprint, pick it up again a moment later so the next hit lands with fresh knockback
        if (resprint > 0 && --resprint == 0 && mc.options.forwardKey.isPressed() && !p.isSneaking()) p.setSprinting(true);
        boolean attack = mc.options.attackKey.isPressed();
        if (attack && !attackWas && p.isSprinting() && mc.crosshairTarget instanceof EntityHitResult
                && Math.random() * 100 < chance.get()) {
            p.setSprinting(false);
            resprint = 2;
        }
        attackWas = attack;
    }
}
