package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

/** Drops cobwebs on the nearest player's feet (and head) to slow them down. */
public class AutoWeb extends Module {
    private final Setting.Num range = add(new Setting.Num("Target range", 4.5, 2, 6, 0.5));
    private final Setting.Bool head = add(new Setting.Bool("Head too", true));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 12, 1, 80, 1));
    private final Setting.Num jitter = add(new Setting.Num("Random extra (ticks)", 5, 0, 30, 1));
    private int wait;
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));

    public AutoWeb() {
        super("AutoWeb", "Places cobwebs on nearby players.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;
        PlayerEntity target = EntityUtil.nearestPlayer(range.get());
        if (target == null) return;
        int slot = InventoryUtil.findHotbar(Items.COBWEB);
        if (slot < 0) return;

        BlockPos feet = target.getBlockPos();
        BlockPos[] spots = head.get() ? new BlockPos[]{feet, new BlockPos(feet.getX(), feet.getY() + 1, feet.getZ())} : new BlockPos[]{feet};
        int previous = p.getInventory().getSelectedSlot();
        for (BlockPos pos : spots) {
            if (!BlockUtil.canPlaceAt(pos) || !BlockUtil.hasSupport(pos)) continue;
            if (p.getEyePos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 20.0) continue;
            InventoryUtil.select(slot);
            if (BlockUtil.place(pos, Hand.MAIN_HAND, true)) {
                if (switchBack.get()) InventoryUtil.select(previous);
                wait = delay.getInt() + (jitter.getInt() > 0 ? java.util.concurrent.ThreadLocalRandom.current().nextInt(jitter.getInt() + 1) : 0);
                return; // one web per tick keeps it quiet
            }
        }
    }
}
