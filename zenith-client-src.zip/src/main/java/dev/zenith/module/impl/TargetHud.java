package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

public class TargetHud extends Module {
    private LivingEntity target;
    private long lastSeen;
    private float shownHp = -1f;
    private LivingEntity shownFor;

    public TargetHud() {
        super("TargetHUD", "Shows the health of the entity you are looking at.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le && le.isAlive()) {
            target = le;
            lastSeen = System.currentTimeMillis();
        }
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (target == null || !target.isAlive() || System.currentTimeMillis() - lastSeen > 2500) return;
        var tr = mc.textRenderer;
        if (shownFor != target) { shownFor = target; shownHp = target.getHealth(); }
        shownHp += (target.getHealth() - shownHp) * 0.15f; // smooth, animated health bar
        int w = 130, h = 38;
        int x = mc.getWindow().getScaledWidth() / 2 + 14;
        int y = mc.getWindow().getScaledHeight() / 2 + 14;
        int accent = ColorUtil.accent(2);
        ctx.fill(x, y, x + w, y + h, 0xA0101216);
        ctx.fill(x, y, x + 2, y + h, accent);
        ctx.drawText(tr, target.getName().getString(), x + 7, y + 4, ColorUtil.TEXT, true);

        float hp = target.getHealth(), max = Math.max(1f, target.getMaxHealth());
        float frac = Math.max(0f, Math.min(1f, hp / max));
        float shownFrac = Math.max(0f, Math.min(1f, shownHp / max));
        int bar = w - 14;
        int color = frac > 0.6f ? 0xFF2FD27E : frac > 0.3f ? 0xFFFFB347 : 0xFFE8344F;
        ctx.fill(x + 7, y + 17, x + 7 + bar, y + 22, 0xFF2A2F3A);
        ctx.fill(x + 7, y + 17, x + 7 + (int) (bar * shownFrac), y + 22, 0xFFFFFFFF & 0x80FFFFFF);   // lagging "damage" trail
        ctx.fill(x + 7, y + 17, x + 7 + (int) (bar * frac), y + 22, color);
        float abs = target.getAbsorptionAmount();
        if (abs > 0) ctx.fill(x + 7, y + 22, x + 7 + (int) (bar * Math.min(1f, abs / max)), y + 24, 0xFFFFD84A);
        String info = String.format("%.1f", hp) + (abs > 0 ? " +" + (int) abs : "") + "   armor " + target.getArmor()
                + "   " + (int) mc.player.distanceTo(target) + "m";
        ctx.drawText(tr, info, x + 7, y + 27, ColorUtil.TEXT_DIM, true);
    }
}
