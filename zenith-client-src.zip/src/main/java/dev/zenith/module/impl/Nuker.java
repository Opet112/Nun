package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.RotationManager;
import dev.zenith.util.EntityUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Mines blocks around you one at a time (everything, or only ores). Pair it with AutoTool. */
public class Nuker extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Blocks", "Ores", "All", "Ores", "Valuable"));
    private final Setting.Num range = add(new Setting.Num("Range", 4, 1, 5, 0.5));
    private final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    private final Setting.Bool onlyExposed = add(new Setting.Bool("Only visible blocks", true));
    private final Setting.Bool avoidFluids = add(new Setting.Bool("Avoid lava/water", true));
    private final Setting.Bool stopFull = add(new Setting.Bool("Stop when inventory full", true));
    private BlockPos current;

    public Nuker() {
        super("Nuker", "Automatically mines nearby blocks.", Category.PLAYER);
    }

    @Override
    protected void onDisable() { current = null; }

    private boolean wanted(BlockState st) {
        if (st.isAir() || st.getBlock() == Blocks.BEDROCK || !st.getFluidState().isEmpty()) return false;
        if (mode.is("All")) return true;
        String id = Registries.BLOCK.getId(st.getBlock()).getPath();
        if (mode.is("Valuable")) return id.contains("diamond") || id.contains("emerald") || id.equals("ancient_debris");
        return id.endsWith("_ore") || id.equals("ancient_debris");
    }

    private boolean exposed(BlockPos pos) {
        for (Direction d : Direction.values()) if (mc.world.getBlockState(pos.offset(d)).isReplaceable()) return true;
        return false;
    }

    /** True when mining this block would release lava or water (it touches a fluid). */
    private boolean touchesFluid(BlockPos pos) {
        for (Direction d : Direction.values()) if (!mc.world.getBlockState(pos.offset(d)).getFluidState().isEmpty()) return true;
        return false;
    }

    private boolean inventoryFull() {
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) return false;
        return true;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (stopFull.get() && inventoryFull()) return;
        double r = range.get();
        Vec3d eye = p.getEyePos();

        if (current != null) {
            BlockState st = mc.world.getBlockState(current);
            if (!wanted(st) || eye.squaredDistanceTo(current.getX() + 0.5, current.getY() + 0.5, current.getZ() + 0.5) > (r + 0.5) * (r + 0.5)) current = null;
        }
        if (current == null) {
            int ri = (int) Math.ceil(r);
            int px = (int) Math.floor(p.getX()), py = (int) Math.floor(p.getY()), pz = (int) Math.floor(p.getZ());
            double best = Double.MAX_VALUE;
            for (int x = -ri; x <= ri; x++) for (int y = -ri; y <= ri; y++) for (int z = -ri; z <= ri; z++) {
                BlockPos pos = new BlockPos(px + x, py + y, pz + z);
                double d = eye.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                if (d > r * r || d >= best) continue;
                if (!wanted(mc.world.getBlockState(pos))) continue;
                if (onlyExposed.get() && !exposed(pos)) continue;
                if (avoidFluids.get() && touchesFluid(pos)) continue;
                best = d;
                current = pos;
            }
        }
        if (current == null) return;

        Vec3d center = Vec3d.ofCenter(current);
        if (rotate.get()) {
            float[] want = EntityUtil.rotationsTo(p, center);
            RotationManager.request(p, want[0], want[1], 60f, true);
        }
        Vec3d d = center.subtract(eye);
        Direction face = Direction.getFacing(-d.x, -d.y, -d.z);
        mc.interactionManager.updateBlockBreakingProgress(current, face);
        p.swingHand(Hand.MAIN_HAND);
    }
}
