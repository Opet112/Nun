package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.gui.DrawContext;

/** Pulsing red edges on screen while your health is low. */
public class LowHealthWarning extends Module {
    private final Setting.Num threshold = add(new Setting.Num("Health", 8, 2, 20, 1));

    public LowHealthWarning() {
        super("LowHealthWarning", "Red screen edges when health is low.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.player == null || mc.player.getHealth() > threshold.get()) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int a = 40 + (int) (50 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 220.0)));
        int edge = (a << 24) | 0xFF0000, none = 0x00FF0000;
        int t = Math.max(24, h / 6);
        ctx.fillGradient(0, 0, w, t, edge, none);
        ctx.fillGradient(0, h - t, w, h, none, edge);
    }
}
