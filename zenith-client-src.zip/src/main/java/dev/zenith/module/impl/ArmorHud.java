package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    private static final EquipmentSlot[] ORDER = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public ArmorHud() {
        super("ArmorHUD", "Shows your armor and durability next to the hotbar.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        var p = mc.player;
        if (p == null) return;
        int x = mc.getWindow().getScaledWidth() / 2 + 96;
        int y = mc.getWindow().getScaledHeight() - 20;
        for (EquipmentSlot slot : ORDER) {
            ItemStack stack = p.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                ctx.drawItem(stack, x, y);
                ctx.drawStackOverlay(mc.textRenderer, stack, x, y);
                if (stack.isDamageable() && stack.getMaxDamage() > 0) {
                    int pct = 100 * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage();
                    String t = pct + "%";
                    int c = pct > 60 ? 0xFF6FE39A : pct > 30 ? 0xFFFFB347 : 0xFFFF6B6B;
                    ctx.drawText(mc.textRenderer, t, x + 8 - mc.textRenderer.getWidth(t) / 2, y - 10, c, true);
                }
            }
            x += 18;
        }
    }
}
