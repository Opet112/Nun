package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Named positions drawn on the HUD with their distance. Manage them with .wp add|del|list. */
public class Waypoints extends Module {
    public static final class Point {
        public final String name, dim;
        public final double x, y, z;
        public Point(String name, String dim, double x, double y, double z) {
            this.name = name; this.dim = dim; this.x = x; this.y = y; this.z = z;
        }
    }

    private static final List<Point> POINTS = new ArrayList<>();

    private final Setting.Num minDist = add(new Setting.Num("Hide closer than", 3, 0, 50, 1));
    private final Setting.Bool beam = add(new Setting.Bool("Beam", true));
    private final Setting.Num maxDist = add(new Setting.Num("Max distance", 5000, 100, 100000, 100));

    public Waypoints() {
        super("Waypoints", "Shows saved positions on screen (.wp add <name>).", Category.RENDER);
    }

    public static List<Point> points() { return POINTS; }

    public static String dimension() {
        return mc.world == null ? "" : mc.world.getRegistryKey().getValue().toString();
    }

    public static void add(String name) {
        if (mc.player == null) return;
        remove(name);
        POINTS.add(new Point(name, dimension(), mc.player.getX(), mc.player.getY(), mc.player.getZ()));
    }

    public static boolean remove(String name) {
        return POINTS.removeIf(p -> p.name.equalsIgnoreCase(name));
    }

    /** "name|dim|x|y|z" lines for the config file. */
    public static List<String> serialize() {
        List<String> out = new ArrayList<>();
        for (Point p : POINTS) out.add(p.name + "|" + p.dim + "|" + p.x + "|" + p.y + "|" + p.z);
        return out;
    }

    public static void load(List<String> lines) {
        POINTS.clear();
        for (String l : lines) {
            try {
                String[] a = l.split("\\|");
                POINTS.add(new Point(a[0], a[1], Double.parseDouble(a[2]), Double.parseDouble(a[3]), Double.parseDouble(a[4])));
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null || POINTS.isEmpty()) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        String dim = dimension();
        for (Point p : POINTS) {
            if (!p.dim.equals(dim)) continue;
            double dx = p.x - mc.player.getX(), dy = p.y - mc.player.getY(), dz = p.z - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > maxDist.get() || dist < minDist.get()) continue;
            double[] s = pr.project(new Vec3d(p.x, p.y + 1.0, p.z));
            if (s == null) continue;
            int col = java.awt.Color.HSBtoRGB(((p.name.hashCode() & 0x7FFFFFFF) % 360) / 360f, 0.55f, 1f) | 0xFF000000;
            if (beam.get()) {
                double[] top = pr.project(new Vec3d(p.x, p.y + 60.0, p.z));
                double[] bot = pr.project(new Vec3d(p.x, p.y, p.z));
                if (top != null && bot != null) dev.zenith.util.DrawUtil.line(ctx, bot[0], bot[1], top[0], top[1], dev.zenith.util.ColorUtil.withAlpha(col, 110), pr.width, pr.height);
            }
            ctx.fill((int) s[0] - 2, (int) s[1] - 6, (int) s[0] + 3, (int) s[1] - 1, col); // marker
            String text = p.name + " " + Math.round(dist) + "m";
            int w = mc.textRenderer.getWidth(text);
            int x = (int) s[0] - w / 2, y = (int) s[1];
            ctx.fill(x - 2, y - 2, x + w + 2, y + 10, 0x90101216);
            ctx.drawText(mc.textRenderer, text, x, y, col, true);
        }
    }
}
