package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.KeyUtil;
import dev.zenith.util.RotationManager;
import dev.zenith.util.EntityUtil;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Legit-style bridging: crouches before every block, looks at the face it places against (the server-side
 * rotation turns in human-sized steps and has to be on target first), aims at a slightly different spot on the
 * face each time and waits a random number of ticks between blocks.
 */
public class Scaffold extends Module {
    private final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    private final Setting.Bool sneak = add(new Setting.Bool("Sneak on place", true));
    private final Setting.Bool swing = add(new Setting.Bool("Swing", true));
    private final Setting.Num minDelay = add(new Setting.Num("Min delay (ticks)", 1, 0, 10, 1));
    private final Setting.Num maxDelay = add(new Setting.Num("Max delay (ticks)", 3, 0, 10, 1));
    private final Setting.Num turnSpeed = add(new Setting.Num("Turn speed", 45, 10, 120, 5));

    private final Setting.Bool restore = add(new Setting.Bool("Restore slot", true));
    private final Setting.Bool safeBlocks = add(new Setting.Bool("Solid blocks only", true));
    private int previousSlot = -1;

    private final Random rnd = new Random();
    private int wait;
    private int sneakHold;
    private boolean forcedSneak;

    public Scaffold() {
        super("Scaffold", "Legit bridging: crouches, looks at the block and places with human-like timing.", Category.MISC);
    }

    @Override
    protected void onEnable() { wait = 0; sneakHold = 0; }

    @Override
    protected void onDisable() {
        sneakHold = 0;
        releaseSneak();
        if (restore.get() && previousSlot >= 0 && mc.player != null) InventoryUtil.select(previousSlot);
        previousSlot = -1;
    }

    private boolean usable(ItemStack st) {
        if (!(st.getItem() instanceof BlockItem bi)) return false;
        if (!safeBlocks.get()) return true;
        var b = bi.getBlock();
        return !(b instanceof FallingBlock) && !(b instanceof BlockWithEntity) && b.getDefaultState().isOpaque();
    }

    /** Hotbar slot of the usable block stack with the most items, or -1. */
    private int bestSlot() {
        int best = -1, count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (usable(st) && st.getCount() > count) { count = st.getCount(); best = i; }
        }
        return best;
    }

    private void releaseSneak() {
        if (forcedSneak) {
            mc.options.sneakKey.setPressed(KeyUtil.isDown(mc.options.sneakKey));
            forcedSneak = false;
        }
    }

    /** Runs before vanilla reads the keys, so the crouch is already part of this tick's input. */
    @Override
    public void onPreTick() {
        if (mc.player == null) return;
        if (sneakHold > 0) {
            mc.options.sneakKey.setPressed(true);
            forcedSneak = true;
        } else {
            releaseSneak();
        }
    }

    private static Vec3d faceHit(BlockPos neighbor, Direction face, Random rnd) {
        Vec3d n = Vec3d.of(face.getVector());
        Vec3d c = Vec3d.ofCenter(neighbor).add(n.multiply(0.5));
        double jx = n.x == 0 ? (rnd.nextDouble() - 0.5) * 0.5 : 0;
        double jy = n.y == 0 ? (rnd.nextDouble() - 0.5) * 0.5 : 0;
        double jz = n.z == 0 ? (rnd.nextDouble() - 0.5) * 0.5 : 0;
        return c.add(jx, jy, jz);
    }

    /** Finds a block to place against for {@code target}; returns {neighbor, face} or null. */
    private BlockPos[] support(BlockPos target, Vec3d eye, Direction[] faceOut) {
        for (Direction d : Direction.values()) {
            if (d == Direction.UP) continue;
            BlockPos neighbor = target.offset(d);
            if (mc.world.getBlockState(neighbor).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d center = Vec3d.ofCenter(neighbor).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (eye.subtract(center).dotProduct(Vec3d.of(face.getVector())) <= 0) continue; // we are behind this face
            faceOut[0] = face;
            return new BlockPos[]{target, neighbor};
        }
        return null;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait > 0) { wait--; return; }

        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        if (!mc.world.getBlockState(below).isReplaceable()) { sneakHold = 0; return; }

        int slot = bestSlot();
        if (slot < 0) return;

        Vec3d eye = p.getEyePos();
        Direction[] face = new Direction[1];
        BlockPos[] found = support(below, eye, face);
        if (found == null) {
            // nothing next to the target: place a block next to us first so the next one has a neighbour
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                BlockPos cand = below.offset(d);
                if (!mc.world.getBlockState(cand).isReplaceable()) continue;
                BlockPos[] s = support(cand, eye, new Direction[1]);
                if (s == null) continue;
                double dist = Vec3d.ofCenter(cand).squaredDistanceTo(p.getX(), p.getY(), p.getZ());
                if (dist < bestD) { bestD = dist; best = cand; }
            }
            if (best == null) return;
            found = support(best, eye, face);
            if (found == null) return;
        }
        BlockPos neighbor = found[1];
        Direction placeFace = face[0];
        Vec3d hit = faceHit(neighbor, placeFace, rnd);

        if (rotate.get()) {
            float[] want = EntityUtil.rotationsTo(p, hit);
            float[] cur = RotationManager.current(p);
            boolean on = RotationManager.lookingAt(p, cur[0], cur[1], new Box(neighbor), 4.5);
            RotationManager.request(p, want[0], want[1], turnSpeed.getFloat(), true);
            if (!on) return; // wait until the rotation the server has actually points at the block
        }

        if (sneak.get() && !p.isSneaking()) {
            sneakHold = 2; // crouch on the next tick, place when the crouch is active
            return;
        }

        if (previousSlot < 0) previousSlot = p.getInventory().getSelectedSlot();
        InventoryUtil.select(slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, placeFace, neighbor, false));
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        sneakHold = 0;
        int lo = minDelay.getInt(), hi = Math.max(lo, maxDelay.getInt());
        wait = lo + rnd.nextInt(hi - lo + 1);
    }
}
