package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Finds player bases by scoring loaded chunks on the things people build and nature does not: storage, furnaces,
 * beds, hoppers, beacons, signs. Neighbouring chunks are merged into one base. Containers remembered by StorageEsp
 * (including ones the server hid) count as well.
 */
public class BaseFinder extends Module {
    private final Setting.Num radius = add(new Setting.Num("Chunk radius", 12, 3, 32, 1));
    private final Setting.Num minScore = add(new Setting.Num("Min score", 10, 2, 60, 1));
    private final Setting.Bool useMemory = add(new Setting.Bool("Use StorageEsp memory", true));
    private final Setting.Bool boxes = add(new Setting.Bool("Base box", true));
    private final Setting.Num boxOpacity = add(new Setting.Num("Box opacity", 50, 10, 160, 10));
    private final Setting.Bool inspect = add(new Setting.Bool("Show contents when looking", true));
    private final Setting.Num maxShown = add(new Setting.Num("Max bases", 5, 1, 12, 1));

    private static final class Base {
        double x, y, z;
        int score, chunks;
        Box box;
        Map<String, Integer> counts = new HashMap<>();
    }

    /** Per-chunk accumulator: weighted centre, bounds and what was found. */
    private static final class Cell {
        double score, sx, sy, sz;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        Map<String, Integer> counts = new HashMap<>();
    }

    private volatile List<Base> bases = new ArrayList<>();
    private int timer;

    public BaseFinder() {
        super("BaseFinder", "Detects player bases from storage, furnaces, beds and other built blocks in loaded chunks.", Category.RENDER);
    }

    @Override
    protected void onEnable() { bases = new ArrayList<>(); timer = 0; }

    private static int weight(String id) {
        return switch (id) {
            case "chest", "trapped_chest", "barrel", "shulker_box" -> 3;
            case "beacon" -> 8;
            case "furnace", "blast_furnace", "smoker", "hopper", "dispenser", "dropper", "brewing_stand", "bed", "campfire" -> 2;
            case "ender_chest", "sign", "hanging_sign", "banner", "jukebox", "lectern", "enchanting_table", "bell" -> 1;
            default -> 0;
        };
    }

    private static String label(String id) {
        return switch (id) {
            case "chest" -> "Chests";
            case "trapped_chest" -> "Trapped chests";
            case "barrel" -> "Barrels";
            case "shulker_box" -> "Shulker boxes";
            case "ender_chest" -> "Ender chests";
            case "furnace", "blast_furnace", "smoker" -> "Furnaces";
            case "hopper" -> "Hoppers";
            case "dispenser", "dropper" -> "Dispensers";
            case "brewing_stand" -> "Brewing stands";
            case "bed" -> "Beds";
            case "campfire" -> "Campfires";
            case "beacon" -> "Beacons";
            case "sign", "hanging_sign" -> "Signs";
            case "banner" -> "Banners";
            default -> "Other";
        };
    }

    private static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xFFFFFFFFL); }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        if (timer-- > 0) return;
        timer = 20;

        int pcx = mc.player.getBlockPos().getX() >> 4, pcz = mc.player.getBlockPos().getZ() >> 4;
        int r = radius.getInt();
        Map<Long, Cell> cells = new HashMap<>();
        Set<Long> counted = new HashSet<>();

        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz, false);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    var id = Registries.BLOCK_ENTITY_TYPE.getId(be.getType());
                    if (id == null) continue;
                    int w = weight(id.getPath());
                    if (w == 0) continue;
                    BlockPos p = be.getPos();
                    if (!counted.add(p.asLong())) continue;
                    add(cells, cx, cz, p, w, label(id.getPath()));
                }
            }
        }
        if (useMemory.get()) {
            StorageEsp se = ZenithClient.modules().get(StorageEsp.class);
            if (se != null) {
                for (BlockPos p : se.remembered()) {
                    int cx = p.getX() >> 4, cz = p.getZ() >> 4;
                    if (Math.abs(cx - pcx) > r || Math.abs(cz - pcz) > r) continue;
                    if (counted.add(p.asLong())) add(cells, cx, cz, p, 3, "Hidden containers");
                }
            }
        }

        // merge neighbouring scoring chunks into bases
        List<Base> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        for (Long start : cells.keySet()) {
            if (!seen.add(start)) continue;
            ArrayDeque<Long> q = new ArrayDeque<>();
            q.add(start);
            Base b = new Base();
            double sc = 0, sx = 0, sy = 0, sz = 0;
            int n = 0, x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, z0 = Integer.MAX_VALUE;
            int x1 = Integer.MIN_VALUE, y1 = Integer.MIN_VALUE, z1 = Integer.MIN_VALUE;
            while (!q.isEmpty()) {
                long cur = q.poll();
                Cell c = cells.get(cur);
                sc += c.score; sx += c.sx; sy += c.sy; sz += c.sz;
                x0 = Math.min(x0, c.minX); y0 = Math.min(y0, c.minY); z0 = Math.min(z0, c.minZ);
                x1 = Math.max(x1, c.maxX); y1 = Math.max(y1, c.maxY); z1 = Math.max(z1, c.maxZ);
                for (Map.Entry<String, Integer> e : c.counts.entrySet()) b.counts.merge(e.getKey(), e.getValue(), Integer::sum);
                n++;
                int ccx = (int) (cur >> 32), ccz = (int) cur;
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    long nk = key(ccx + dx, ccz + dz);
                    if (cells.containsKey(nk) && seen.add(nk)) q.add(nk);
                }
            }
            if (sc >= minScore.get()) {
                b.score = (int) sc; b.chunks = n;
                b.x = sx / sc; b.y = sy / sc; b.z = sz / sc;
                // the box wraps everything found, with a little slack and a sensible minimum size
                b.box = new Box(x0 - 2, y0 - 1, z0 - 2, x1 + 3, y1 + 2, z1 + 3);
                out.add(b);
            }
        }
        out.sort((a, b) -> Double.compare(dist(a), dist(b)));
        bases = out;

    }

    private static void add(Map<Long, Cell> cells, int cx, int cz, BlockPos p, int w, String what) {
        Cell c = cells.computeIfAbsent(key(cx, cz), k -> new Cell());
        c.score += w; c.sx += p.getX() * (double) w; c.sy += p.getY() * (double) w; c.sz += p.getZ() * (double) w;
        c.minX = Math.min(c.minX, p.getX()); c.minY = Math.min(c.minY, p.getY()); c.minZ = Math.min(c.minZ, p.getZ());
        c.maxX = Math.max(c.maxX, p.getX()); c.maxY = Math.max(c.maxY, p.getY()); c.maxZ = Math.max(c.maxZ, p.getZ());
        c.counts.merge(what, 1, Integer::sum);
    }

    /** Wireframe of the base volume (only when every corner is in front of the camera). */
    private static void edges(DrawContext ctx, Projector pr, Box b, int color) {
        double[][] p = new double[8][];
        for (int i = 0; i < 8; i++) {
            p[i] = pr.project(new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ));
            if (p[i] == null) return;
        }
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) != 0) continue;
                int j = i | bit;
                DrawUtil.line(ctx, p[i][0], p[i][1], p[j][0], p[j][1], color, pr.width, pr.height);
            }
        }
    }

    /** Look at a base box (or stand inside it) to see what it contains. */
    private void drawContents(DrawContext ctx, List<Base> now) {
        if (now.isEmpty()) return;
        Vec3d eye = mc.player.getLerpedPos(ZenithClient.partial()).add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);
        Vec3d end = eye.add(mc.player.getRotationVector().multiply(160));
        Base target = null;
        double best = Double.MAX_VALUE;
        for (Base b : now) {
            if (b.box == null) continue;
            double d;
            if (b.box.contains(eye)) d = 0;
            else {
                var hit = b.box.raycast(eye, end);
                if (hit.isEmpty()) continue;
                d = hit.get().squaredDistanceTo(eye);
            }
            if (d < best) { best = d; target = b; }
        }
        if (target == null) return;

        List<Map.Entry<String, Integer>> rows = new ArrayList<>(target.counts.entrySet());
        rows.sort((a, c) -> c.getValue() - a.getValue());
        int w = 128, h = 26 + rows.size() * 11;
        int x = mc.getWindow().getScaledWidth() / 2 + 14, y = mc.getWindow().getScaledHeight() / 2 + 10;
        ctx.fill(x, y, x + w, y + h, 0xD00B0C1F);
        ctx.fill(x, y, x + w, y + 1, 0xFFFFB84A);
        int sx = (int) (target.box.maxX - target.box.minX), sy = (int) (target.box.maxY - target.box.minY), sz = (int) (target.box.maxZ - target.box.minZ);
        ctx.drawText(mc.textRenderer, "Base  " + sx + "x" + sy + "x" + sz, x + 6, y + 4, 0xFFFFFFFF, true);
        ctx.drawText(mc.textRenderer, "Score " + target.score + " · " + target.chunks + " chunk(s)", x + 6, y + 14, 0xFF8890B5, false);
        int ry = y + 26;
        for (Map.Entry<String, Integer> e : rows) {
            ctx.drawText(mc.textRenderer, e.getKey(), x + 6, ry, 0xFFB8BEDD, false);
            String n = String.valueOf(e.getValue());
            ctx.drawText(mc.textRenderer, n, x + w - 6 - mc.textRenderer.getWidth(n), ry, 0xFFFFD84A, false);
            ry += 11;
        }
    }

    private double dist(Base b) {
        double dx = b.x - mc.player.getX(), dz = b.z - mc.player.getZ();
        return dx * dx + dz * dz;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        List<Base> now = bases;
        int shown = Math.min(now.size(), maxShown.getInt());

        Projector prj = Projector.create(ZenithClient.partial());
        if (boxes.get() && prj != null) {
            int fill = (boxOpacity.getInt() << 24) | 0xFFB84A;
            for (int i = 0; i < shown; i++) {
                Box bx = now.get(i).box;
                if (bx == null) continue;
                if (DrawUtil.fillBlock(ctx, prj, bx, fill)) edges(ctx, prj, bx, 0xFFFFB84A);
            }
        }
        if (inspect.get()) drawContents(ctx, now);

    }
}