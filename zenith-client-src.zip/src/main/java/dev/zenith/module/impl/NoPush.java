package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.Entity;

public class NoPush extends Module {
    private static NoPush instance;
    private final Setting.Bool entities = add(new Setting.Bool("Entities", true));
    private final Setting.Bool fluids = add(new Setting.Bool("Fluids", true));

    public NoPush() {
        super("NoPush", "You are not pushed by other entities or flowing water.", Category.PLAYER);
        instance = this;
    }

    public static boolean blocksEntities(Entity e) {
        return instance != null && instance.isEnabled() && instance.entities.get() && e == mc.player;
    }

    public static boolean blocksFluids(Entity e) {
        return instance != null && instance.isEnabled() && instance.fluids.get() && e == mc.player;
    }
}
