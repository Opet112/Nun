package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/** Pulsing on-screen warning when a worn armor piece (or elytra) is close to breaking. */
public class ArmorWarning extends Module {
    private final Setting.Num percent = add(new Setting.Num("Warn below %", 12, 2, 50, 1));
    private String text = "";

    public ArmorWarning() {
        super("ArmorWarning", "Warns you before armor breaks.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        text = "";
        if (mc.player == null) return;
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        String[] names = {"Helmet", "Chestplate", "Leggings", "Boots"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < slots.length; i++) {
            ItemStack st = mc.player.getEquippedStack(slots[i]);
            int max = st.getMaxDamage();
            if (st.isEmpty() || max <= 0) continue;
            int left = (int) (100.0 * (max - st.getDamage()) / max);
            if (left <= percent.get()) sb.append(sb.length() > 0 ? ", " : "").append(names[i]).append(' ').append(left).append('%');
        }
        if (sb.length() > 0) text = "Armor low: " + sb;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (text.isEmpty() || mc.player == null) return;
        float pulse = 0.55f + 0.45f * (float) Math.sin(System.currentTimeMillis() / 160.0);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        int tw = mc.textRenderer.getWidth(text);
        int x = w / 2 - tw / 2, y = h - 72;
        ctx.fill(x - 6, y - 4, x + tw + 6, y + 12, ((int) (0xB0 * pulse) << 24) | 0x3A0B14);
        ctx.fill(x - 6, y + 12, x + tw + 6, y + 13, 0xFFE8344F);
        ctx.drawText(mc.textRenderer, text, x, y, 0xFFFF6B7A, true);
    }
}
