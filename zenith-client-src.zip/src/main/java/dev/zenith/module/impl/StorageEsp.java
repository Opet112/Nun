package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Storage ESP with memory. Some servers turn far-away chests into stone; once a container has been seen it is
 * remembered and keeps being drawn until you stand close and the server's real data shows it is gone.
 */
public class StorageEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 32, 8, 64, 4));
    private final Setting.Num forgetDist = add(new Setting.Num("Forget distance", 6, 3, 16, 1));

    /** dimension -> (block position -> colour of the container that was seen there) */
    private final Map<String, Map<Long, Integer>> memory = new HashMap<>();
    private String lastServer = "";
    private int layer;

    public StorageEsp() {
        super("StorageEsp", "Chests/barrels/shulkers through walls, remembered even if the server hides them.", Category.RENDER);
    }

    private final Setting.Num opacity = add(new Setting.Num("Opacity", 110, 20, 255, 10));

    private static int colorFor(Block b) {
        if (b instanceof net.minecraft.block.TrappedChestBlock) return 0xFFFF6B3D;
        if (b instanceof EnderChestBlock) return 0xFFB57EDC;
        if (b instanceof ShulkerBoxBlock) return 0xFFFF7ED8;
        if (b instanceof BarrelBlock) return 0xFFC98A4B;
        return 0xFFFFD84A;
    }

    private static boolean storage(Block b) {
        return b instanceof ChestBlock || b instanceof BarrelBlock || b instanceof EnderChestBlock || b instanceof ShulkerBoxBlock;
    }

    /** Filled from the network thread by the packet mixin: {packed pos, colour}. */
    private static final ConcurrentLinkedQueue<long[]> PENDING = new ConcurrentLinkedQueue<>();

    /** Called for every block entity the server announces, whatever block state it shows for that position. */
    public static void packetSeen(BlockPos pos, net.minecraft.block.entity.BlockEntityType<?> type) {
        if (type == null || pos == null) return;
        net.minecraft.util.Identifier id = net.minecraft.registry.Registries.BLOCK_ENTITY_TYPE.getId(type);
        if (id == null) return;
        int col;
        switch (id.getPath()) {
            case "chest" -> col = 0xFFFFD84A;
            case "trapped_chest" -> col = 0xFFFF6B3D;
            case "ender_chest" -> col = 0xFFB57EDC;
            case "barrel" -> col = 0xFFC98A4B;
            case "shulker_box" -> col = 0xFFFF7ED8;
            default -> { return; }
        }
        if (PENDING.size() < 20000) PENDING.add(new long[]{pos.asLong(), col});
    }

    private Map<Long, Integer> here() {
        String dim = mc.world.getRegistryKey().getValue().toString();
        return memory.computeIfAbsent(dim, k -> new HashMap<>());
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        ServerInfo si = mc.getCurrentServerEntry();
        String server = si == null ? "single" : si.address;
        if (!server.equals(lastServer)) { memory.clear(); lastServer = server; }

        Map<Long, Integer> mem = here();
        long[] pk;
        while ((pk = PENDING.poll()) != null) mem.put(pk[0], (int) pk[1]);
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        BlockPos.Mutable m = new BlockPos.Mutable();
        int dx = layer - r;
        for (int dz = -r; dz <= r; dz++) {
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block seen = mc.world.getBlockState(m).getBlock();
                if (storage(seen)) mem.put(m.asLong(), colorFor(seen));
            }
        }
        layer = layer >= r * 2 ? 0 : layer + 1;

        // Only trust "this is no longer a container" when the server must be sending real blocks.
        double fd = forgetDist.get();
        mem.keySet().removeIf(l -> {
            BlockPos p = BlockPos.fromLong(l);
            double ddx = p.getX() + 0.5 - mc.player.getX(), ddy = p.getY() + 0.5 - mc.player.getY(), ddz = p.getZ() + 0.5 - mc.player.getZ();
            return ddx * ddx + ddy * ddy + ddz * ddz < fd * fd && !storage(mc.world.getBlockState(p).getBlock());
        });
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        // Containers the server swapped for stone/air stay drawn in their real colour: the anti-ESP trick changes
        // the block, not the memory. They are only dropped when you stand within the forget distance.
        for (Map.Entry<Long, Integer> e : here().entrySet()) {
            Box box = new Box(BlockPos.fromLong(e.getKey()));
            Block now = mc.world.getBlockState(BlockPos.fromLong(e.getKey())).getBlock();
            int col = storage(now) ? colorFor(now) : e.getValue();
            DrawUtil.fillBlock(ctx, pr, box, (opacity.getInt() << 24) | (col & 0xFFFFFF));
        }
    }
}
