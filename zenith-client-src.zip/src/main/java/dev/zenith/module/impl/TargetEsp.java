package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Draws a pulsing frame and health bar on the living entity closest to your crosshair. */
public class TargetEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 32, 4, 100, 2));
    private final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));

    public TargetEsp() {
        super("TargetEsp", "Highlights the entity you are aiming at.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        LivingEntity best = null;
        double bestAngle = 0.2; // radians-ish cone
        var look = mc.player.getRotationVec(partial);
        var eye = mc.player.getCameraPosVec(partial);
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity le) || e instanceof ArmorStandEntity || !le.isAlive()) continue;
            if (playersOnly.get() && !(e instanceof PlayerEntity)) continue;
            if (mc.player.distanceTo(e) > range.get()) continue;
            var to = le.getLerpedPos(partial).add(0, le.getHeight() / 2.0, 0).subtract(eye);
            double len = to.length();
            if (len < 0.1) continue;
            double ang = Math.acos(Math.max(-1, Math.min(1, look.dotProduct(to) / len)));
            if (ang < bestAngle) { bestAngle = ang; best = le; }
        }
        if (best == null) return;
        double[] s = pr.boxClamped(Projector.lerpedBox(best, partial));
        if (s == null) return;
        int x0 = (int) s[0], y0 = (int) s[1], x1 = (int) s[2], y1 = (int) s[3];
        int pulse = 150 + (int) (105 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 150.0)));
        int col = ColorUtil.withAlpha(ColorUtil.accent(0), pulse);
        ctx.fill(x0, y0, x1 + 1, y0 + 1, col);
        ctx.fill(x0, y1, x1 + 1, y1 + 1, col);
        ctx.fill(x0, y0, x0 + 1, y1 + 1, col);
        ctx.fill(x1, y0, x1 + 1, y1 + 1, col);
        float frac = Math.max(0f, Math.min(1f, best.getHealth() / Math.max(1f, best.getMaxHealth())));
        int bx = x0 - 4, h = y1 - y0;
        ctx.fill(bx, y0, bx + 2, y1, 0xAA000000);
        int g = (int) (255 * frac), r = 255 - g;
        ctx.fill(bx, y1 - (int) (h * frac), bx + 2, y1, 0xFF000000 | (r << 16) | (g << 8) | 0x30);
    }
}
