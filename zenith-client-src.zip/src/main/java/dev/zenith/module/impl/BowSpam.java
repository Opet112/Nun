package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** Releases the bow after a set draw time so you can shoot repeatedly while holding use. */
public class BowSpam extends Module {
    private final Setting.Num drawTicks = add(new Setting.Num("Draw ticks", 18, 3, 20, 1));

    public BowSpam() {
        super("BowSpam", "Auto-releases the bow after N ticks of draw (20 = full power).", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (p.isUsingItem() && p.getActiveItem().isOf(Items.BOW) && p.getItemUseTime() >= drawTicks.getInt()) {
            mc.interactionManager.stopUsingItem(p);
        }
    }
}
