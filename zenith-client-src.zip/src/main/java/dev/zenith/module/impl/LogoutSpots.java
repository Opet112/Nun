package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Remembers where players were standing when they disconnected. */
public class LogoutSpots extends Module {
    private static final class Spot {
        final String name, dim;
        final Vec3d pos;
        final long time;
        Spot(String name, String dim, Vec3d pos, long time) { this.name = name; this.dim = dim; this.pos = pos; this.time = time; }
    }

    private final Setting.Num maxSpots = add(new Setting.Num("Max spots", 20, 5, 60, 5));
    private final Setting.Bool announce = add(new Setting.Bool("Chat message", true));
    private final Setting.Num expire = add(new Setting.Num("Expire (min)", 30, 1, 240, 1));
    private final Map<UUID, Spot> seen = new HashMap<>();
    private final Map<UUID, Spot> gone = new HashMap<>();
    private String dim = "";

    public LogoutSpots() {
        super("LogoutSpots", "Marks where players logged out.", Category.RENDER);
    }

    @Override
    protected void onEnable() { seen.clear(); gone.clear(); }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null) return;
        String d = mc.world.getRegistryKey().getValue().toString();
        if (!d.equals(dim)) { dim = d; seen.clear(); gone.clear(); }

        Map<UUID, Boolean> present = new HashMap<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player) continue;
            present.put(e.getUuid(), true);
            seen.put(e.getUuid(), new Spot(e.getName().getString(), d, new Vec3d(e.getX(), e.getY(), e.getZ()), System.currentTimeMillis()));
            gone.remove(e.getUuid());
        }
        Iterator<Map.Entry<UUID, Spot>> it = seen.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            if (present.containsKey(en.getKey())) continue;
            // out of render distance but still on the player list = not a logout
            if (mc.getNetworkHandler().getPlayerListEntry(en.getKey()) == null) {
                gone.put(en.getKey(), en.getValue());
                if (announce.get()) {
                    Vec3d lp = en.getValue().pos;
                    ZenithClient.info(en.getValue().name + " logged out at " + (int) lp.x + " " + (int) lp.y + " " + (int) lp.z);
                }
                it.remove();
            }
        }
        long limit = expire.getInt() * 60000L;
        gone.values().removeIf(sp -> System.currentTimeMillis() - sp.time > limit);
        while (gone.size() > maxSpots.getInt()) {
            UUID oldest = null;
            long t = Long.MAX_VALUE;
            for (var en : gone.entrySet()) if (en.getValue().time < t) { t = en.getValue().time; oldest = en.getKey(); }
            if (oldest == null) break;
            gone.remove(oldest);
        }
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null || gone.isEmpty()) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        for (Spot s : gone.values()) {
            if (!s.dim.equals(dim)) continue;
            double[] b = pr.boxClamped(new Box(s.pos.x - 0.3, s.pos.y, s.pos.z - 0.3, s.pos.x + 0.3, s.pos.y + 1.8, s.pos.z + 0.3));
            if (b == null) continue;
            DrawUtil.outline(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], 0xFFE8344F);
            long mins = (System.currentTimeMillis() - s.time) / 60000L;
            String text = s.name + " logged out  [" + (int) s.pos.x + " " + (int) s.pos.y + " " + (int) s.pos.z + "]  " + (int) Math.sqrt(mc.player.squaredDistanceTo(s.pos.x, s.pos.y, s.pos.z)) + "m  " + mins + "min";
            int w = mc.textRenderer.getWidth(text);
            int x = (int) ((b[0] + b[2]) / 2) - w / 2, y = (int) b[1] - 11;
            ctx.fill(x - 2, y - 1, x + w + 2, y + 9, 0x90101216);
            ctx.drawText(mc.textRenderer, text, x, y, ColorUtil.TEXT, true);
        }
    }
}
