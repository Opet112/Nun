package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Marks ender pearls in flight and predicts where they will land (pearl traps, escapes, stasis chambers). */
public class PearlEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 128, 16, 300, 8));
    private final Setting.Bool landing = add(new Setting.Bool("Landing marker", true));

    public PearlEsp() {
        super("PearlEsp", "Shows thrown ender pearls and where they will land.", Category.RENDER);
    }

    private void label(DrawContext ctx, Projector pr, Vec3d at, String text, int color) {
        double[] s = pr.project(at);
        if (s == null) return;
        int w = mc.textRenderer.getWidth(text);
        int x = (int) s[0] - w / 2, y = (int) s[1] - 4;
        ctx.fill(x - 3, y - 2, x + w + 3, y + 10, 0xA00B0C1F);
        ctx.fill(x - 3, y + 10, x + w + 3, y + 11, color);
        ctx.drawText(mc.textRenderer, text, x, y, 0xFFFFFFFF, true);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EnderPearlEntity)) continue;
            double d = mc.player.distanceTo(e);
            if (d > range.get()) continue;
            label(ctx, pr, new Vec3d(e.getX(), e.getY(), e.getZ()), "Pearl " + (int) d + "m", 0xFFB57EDC);
            if (!landing.get()) continue;
            Vec3d pos = new Vec3d(e.getX(), e.getY(), e.getZ()), vel = e.getVelocity();
            for (int i = 0; i < 160; i++) {
                pos = pos.add(vel);
                vel = new Vec3d(vel.x * 0.99, vel.y * 0.99 - 0.03, vel.z * 0.99);
                if (!mc.world.getBlockState(BlockPos.ofFloored(pos)).isAir() || pos.y < mc.world.getBottomY()) break;
            }
            label(ctx, pr, pos, "Landing " + (int) new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ()).distanceTo(pos) + "m", 0xFFFF6B3D);
        }
    }
}
