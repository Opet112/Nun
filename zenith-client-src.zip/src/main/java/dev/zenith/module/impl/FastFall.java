package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.util.math.Vec3d;

/** Falls faster, which shortens the time you stay in the air (useful against knockback and for dropping into holes). */
public class FastFall extends Module {
    private final Setting.Num speed = add(new Setting.Num("Fall speed", 1.5, 0.5, 4, 0.25));

    public FastFall() {
        super("FastFall", "Increases your falling speed.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isGliding() || p.getAbilities().flying) return;
        Vec3d v = p.getVelocity();
        if (v.y < -0.35 && v.y > -speed.get()) p.setVelocity(v.x, -speed.get(), v.z);
    }
}
