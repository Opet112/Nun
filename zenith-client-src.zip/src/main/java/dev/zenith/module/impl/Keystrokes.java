package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.util.CpsCounter;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

public class Keystrokes extends Module {
    private final Setting.Bool mouse = add(new Setting.Bool("Mouse + CPS", true));

    private final Setting.Bool space = add(new Setting.Bool("Space bar", true));
    private final java.util.Map<String, Float> glow = new java.util.HashMap<>();

    public Keystrokes() {
        super("Keystrokes", "Shows WASD and mouse buttons on screen.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        var o = mc.options;
        int x = 6, y = mc.getWindow().getScaledHeight() - 112;
        key(ctx, "W", x + 20, y, 18, o.forwardKey.isPressed());
        key(ctx, "A", x, y + 20, 18, o.leftKey.isPressed());
        key(ctx, "S", x + 20, y + 20, 18, o.backKey.isPressed());
        key(ctx, "D", x + 40, y + 20, 18, o.rightKey.isPressed());
        if (space.get()) wide(ctx, "SPACE", x, y + 56, 60, o.jumpKey.isPressed());
        if (mouse.get()) {
            wide(ctx, "L " + CpsCounter.left(), x, y + 40, 29, GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS);
            wide(ctx, "R " + CpsCounter.right(), x + 31, y + 40, 29, GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS);
        }
    }

    private int shade(String id, boolean down) {
        float g = glow.getOrDefault(id, 0f);
        g += ((down ? 1f : 0f) - g) * 0.3f;
        glow.put(id, g);
        int base = 0x90101216, on = ColorUtil.withAlpha(ColorUtil.accent(0), 0xB0);
        return dev.zenith.util.ZeusTheme.lerp(base, on, g);
    }

    private void key(DrawContext ctx, String label, int x, int y, int size, boolean down) {
        ctx.fill(x, y, x + size, y + size, shade(label, down));
        int w = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (size - w) / 2, y + (size - 8) / 2, ColorUtil.TEXT, true);
    }

    private void wide(DrawContext ctx, String label, int x, int y, int width, boolean down) {
        ctx.fill(x, y, x + width, y + 14, shade(label.split(" ")[0], down));
        ctx.drawText(mc.textRenderer, label, x + 3, y + 3, ColorUtil.TEXT, true);
    }
}
