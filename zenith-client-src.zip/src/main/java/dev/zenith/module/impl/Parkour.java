package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Parkour extends Module {
    public Parkour() {
        super("Parkour", "Jumps automatically at the edge of a block.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null || p.isSneaking()) return;
        if (EntityUtil.isMoving() && EntityUtil.atEdge(p)) p.jump();
    }
}
