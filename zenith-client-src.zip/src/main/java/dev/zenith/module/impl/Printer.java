package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.util.ColorUtil;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import dev.zenith.util.Schematic;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

/**
 * Builds a schematic (.litematic, .schem, .nbt) block by block. Put files in .minecraft/zenith/schematics,
 * then use .schem load <file> and .schem start while standing where the build's corner should be.
 * Block states are reduced to block names, so stairs/slabs/etc. are placed without their orientation.
 */
public class Printer extends Module {
    private final Setting.Num perTick = add(new Setting.Num("Blocks/tick", 1, 1, 4, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 10, 1));
    private final Setting.Num reach = add(new Setting.Num("Reach", 4.5, 2, 5.5, 0.5));
    private final Setting.Bool swing = add(new Setting.Bool("Swing", true));
    private final Setting.Bool walk = add(new Setting.Bool("Walk to blocks", true));
    private final Setting.Bool layerOnly = add(new Setting.Bool("Preview current layer only", false));
    private final Setting.Bool progressBar = add(new Setting.Bool("Progress bar", true));
    private final Setting.Bool preview = add(new Setting.Bool("Preview outline", true));
    private final Setting.Num previewAlpha = add(new Setting.Num("Preview opacity", 90, 20, 200, 10));
    private final Setting.Num previewRange = add(new Setting.Num("Preview range", 24, 8, 64, 4));
    private final Setting.Bool restock = add(new Setting.Bool("Restock from containers", true));
    private final Setting.Num stopHealth = add(new Setting.Num("Stop below HP", 8, 0, 19, 1));

    private Schematic schematic;
    private String schematicName = "";
    private Block[] targets;
    private int[] order;
    private boolean[] done;
    private int doneCount, wait, first, nag;
    private BlockPos origin;
    private BlockPos anchor;

    private enum State { BUILD, RESTOCK }
    private State state = State.BUILD;
    private Vec3d walkTarget;
    private boolean wasWalking;
    private final Set<Long> emptied = new HashSet<>();
    private final Map<Item, Integer> need = new HashMap<>();
    private BlockPos container;
    private int openWait, clickWait, clicks, restocks, stuckTicks, goalTicks, idle;
    private boolean visitTook;
    private Vec3d lastPos;

    public Printer() {
        super("Printer", "Builds a loaded schematic (.schem load <file>, .schem start).", Category.PLAYER);
    }

    public static Path folder() {
        return FabricLoader.getInstance().getGameDir().resolve("zenith").resolve("schematics");
    }

    public static List<String> files() {
        List<String> out = new ArrayList<>();
        try {
            Files.createDirectories(folder());
            try (Stream<Path> s = Files.list(folder())) {
                s.map(p -> p.getFileName().toString()).filter(n -> {
                    String l = n.toLowerCase(Locale.ROOT);
                    return l.endsWith(".litematic") || l.endsWith(".schem") || l.endsWith(".nbt");
                }).sorted().forEach(out::add);
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Returns a message for the chat. */
    public String load(String file) {
        try {
            Schematic s;
            if (file.toLowerCase(Locale.ROOT).startsWith("builtin:")) {
                s = dev.zenith.util.BuiltinSchematics.build(file.substring(8).trim());
                if (s == null) return "Unknown built-in blueprint. Use .schem builtin to list them.";
            } else {
                Path p = folder().resolve(file).normalize();
                if (!p.startsWith(folder())) return "Invalid file name.";
                s = Schematic.load(p);
            }
            List<Integer> keep = new ArrayList<>();
            List<Block> blocks = new ArrayList<>();
            for (int i = 0; i < s.size(); i++) {
                Identifier id = Identifier.tryParse(s.name(i));
                if (id == null || !Registries.BLOCK.containsId(id)) continue;
                Block b = Registries.BLOCK.get(id);
                if (b.asItem() == Items.AIR) continue; // water, fire, ... cannot be placed from an item
                keep.add(i);
                blocks.add(b);
            }
            if (keep.isEmpty()) return "Nothing buildable in " + file;
            int n = keep.size();
            Schematic loaded = s;
            order = new int[n];
            targets = new Block[n];
            Integer[] idx = new Integer[n];
            for (int i = 0; i < n; i++) idx[i] = i;
            java.util.Arrays.sort(idx, Comparator.<Integer>comparingInt(i -> loaded.y(keep.get(i)))
                    .thenComparingInt(i -> loaded.z(keep.get(i))).thenComparingInt(i -> loaded.x(keep.get(i))));
            for (int i = 0; i < n; i++) { order[i] = keep.get(idx[i]); targets[i] = blocks.get(idx[i]); }
            schematic = s;
            anchor = null;
            schematicName = file;
            done = new boolean[n];
            doneCount = 0;
            first = 0;
            return "Loaded " + file + ": " + n + " blocks (" + s.width + "x" + s.height + "x" + s.length + ").";
        } catch (Exception e) {
            return "Could not load " + file + ": " + e.getMessage();
        }
    }

    /** Fixes the build's corner at your current position (shown as a preview until you start). */
    public String anchorHere() {
        if (mc.player == null) return "";
        anchor = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        return "Origin set to " + anchor.getX() + " " + anchor.getY() + " " + anchor.getZ();
    }

    /** Called every frame by the HUD, also while the module is off, so you can look at the plan first. */
    public void previewRender(DrawContext ctx) {
        if (!preview.get() || schematic == null || mc.world == null || mc.player == null) return;
        BlockPos base = isEnabled() ? origin : anchor;
        if (base == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        double max = previewRange.get(), max2 = max * max;
        int drawn = 0;
        int layer = Integer.MIN_VALUE;
        if (layerOnly.get()) {
            for (int i = 0; i < done.length; i++) if (!done[i]) { layer = schematic.y(order[i]); break; }
        }
        if (progressBar.get() && isEnabled() && done.length > 0) {
            int w = 120, x = ctx.getScaledWindowWidth() / 2 - w / 2, y = 16;
            float frac = doneCount / (float) done.length;
            ctx.fill(x - 1, y - 1, x + w + 1, y + 7, 0xA0101216);
            ctx.fill(x, y, x + (int) (w * frac), y + 6, ColorUtil.accent(0));
            String t = schematicName + " " + (int) (frac * 100) + "%";
            ctx.drawText(mc.textRenderer, t, x + w / 2 - mc.textRenderer.getWidth(t) / 2, y + 9, ColorUtil.TEXT, true);
        }
        for (int i = 0; i < done.length && drawn < 500; i++) {
            if (done[i] && isEnabled()) continue;
            int s = order[i];
            if (layer != Integer.MIN_VALUE && schematic.y(s) != layer) continue;
            BlockPos pos = new BlockPos(base.getX() + schematic.x(s), base.getY() + schematic.y(s), base.getZ() + schematic.z(s));
            double dx = pos.getX() + 0.5 - mc.player.getX(), dy = pos.getY() + 0.5 - mc.player.getY(), dz = pos.getZ() + 0.5 - mc.player.getZ();
            if (dx * dx + dy * dy + dz * dz > max2) continue;
            Block cur = mc.world.getBlockState(pos).getBlock();
            if (cur == targets[i]) continue;
            boolean blocked = !BlockUtil.canPlaceAt(pos);
            int rgb;
            if (blocked) rgb = 0xE8344F; // something else is in the way
            else {
                int h = Registries.BLOCK.getId(targets[i]).getPath().hashCode();
                rgb = java.awt.Color.HSBtoRGB(((h & 0x7FFFFFFF) % 360) / 360f, 0.55f, 1f) & 0xFFFFFF;
            }
            double[] b = pr.box(new Box(pos));
            if (b == null) continue;
            int x0 = (int) b[0], y0 = (int) b[1], x1 = (int) b[2], y1 = (int) b[3];
            ctx.fill(x0, y0, x1 + 1, y1 + 1, (previewAlpha.getInt() << 24) | rgb); // translucent "ghost" block
            DrawUtil.outline(ctx, x0, y0, x1, y1, 0xFF000000 | rgb);
            drawn++;
        }
    }

    public boolean loaded() { return schematic != null; }
    public String status() {
        return schematic == null ? "No schematic loaded." : schematicName + " " + doneCount + "/" + done.length;
    }

    @Override
    protected void onEnable() {
        if (schematic == null || mc.player == null) {
            ZenithClient.info("Load a schematic first: .schem load <file>");
            setEnabledSilently(false);
            return;
        }
        origin = anchor != null ? anchor : BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        java.util.Arrays.fill(done, false);
        doneCount = 0;
        first = 0;
        wait = 0;
        nag = 0;
        state = State.BUILD;
        emptied.clear();
        container = null;
        restocks = 0;
        idle = 0;
        ZenithClient.info("Building " + schematicName + " from your position.");
    }

    @Override
    protected void onDisable() {
        walkTarget = null;
        releaseKeys();
        container = null;
        state = State.BUILD;
        if (mc.player != null && mc.player.currentScreenHandler != mc.player.playerScreenHandler) mc.player.closeHandledScreen();
    }

    @Override
    public String getSuffix() { return schematic == null ? null : doneCount + "/" + done.length; }

    private void releaseKeys() {
        if (wasWalking) {
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            wasWalking = false;
        }
    }

    /** Applies the walking decided in the last tick before vanilla reads the keys. */
    @Override
    public void onPreTick() {
        if (mc.player == null) return;
        if (walkTarget != null) {
            mc.options.forwardKey.setPressed(true);
            mc.options.jumpKey.setPressed(mc.player.horizontalCollision && mc.player.isOnGround());
            wasWalking = true;
        } else {
            releaseKeys();
        }
    }

    /** Turns toward the target and walks. Returns true if we have been stuck for a while. */
    private boolean walkToward(double x, double z) {
        var p = mc.player;
        double dx = x - p.getX(), dz = z - p.getZ();
        p.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90f);
        walkTarget = new Vec3d(x, p.getY(), z);
        Vec3d now = new Vec3d(p.getX(), p.getY(), p.getZ());
        if (lastPos != null && now.squaredDistanceTo(lastPos) < 0.0004) stuckTicks++; else stuckTicks = 0;
        lastPos = now;
        return stuckTicks > 60;
    }

    private void stopWalking() { walkTarget = null; stuckTicks = 0; }

    private boolean fetch(Item item) {
        var p = mc.player;
        for (int i = 9; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(item)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, p.getInventory().getSelectedSlot(), SlotActionType.SWAP, p);
                return true;
            }
        }
        return false;
    }

    private static boolean isContainer(Block b) {
        return b instanceof ChestBlock || b instanceof BarrelBlock || b instanceof ShulkerBoxBlock;
    }

    private BlockPos nearestContainer() {
        var p = mc.player;
        int px = (int) Math.floor(p.getX()), py = (int) Math.floor(p.getY()), pz = (int) Math.floor(p.getZ());
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -24; x <= 24; x++) for (int y = -12; y <= 12; y++) for (int z = -24; z <= 24; z++) {
            m.set(px + x, py + y, pz + z);
            if (emptied.contains(m.asLong()) || !isContainer(mc.world.getBlockState(m).getBlock())) continue;
            double d = x * x + y * y + z * z;
            if (d < bestD) { bestD = d; best = m.toImmutable(); }
        }
        return best;
    }

    private void computeNeed() {
        need.clear();
        for (int i = 0; i < done.length; i++) {
            if (done[i]) continue;
            Item it = targets[i].asItem();
            need.merge(it, 1, Integer::sum);
        }
    }

    private Map<Item, Integer> inventoryCounts() {
        Map<Item, Integer> have = new HashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (!st.isEmpty()) have.merge(st.getItem(), st.getCount(), Integer::sum);
        }
        return have;
    }

    private void closeContainer(boolean markEmpty) {
        if (markEmpty && container != null) emptied.add(container.asLong());
        mc.player.closeHandledScreen();
        container = null;
        openWait = 0;
        clicks = 0;
        visitTook = false;
        state = State.BUILD;
        wait = 5;
    }

    private void restockTick() {
        var p = mc.player;
        ScreenHandler h = p.currentScreenHandler;
        if (h != p.playerScreenHandler) {
            if (clickWait-- > 0) return;
            int n = h.slots.size() - 36;
            Map<Item, Integer> have = inventoryCounts();
            if (n > 0 && clicks < 60) {
                for (int s = 0; s < n; s++) {
                    ItemStack st = h.getSlot(s).getStack();
                    if (st.isEmpty()) continue;
                    int want = need.getOrDefault(st.getItem(), 0) - have.getOrDefault(st.getItem(), 0);
                    if (want <= 0) continue;
                    mc.interactionManager.clickSlot(h.syncId, s, 0, SlotActionType.QUICK_MOVE, p);
                    clicks++;
                    visitTook = true;
                    clickWait = 2;
                    return;
                }
            }
            closeContainer(!visitTook);
            return;
        }
        if (container == null) {
            container = nearestContainer();
            if (container == null) {
                ZenithClient.info("No container with the needed blocks found nearby. Stopping.");
                setEnabled(false);
                return;
            }
        }
        double dx = container.getX() + 0.5 - p.getX(), dy = container.getY() + 0.5 - p.getEyeY(), dz = container.getZ() + 0.5 - p.getZ();
        if (dx * dx + dy * dy + dz * dz > 14.0) {
            if (!walk.get() || walkToward(container.getX() + 0.5, container.getZ() + 0.5)) {
                emptied.add(container.asLong());
                container = null;
                stopWalking();
            }
            return;
        }
        stopWalking();
        if (openWait == 0) {
            Vec3d center = Vec3d.ofCenter(container);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                    new BlockHitResult(center, BlockUtil.bestFace(container, p.getEyePos()), container, false));
            openWait = 1;
            clickWait = 3;
            visitTook = false;
            clicks = 0;
            if (++restocks > 40) {
                ZenithClient.info("Restocked too many times, stopping.");
                setEnabled(false);
            }
        } else if (++openWait > 40) {
            emptied.add(container.asLong());
            container = null;
            openWait = 0;
        }
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || schematic == null) return;
        if (stopHealth.getInt() > 0 && p.getHealth() <= stopHealth.getInt()) {
            ZenithClient.info("Health is low, Printer stopped.");
            setEnabled(false);
            return;
        }
        walkTarget = null;
        if (state == State.RESTOCK) { restockTick(); return; }
        if (mc.currentScreen != null) return;
        if (wait-- > 0) return;

        double r2 = reach.get() * reach.get();
        int placed = 0, scanned = 0, goal = -1;
        Set<String> missing = new TreeSet<>();
        for (int i = first; i < done.length && placed < perTick.getInt(); i++) {
            if (done[i]) { if (i == first) first++; continue; }
            if (++scanned > 8000) break;
            int s = order[i];
            BlockPos pos = new BlockPos(origin.getX() + schematic.x(s), origin.getY() + schematic.y(s), origin.getZ() + schematic.z(s));
            Block target = targets[i];
            if (mc.world.getBlockState(pos).getBlock() == target) { done[i] = true; doneCount++; continue; }
            if (!BlockUtil.canPlaceAt(pos)) { done[i] = true; doneCount++; continue; } // something else is there
            if (p.getEyePos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > r2) {
                if (goal < 0) goal = i;
                continue;
            }
            if (!BlockUtil.hasSupport(pos)) continue;
            Item item = target.asItem();
            int slot = InventoryUtil.findHotbar(item);
            if (slot < 0) {
                if (fetch(item)) { wait = 1; return; }
                missing.add(Registries.ITEM.getId(item).getPath());
                continue;
            }
            InventoryUtil.select(slot);
            if (BlockUtil.place(pos, Hand.MAIN_HAND, swing.get())) placed++;
        }
        if (placed > 0) { wait = delay.getInt(); idle = 0; goalTicks = 0; }
        if (doneCount >= done.length) {
            ZenithClient.info("Schematic finished.");
            setEnabled(false);
            return;
        }
        if (placed > 0) return;

        if (goal >= 0 && walk.get()) {
            // nothing placeable from here: walk towards the next block that is still out of reach
            int s = order[goal];
            boolean stuck = walkToward(origin.getX() + schematic.x(s) + 0.5, origin.getZ() + schematic.z(s) + 0.5);
            if (stuck || ++goalTicks > 600) { done[goal] = true; doneCount++; goalTicks = 0; stopWalking(); }
            return;
        }
        if (!missing.isEmpty()) {
            if (restock.get()) {
                computeNeed();
                state = State.RESTOCK;
                container = null;
                openWait = 0;
            } else if (nag++ % 100 == 0) {
                ZenithClient.info("Missing items: " + String.join(", ", missing));
            }
            return;
        }
        if (++idle > 200) {
            ZenithClient.info("Nothing more can be built from here. " + status());
            setEnabled(false);
        }
    }
}
