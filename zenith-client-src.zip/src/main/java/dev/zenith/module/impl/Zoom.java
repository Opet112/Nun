package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

public class Zoom extends Module {
    private final Setting.Num fov = add(new Setting.Num("FOV", 30, 30, 90, 5));
    private final Setting.Bool smooth = add(new Setting.Bool("Smooth", true));
    private int previous = -1;
    private double current = -1;

    public Zoom() {
        super("Zoom", "Narrows your field of view to zoom in.", Category.RENDER);
    }

    @Override
    protected void onEnable() { previous = mc.options.getFov().getValue(); }

    @Override
    public void onTick() {
        if (previous < 0) previous = mc.options.getFov().getValue();
        if (current < 0) current = previous;
        double target = fov.get();
        current = smooth.get() ? current + (target - current) * 0.35 : target;
        mc.options.getFov().setValue((int) Math.round(Math.max(30, current)));
    }

    @Override
    protected void onDisable() { restore(); }

    @Override
    public void onShutdown() { restore(); }

    private void restore() {
        if (previous >= 30) mc.options.getFov().setValue(previous);
        previous = -1;
        current = -1;
    }
}
