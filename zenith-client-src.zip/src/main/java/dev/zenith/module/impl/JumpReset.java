package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class JumpReset extends Module {
    public JumpReset() {
        super("JumpReset", "Jumps when you take a hit to cut knockback.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (p.hurtTime > 0 && p.isOnGround()) p.jump();
    }
}
