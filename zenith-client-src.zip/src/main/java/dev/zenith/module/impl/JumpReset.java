package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class JumpReset extends Module {
    private final Setting.Num chance = add(new Setting.Num("Chance %", 80, 10, 100, 5));
    private boolean decided;

    public JumpReset() {
        super("JumpReset", "Jumps when you take a hit to cut knockback.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (p.hurtTime == 0) { decided = false; return; }
        if (decided) return; // decide once per hit, a perfect reset every time looks scripted
        decided = true;
        if (p.isOnGround() && Math.random() * 100 < chance.get()) p.jump();
    }
}
