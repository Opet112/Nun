package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class Spider extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 0.2, 0.05, 0.6, 0.05));

    private final Setting.Bool needForward = add(new Setting.Bool("Require forward key", true));

    public Spider() {
        super("Spider", "Climb walls like a ladder.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || !p.horizontalCollision || p.isSneaking()) return;
        if (needForward.get() && !mc.options.forwardKey.isPressed()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, speed.get(), v.z);
    }
}
