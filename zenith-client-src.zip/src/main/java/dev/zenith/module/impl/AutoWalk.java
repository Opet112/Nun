package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class AutoWalk extends Module {
    private final Setting.Bool jump = add(new Setting.Bool("Jump over blocks", true));
    private final Setting.Bool sprint = add(new Setting.Bool("Sprint", false));
    private final Setting.Num stopHp = add(new Setting.Num("Stop below HP (0 = off)", 0, 0, 20, 1));
    private final Setting.Num stopNear = add(new Setting.Num("Stop if player within (0 = off)", 0, 0, 64, 4));

    public AutoWalk() {
        super("AutoWalk", "Holds the forward key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        boolean stop = (stopHp.get() > 0 && p.getHealth() <= stopHp.get())
                || (stopNear.get() > 0 && dev.zenith.util.EntityUtil.nearestPlayer(stopNear.get()) != null);
        if (stop) { mc.options.forwardKey.setPressed(false); return; }
        mc.options.forwardKey.setPressed(true);
        if (sprint.get() && !p.isSneaking()) p.setSprinting(true);
        if (jump.get() && p.horizontalCollision && p.isOnGround()) p.jump();
    }

    @Override
    protected void onDisable() { mc.options.forwardKey.setPressed(false); }
}
