package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.EntityHitResult;

public class AutoWeapon extends Module {
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back after fight", true));
    private int previous = -1, idle;
    private final Setting.Bool preferAxe = add(new Setting.Bool("Prefer axe", false));

    public AutoWeapon() {
        super("AutoWeapon", "Switches to your best weapon when you attack an entity.", Category.COMBAT);
    }

    private int score(ItemStack s) {
        if (s.isEmpty()) return 0;
        String path = Registries.ITEM.getId(s.getItem()).getPath();
        int rank = EntityUtil.materialRank(path);
        if (path.endsWith("_sword")) return 100 + rank + (preferAxe.get() ? 0 : 20);
        if (path.endsWith("_axe")) return 100 + rank + (preferAxe.get() ? 20 : 0);
        if (path.equals("mace")) return 90;
        if (path.equals("trident")) return 80;
        return 0;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        boolean fighting = mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof EntityHitResult;
        if (!fighting) {
            // a second after the last swing, go back to the slot you were on before
            if (previous >= 0 && ++idle > 20) {
                if (switchBack.get()) p.getInventory().setSelectedSlot(previous);
                previous = -1;
            }
            return;
        }
        idle = 0;
        int best = p.getInventory().getSelectedSlot();
        int bestScore = score(p.getInventory().getStack(best));
        for (int i = 0; i < 9; i++) {
            int sc = score(p.getInventory().getStack(i));
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        if (best != p.getInventory().getSelectedSlot()) {
            if (previous < 0) previous = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(best);
        }
    }
}
