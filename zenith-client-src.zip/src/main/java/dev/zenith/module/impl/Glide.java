package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class Glide extends Module {
    private final Setting.Num fall = add(new Setting.Num("Fall speed", 0.1, 0.02, 0.5, 0.01));

    private final Setting.Bool holdJump = add(new Setting.Bool("Only while holding jump", false));

    public Glide() {
        super("Glide", "Fall slowly.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isGliding()) return;
        if (holdJump.get() && !mc.options.jumpKey.isPressed()) return;
        Vec3d v = p.getVelocity();
        if (v.y < -fall.get()) p.setVelocity(v.x, -fall.get(), v.z);
    }
}
