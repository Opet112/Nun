package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.util.Hand;

import java.util.Random;

public class AntiAfk extends Module {
    private final Setting.Num interval = add(new Setting.Num("Interval (s)", 20, 5, 120, 5));
    private final Random random = new Random();
    private int timer;

    public AntiAfk() {
        super("AntiAFK", "Moves slightly now and then so you are not kicked for idling.", Category.PLAYER);
    }

    @Override
    protected void onEnable() { timer = 0; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (++timer < interval.getInt() * 20) return;
        timer = 0;
        p.setYaw(p.getYaw() + (random.nextFloat() - 0.5f) * 40f);
        p.swingHand(Hand.MAIN_HAND);
        if (p.isOnGround()) p.jump();
    }
}
