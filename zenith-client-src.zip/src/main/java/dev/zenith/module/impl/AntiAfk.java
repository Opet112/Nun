package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.util.Hand;

import java.util.Random;

public class AntiAfk extends Module {
    private final Setting.Num interval = add(new Setting.Num("Interval (s)", 20, 5, 120, 5));
    private final Setting.Num jitter = add(new Setting.Num("Random jitter (s)", 5, 0, 30, 1));
    private final Setting.Bool jump = add(new Setting.Bool("Jump", true));
    private final Setting.Bool look = add(new Setting.Bool("Look around", true));
    private final Setting.Bool swing = add(new Setting.Bool("Swing", true));
    private final Setting.Bool sneakTap = add(new Setting.Bool("Sneak tap", true));
    private int sneakTicks, nextExtra;
    private final Random random = new Random();
    private int timer;

    public AntiAfk() {
        super("AntiAFK", "Moves slightly now and then so you are not kicked for idling.", Category.PLAYER);
    }

    @Override
    protected void onEnable() { timer = 0; nextExtra = 0; sneakTicks = 0; }

    @Override
    protected void onDisable() { if (mc.options != null) mc.options.sneakKey.setPressed(false); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (sneakTicks > 0) {
            mc.options.sneakKey.setPressed(true);
            if (--sneakTicks == 0) mc.options.sneakKey.setPressed(false);
        }
        if (++timer < interval.getInt() * 20 + nextExtra) return;
        timer = 0;
        nextExtra = jitter.getInt() > 0 ? random.nextInt(jitter.getInt() * 20 + 1) : 0;
        // pick one or two random actions instead of always doing the same thing
        for (int n = 0; n < 1 + random.nextInt(2); n++) {
            switch (random.nextInt(4)) {
                case 0 -> { if (look.get()) { p.setYaw(p.getYaw() + (random.nextFloat() - 0.5f) * 50f); p.setPitch(Math.max(-60f, Math.min(60f, p.getPitch() + (random.nextFloat() - 0.5f) * 20f))); } }
                case 1 -> { if (jump.get() && p.isOnGround()) p.jump(); }
                case 2 -> { if (swing.get()) p.swingHand(Hand.MAIN_HAND); }
                default -> { if (sneakTap.get()) sneakTicks = 3 + random.nextInt(4); }
            }
        }
    }
}
