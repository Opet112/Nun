package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.*;

/** Highlights any blocks you pick from the full block list (search and tick them on the module page). */
public class BlockEsp extends Module {
    public final Setting.BlockSet blocks = add(new Setting.BlockSet("Blocks", "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"));
    private final Setting.Bool exposedOnly = add(new Setting.Bool("Exposed only (ignore fake ores)", true));
    private final Setting.Bool tracers = add(new Setting.Bool("Tracers to nearest", false));
    private final Setting.Num tracerCount = add(new Setting.Num("Tracer count", 5, 1, 20, 1));
    private final Setting.Bool showUnverified = add(new Setting.Bool("Show unverified (may be fake)", true));
    private final Setting.Num verifyDist = add(new Setting.Num("Verify distance", 9, 3, 16, 1));
    /** Ores seen inside the distance where the server stops faking: these are real and are remembered. */
    private final Map<Long, Block> verified = new HashMap<>();
    private Object lastWorld;
    private final Setting.Bool probe = add(new Setting.Bool("Probe far blocks (risky)", false));
    private final Setting.Num probeRate = add(new Setting.Num("Probes per second", 8, 1, 40, 1));
    private final dev.zenith.util.Prober prober = new dev.zenith.util.Prober();
    private final Setting.Num range = add(new Setting.Num("Range", 32, 8, 128, 4));
    private final Setting.Num opacity = add(new Setting.Num("Opacity", 120, 20, 255, 10));
    private final Setting.Num maxShown = add(new Setting.Num("Max blocks", 400, 50, 3000, 50));

    private Set<Block> wanted = new HashSet<>();
    private int wantedVersion = -1;
    private Map<Long, Block> shown = new HashMap<>();
    private final Map<Long, Block> next = new HashMap<>();
    private int layer, dzCursor = Integer.MIN_VALUE;

    public BlockEsp() {
        super("BlockEsp", "Tints any blocks you choose (pick them from the full block list on this page).", Category.RENDER);
    }

    @Override
    protected void onEnable() { shown = new HashMap<>(); next.clear(); layer = 0; dzCursor = Integer.MIN_VALUE; wantedVersion = -1; }

    private boolean isWanted(Block b) { return wanted.contains(b); }

    private void refreshWanted() {
        if (wantedVersion == blocks.version()) return;
        wantedVersion = blocks.version();
        Set<Block> set = new HashSet<>();
        for (String id : blocks.ids()) {
            Identifier ident = Identifier.tryParse(id);
            if (ident != null && Registries.BLOCK.containsId(ident)) set.add(Registries.BLOCK.get(ident));
        }
        wanted = set;
        shown = new HashMap<>();
        next.clear();
        layer = 0;
    }

    /** True when at least one face of the block touches air, fluid or another non-solid block. */
    private boolean exposed(BlockPos.Mutable n, int x, int y, int z) {
        int[][] d = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        for (int[] o : d) {
            n.set(x + o[0], y + o[1], z + o[2]);
            if (mc.world.getChunkManager().getWorldChunk(n.getX() >> 4, n.getZ() >> 4, false) == null) continue; // unloaded neighbour reads as air: not a real opening
            if (!mc.world.getBlockState(n).isSolidBlock(mc.world, n)) return true;
        }
        return false;
    }

    private static int colorOf(Block b) {
        Identifier id = Registries.BLOCK.getId(b);
        float hue = (Math.abs(id.toString().hashCode()) % 360) / 360f;
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, 0.7f, 1f) & 0xFFFFFF);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        refreshWanted();
        if (wanted.isEmpty()) return;
        if (mc.world != lastWorld) { lastWorld = mc.world; verified.clear(); prober.clear(); }
        if (probe.get()) prober.step(shown.keySet(), verified, wanted::contains, probeRate.get());
        double vd = verifyDist.get();
        verified.entrySet().removeIf(en -> {
            BlockPos p = BlockPos.fromLong(en.getKey());
            if (p.getSquaredDistance(mc.player.getX(), mc.player.getY(), mc.player.getZ()) > (vd + 1) * (vd + 1)) return false;
            return !isWanted(mc.world.getBlockState(p).getBlock()); // mined, or turned to stone when you got close = it was fake
        });

        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        BlockPos.Mutable m = new BlockPos.Mutable(), nb = new BlockPos.Mutable();
        int budget = 24000, cap = maxShown.getInt();
        if (layer > r * 2) layer = 0;
        if (dzCursor < -r || dzCursor > r + 1) dzCursor = -r;
        while (budget > 0) {
            if (dzCursor > r) {
                dzCursor = -r;
                layer++;
                if (layer > r * 2) { layer = 0; shown = new HashMap<>(next); next.clear(); }
            }
            int dx = layer - r, dz = dzCursor++;
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block b = mc.world.getBlockState(m).getBlock();
                boolean wantedHere = wanted.contains(b);
                if (wantedHere) {
                    double ddx = dx, ddy = dy, ddz = dz;
                    if (ddx * ddx + ddy * ddy + ddz * ddz <= vd * vd) verified.put(m.asLong(), b);
                }
                if (wantedHere && next.size() < cap && (!exposedOnly.get() || exposed(nb, px + dx, py + dy, pz + dz))) next.put(m.asLong(), b);
            }
            budget -= 2 * r + 1;
        }
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Map<Long, Block> view = new HashMap<>();
        if (showUnverified.get()) view.putAll(shown);
        view.putAll(verified);
        if (view.isEmpty()) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        double pdx = mc.player.getX(), pdy = mc.player.getY(), pdz = mc.player.getZ(), nearSq = (verifyDist.get() + 1) * (verifyDist.get() + 1);
        for (Map.Entry<Long, Block> e : view.entrySet()) {
            if (!wanted.contains(e.getValue()) || prober.rejected.contains(e.getKey())) continue;
            BlockPos bp = BlockPos.fromLong(e.getKey());
            // far away the server shows stone for real ores too, so only re-check blocks close enough to be trusted
            if (bp.getSquaredDistance(pdx, pdy, pdz) <= nearSq && !wanted.contains(mc.world.getBlockState(bp).getBlock())) continue;
            DrawUtil.fillBlock(ctx, pr, new Box(bp), ((verified.containsKey(e.getKey()) ? opacity.getInt() : opacity.getInt() / 2) << 24) | (colorOf(e.getValue()) & 0xFFFFFF)); // unverified = fainter
        }
        if (tracers.get()) {
            double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
            List<Map.Entry<Long, Block>> list = new ArrayList<>(view.entrySet());
            list.sort(Comparator.comparingDouble(en -> BlockPos.fromLong(en.getKey()).getSquaredDistance(px, py, pz)));
            int n = 0;
            for (Map.Entry<Long, Block> en : list) {
                if (n >= tracerCount.getInt()) break;
                if (!wanted.contains(en.getValue())) continue;
                BlockPos bp = BlockPos.fromLong(en.getKey());
                double[] t = pr.project(new net.minecraft.util.math.Vec3d(bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5));
                n++;
                if (t == null) continue;
                DrawUtil.line(ctx, pr.width / 2.0, pr.height, t[0], t[1], 0xB0000000 | (colorOf(en.getValue()) & 0xFFFFFF), pr.width, pr.height);
            }
        }
    }
}
