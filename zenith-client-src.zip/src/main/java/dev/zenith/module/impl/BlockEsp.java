package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.*;

/** Highlights any blocks you pick from the full block list (search and tick them on the module page). */
public class BlockEsp extends Module {
    public final Setting.BlockSet blocks = add(new Setting.BlockSet("Blocks", "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"));
    private final Setting.Num range = add(new Setting.Num("Range", 32, 8, 128, 4));
    private final Setting.Num opacity = add(new Setting.Num("Opacity", 120, 20, 255, 10));
    private final Setting.Num maxShown = add(new Setting.Num("Max blocks", 400, 50, 3000, 50));

    private Set<Block> wanted = new HashSet<>();
    private int wantedVersion = -1;
    private Map<Long, Block> shown = new HashMap<>();
    private final Map<Long, Block> next = new HashMap<>();
    private int layer, dzCursor = Integer.MIN_VALUE;

    public BlockEsp() {
        super("BlockEsp", "Tints any blocks you choose (pick them from the full block list on this page).", Category.RENDER);
    }

    @Override
    protected void onEnable() { shown = new HashMap<>(); next.clear(); layer = 0; dzCursor = Integer.MIN_VALUE; wantedVersion = -1; }

    private void refreshWanted() {
        if (wantedVersion == blocks.version()) return;
        wantedVersion = blocks.version();
        Set<Block> set = new HashSet<>();
        for (String id : blocks.ids()) {
            Identifier ident = Identifier.tryParse(id);
            if (ident != null && Registries.BLOCK.containsId(ident)) set.add(Registries.BLOCK.get(ident));
        }
        wanted = set;
        shown = new HashMap<>();
        next.clear();
        layer = 0;
    }

    private static int colorOf(Block b) {
        Identifier id = Registries.BLOCK.getId(b);
        float hue = (Math.abs(id.toString().hashCode()) % 360) / 360f;
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, 0.7f, 1f) & 0xFFFFFF);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        refreshWanted();
        if (wanted.isEmpty()) return;
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        BlockPos.Mutable m = new BlockPos.Mutable();
        int budget = 24000, cap = maxShown.getInt();
        if (layer > r * 2) layer = 0;
        if (dzCursor < -r || dzCursor > r + 1) dzCursor = -r;
        while (budget > 0) {
            if (dzCursor > r) {
                dzCursor = -r;
                layer++;
                if (layer > r * 2) { layer = 0; shown = new HashMap<>(next); next.clear(); }
            }
            int dx = layer - r, dz = dzCursor++;
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block b = mc.world.getBlockState(m).getBlock();
                if (wanted.contains(b) && next.size() < cap) next.put(m.asLong(), b);
            }
            budget -= 2 * r + 1;
        }
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null || shown.isEmpty()) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        for (Map.Entry<Long, Block> e : shown.entrySet()) {
            if (!wanted.contains(e.getValue())) continue;
            BlockPos bp = BlockPos.fromLong(e.getKey());
            if (!wanted.contains(mc.world.getBlockState(bp).getBlock())) continue; // mined / changed since the sweep
            DrawUtil.fillBlock(ctx, pr, new Box(bp), (opacity.getInt() << 24) | (colorOf(e.getValue()) & 0xFFFFFF));
        }
    }
}
