package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.Random;

/** Takes items out of chests, barrels and shulker boxes, optionally skipping junk and with a randomised delay. */
public class ChestStealer extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min delay (ticks)", 1, 0, 10, 1));
    private final Setting.Num maxDelay = add(new Setting.Num("Max delay (ticks)", 3, 0, 10, 1));
    private final Setting.Bool close = add(new Setting.Bool("Close when empty", true));
    private final Setting.Bool skipJunk = add(new Setting.Bool("Skip junk", false));
    private final Setting.Bool stopWhenFull = add(new Setting.Bool("Stop when inventory full", true));
    private final Random rnd = new Random();
    private int wait;

    public ChestStealer() {
        super("ChestStealer", "Takes items out of an opened chest, barrel or shulker box.", Category.MISC);
    }

    private static boolean junk(ItemStack s) {
        return s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
                || s.isOf(Items.DIRT) || s.isOf(Items.COBBLESTONE) || s.isOf(Items.COBBLED_DEEPSLATE)
                || s.isOf(Items.GRAVEL) || s.isOf(Items.NETHERRACK) || s.isOf(Items.STICK)
                || s.isOf(Items.BONE) || s.isOf(Items.STRING)
                || s.isOf(Items.WHEAT_SEEDS) || s.isOf(Items.FLINT);
    }

    private boolean inventoryFull() {
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) return false;
        return true;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        ScreenHandler handler;
        int size;
        if (mc.currentScreen instanceof GenericContainerScreen g) {
            handler = g.getScreenHandler();
            size = g.getScreenHandler().getRows() * 9;
        } else if (mc.currentScreen instanceof ShulkerBoxScreen sh) {
            handler = sh.getScreenHandler();
            size = 27;
        } else { wait = 0; return; }
        if (wait-- > 0) return;

        if (stopWhenFull.get() && inventoryFull()) return;
        boolean leftover = false;
        for (int i = 0; i < size; i++) {
            var slot = handler.getSlot(i);
            if (!slot.hasStack()) continue;
            if (skipJunk.get() && junk(slot.getStack())) { leftover = true; continue; }
            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
            int lo = minDelay.getInt(), hi = Math.max(lo, maxDelay.getInt());
            wait = lo + rnd.nextInt(hi - lo + 1);
            return;
        }
        if (close.get()) p.closeHandledScreen();
    }
}
