package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class ChestStealer extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 10, 1));
    private final Setting.Bool close = add(new Setting.Bool("Close when empty", true));
    private int wait;

    public ChestStealer() {
        super("ChestStealer", "Takes everything out of an opened chest.", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof GenericContainerScreen screen)) { wait = 0; return; }
        if (wait-- > 0) return;

        GenericContainerScreenHandler handler = screen.getScreenHandler();
        int size = handler.getRows() * 9;
        for (int i = 0; i < size; i++) {
            if (handler.getSlot(i).hasStack()) {
                mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                wait = delay.getInt();
                return;
            }
        }
        if (close.get()) p.closeHandledScreen();
    }
}
