package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Eats a golden apple when your health drops, then returns to the item you were holding. */
public class AutoGap extends Module {
    private final Setting.Num health = add(new Setting.Num("Eat below HP", 10, 2, 19, 1));
    private final Setting.Bool enchanted = add(new Setting.Bool("Prefer enchanted", true));
    private final Setting.Bool needEnemy = add(new Setting.Bool("Only with enemy near", false));
    private int prev = -1;
    private boolean eating;
    private int eatTicks;

    public AutoGap() {
        super("AutoGap", "Auto-eats golden apples when low on health.", Category.COMBAT);
    }

    @Override
    protected void onDisable() { stop(); }

    private void stop() {
        if (eating && mc.options != null) mc.options.useKey.setPressed(false);
        if (eating && prev >= 0 && mc.player != null) InventoryUtil.select(prev);
        eating = false;
        prev = -1;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) { stop(); return; }
        if (eating) {
            if (++eatTicks > 4 && !p.isUsingItem()) stop(); // finished (or interrupted)
            return;
        }
        if (p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
        if (needEnemy.get() && EntityUtil.nearestPlayer(12) == null) return;
        Item first = enchanted.get() ? Items.ENCHANTED_GOLDEN_APPLE : Items.GOLDEN_APPLE;
        Item second = enchanted.get() ? Items.GOLDEN_APPLE : Items.ENCHANTED_GOLDEN_APPLE;
        int slot = InventoryUtil.findHotbar(first);
        if (slot < 0) slot = InventoryUtil.findHotbar(second);
        if (slot < 0) return;
        prev = p.getInventory().getSelectedSlot();
        InventoryUtil.select(slot);
        mc.options.useKey.setPressed(true);
        eating = true;
        eatTicks = 0;
    }
}
