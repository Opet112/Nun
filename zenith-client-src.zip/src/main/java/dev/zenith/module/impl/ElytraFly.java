package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.InventoryUtil;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** Works while you are gliding (jump in mid-air with an elytra equipped, as in vanilla). */
public class ElytraFly extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Control", "Control", "Boost"));
    private final Setting.Num speed = add(new Setting.Num("Speed", 1.8, 0.5, 4.0, 0.1));
    private final Setting.Num vertical = add(new Setting.Num("Vertical", 0.8, 0.2, 2.0, 0.1));
    private final Setting.Bool autoFirework = add(new Setting.Bool("Auto firework", false));
    private final Setting.Num fireworkDelay = add(new Setting.Num("Firework delay (s)", 3, 1, 10, 1));
    private int fireworkTimer;
    private int restoreSlot = -1;

    public ElytraFly() {
        super("ElytraFly", "Control or boost your elytra flight.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;

        if (restoreSlot >= 0) { InventoryUtil.select(restoreSlot); restoreSlot = -1; }
        if (!p.isGliding()) { fireworkTimer = 0; return; }

        var o = mc.options;
        boolean forward = o.forwardKey.isPressed();
        Vec3d look = p.getRotationVec(1.0f);

        if (mode.is("Control")) {
            double x = 0, y = 0, z = 0;
            if (forward) { x = look.x * speed.get(); y = look.y * speed.get(); z = look.z * speed.get(); }
            else if (o.backKey.isPressed()) { x = -look.x * speed.get(); z = -look.z * speed.get(); }
            if (o.jumpKey.isPressed()) y += vertical.get();
            if (o.sneakKey.isPressed()) y -= vertical.get();
            p.setVelocity(x, y, z);
        } else if (forward) {
            Vec3d v = p.getVelocity().add(look.multiply(0.08 * speed.get()));
            double max = speed.get() * 1.5;
            if (v.length() > max) v = v.normalize().multiply(max);
            p.setVelocity(v);
        }

        if (autoFirework.get() && forward && ++fireworkTimer >= fireworkDelay.getInt() * 20) {
            fireworkTimer = 0;
            useFirework();
        }
    }

    private void useFirework() {
        var p = mc.player;
        if (mc.interactionManager == null) return;
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            return;
        }
        int slot = InventoryUtil.findHotbar(Items.FIREWORK_ROCKET);
        if (slot < 0) return;
        restoreSlot = p.getInventory().getSelectedSlot();
        InventoryUtil.select(slot);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
    }

    @Override
    public String getSuffix() { return mode.get(); }
}
