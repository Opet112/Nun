package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Sneak extends Module {
    private final Setting.Bool onlyMoving = add(new Setting.Bool("Only while moving", false));
    private boolean held;

    public Sneak() {
        super("Sneak", "Holds the sneak key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        boolean want = !onlyMoving.get() || dev.zenith.util.EntityUtil.isMoving();
        if (want) { mc.options.sneakKey.setPressed(true); held = true; }
        else if (held) { mc.options.sneakKey.setPressed(false); held = false; }
    }

    @Override
    protected void onDisable() { mc.options.sneakKey.setPressed(false); }
}
