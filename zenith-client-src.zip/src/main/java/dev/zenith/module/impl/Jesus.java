package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    private final Setting.Bool water = add(new Setting.Bool("Water", true));
    private final Setting.Bool lava = add(new Setting.Bool("Lava", true));

    public Jesus() {
        super("Jesus", "Float on water and lava (client-side approximation).", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isSneaking() || mc.options.jumpKey.isPressed()) return;
        boolean inWater = water.get() && p.isTouchingWater();
        boolean inLava = lava.get() && p.isInLava();
        if (!inWater && !inLava) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, p.isSubmergedInWater() ? 0.12 : 0.0, v.z);
    }
}
