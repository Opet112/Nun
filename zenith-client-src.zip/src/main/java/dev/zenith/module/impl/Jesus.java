package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    public Jesus() {
        super("Jesus", "Float on water and lava (client-side approximation).", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isSneaking() || mc.options.jumpKey.isPressed()) return;
        if (!p.isTouchingWater() && !p.isInLava()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, p.isSubmergedInWater() ? 0.12 : 0.0, v.z);
    }
}
