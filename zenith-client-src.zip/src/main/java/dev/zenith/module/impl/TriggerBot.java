package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot extends Module {
    private final Setting.Bool playersOnly = add(new Setting.Bool("Players only", false));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown", 0.92, 0.5, 1.0, 0.01));

    private final Setting.Bool randomize = add(new Setting.Bool("Randomize", true));
    private final java.util.Random rng = new java.util.Random();
    private float threshold = 0.92f;

    public TriggerBot() {
        super("TriggerBot", "Attacks whatever your crosshair is on once the weapon is charged.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.player == null || mc.interactionManager == null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity le) || !le.isAlive() || EntityUtil.isFriend(target)) return;
        if (playersOnly.get() && !(target instanceof net.minecraft.entity.player.PlayerEntity)) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < threshold) return;
        threshold = Math.min(1.0f, cooldown.getFloat() + (randomize.get() ? (rng.nextFloat() - 0.5f) * 0.08f : 0f));
        Criticals.apply();
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
