package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.GameMode;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Spots vanished staff/players: a player entity that is rendered in the world but missing from the tab list
 * is hidden by a vanish plugin (real players are always in the list).
 */
public class AntiVanish extends Module {
    private final Setting.Num grace = add(new Setting.Num("Confirm (checks)", 4, 1, 20, 1));
    private final Map<UUID, Integer> missing = new HashMap<>();
    private final Set<UUID> alerted = new HashSet<>();
    private final Setting.Bool spectators = add(new Setting.Bool("Spectator / watcher alert", true));
    private final Setting.Bool flash = add(new Setting.Bool("Screen warning", true));
    private final Setting.Num watchDist = add(new Setting.Num("Watcher distance", 25, 2, 64, 1));
    private final Set<UUID> specAlerted = new HashSet<>();
    private final Set<UUID> watchAlerted = new HashSet<>();
    private long flashAt;
    private String flashText = "";
    private int timer;

    public AntiVanish() {
        super("AntiVanish", "Detects vanished players: visible in the world but absent from the tab list.", Category.MISC);
    }

    @Override
    protected void onEnable() { missing.clear(); alerted.clear(); specAlerted.clear(); watchAlerted.clear(); timer = 0; }

    // GameProfile accessors changed names between versions (getId/id, getName/name): resolve them once by reflection.
    private static Object call(Object o, String a, String b) {
        for (String n : new String[]{a, b}) {
            try { return o.getClass().getMethod(n).invoke(o); } catch (Throwable ignored) { }
        }
        return null;
    }

    private static UUID profileId(Object profile) {
        return call(profile, "id", "getId") instanceof UUID u ? u : new UUID(0, 0);
    }

    private static String profileName(Object profile) {
        Object n = call(profile, "name", "getName");
        return n == null ? "?" : n.toString();
    }

    private void warn(String text) {
        flashText = text;
        flashAt = System.currentTimeMillis();
        ZenithClient.info(text);
    }

    /** Players the tab list marks as spectators, and spectators/invisible players parked right on top of you. */
    private void scanSpectators() {
        Set<UUID> specNow = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) {
            if (en.getGameMode() != GameMode.SPECTATOR) continue;
            UUID id = profileId(en.getProfile());
            if (id.equals(mc.player.getUuid())) continue;
            specNow.add(id);
            if (specAlerted.add(id)) warn("Spectator online: " + profileName(en.getProfile()));
        }
        specAlerted.retainAll(specNow);

        Set<UUID> watchNow = new HashSet<>();
        double wd = watchDist.get();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || mc.player.squaredDistanceTo(e) > wd * wd) continue;
            PlayerListEntry en = mc.getNetworkHandler().getPlayerListEntry(e.getUuid());
            boolean spec = en != null && en.getGameMode() == GameMode.SPECTATOR;
            if (!spec && !e.isInvisible() && en != null) continue; // a normal visible player standing close is just a player
            watchNow.add(e.getUuid());
            if (watchAlerted.add(e.getUuid())) warn(e.getName().getString() + " is watching you!");
        }
        watchAlerted.retainAll(watchNow);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (!flash.get()) return;
        long age = System.currentTimeMillis() - flashAt;
        if (age < 0 || age > 2500) return;
        float fade = 1f - age / 2500f;
        float pulse = 0.55f + 0.45f * (float) Math.sin(age / 85.0);
        int a = (int) (0x90 * fade * pulse);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        int red = 0xE8344F;
        ctx.fillGradient(0, 0, w, h / 4, (a << 24) | red, red);
        ctx.fillGradient(0, h - h / 4, w, h, red, (a << 24) | red);
        String t = "! " + flashText + " !";
        int tw = mc.textRenderer.getWidth(t);
        ctx.drawText(mc.textRenderer, t, w / 2 - tw / 2, h / 5, ((int) (0xFF * Math.min(1f, fade * 2f)) << 24) | 0xFFFFFF, true);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null || timer++ % 10 != 0) return;
        Set<UUID> present = new HashSet<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player) continue;
            UUID id = e.getUuid();
            present.add(id);
            if (mc.getNetworkHandler().getPlayerListEntry(id) != null) { missing.remove(id); alerted.remove(id); continue; }
            int n = missing.merge(id, 1, Integer::sum);
            if (n >= grace.getInt() && alerted.add(id)) {
                warn("Vanished player: " + e.getName().getString() + " at " + (int) e.getX() + ", " + (int) e.getY() + ", " + (int) e.getZ()
                        + " (" + (int) mc.player.distanceTo(e) + "m)");
            }
        }
        if (spectators.get()) scanSpectators();
        missing.keySet().removeIf(id -> !present.contains(id));
        alerted.removeIf(id -> !present.contains(id));
    }
}
