package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.GameMode;
import net.minecraft.network.packet.c2s.play.RequestCommandCompletionsC2SPacket;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Spots vanished staff/players: a player entity that is rendered in the world but missing from the tab list
 * is hidden by a vanish plugin (real players are always in the list).
 */
public class AntiVanish extends Module {
    private final Setting.Num grace = add(new Setting.Num("Confirm (checks)", 4, 1, 20, 1));
    private final Map<UUID, Integer> missing = new HashMap<>();
    private final Set<UUID> alerted = new HashSet<>();
    private final Setting.Bool spectators = add(new Setting.Bool("Spectator / watcher alert", true));
    private final Setting.Bool flash = add(new Setting.Bool("Screen warning", true));
    private final Setting.Num watchDist = add(new Setting.Num("Watcher distance", 25, 2, 64, 1));
    private final Set<UUID> specAlerted = new HashSet<>();
    private final Set<UUID> watchAlerted = new HashSet<>();
    private final Setting.Num crowd = add(new Setting.Num("Crowd limit (quiet above)", 10, 3, 60, 1));
    private UUID watcherId;
    private String watcherName = "";
    private long watcherAt;
    private long flashAt;
    private String flashText = "";
    private final Setting.Bool nameProbe = add(new Setting.Bool("Name probe (tab-complete)", true));
    private static final ConcurrentLinkedQueue<List<String>> INBOUND = new ConcurrentLinkedQueue<>();
    private static volatile long probeUntil;
    private final Map<String, Long> probeAlerted = new HashMap<>();
    private int timer, probeTimer;
    private final Setting.Bool soundSense = add(new Setting.Bool("Sound / particle sensor", true));
    private final Setting.Bool tabSense = add(new Setting.Bool("Silent tab removal", true));
    private record Sig(String kind, String id, double x, double y, double z, long t) { }
    private static final ConcurrentLinkedQueue<Sig> SIGS = new ConcurrentLinkedQueue<>();
    private static volatile boolean live;
    private static volatile long lastLeaveMsg;
    private static final Map<String, Long> LEFT_MSGS = Collections.synchronizedMap(new HashMap<>());
    private final Map<UUID, Long> listedSince = new HashMap<>();
    private final Deque<double[]> weak = new ArrayDeque<>();
    private final Map<Long, Long> areaCooldown = new HashMap<>();
    private long useKeyAt;

    public AntiVanish() {
        super("AntiVanish", "Detects vanished players: visible in the world but absent from the tab list.", Category.MISC);
    }

    @Override
    protected void onDisable() { live = false; SIGS.clear(); }

    @Override
    protected void onEnable() { live = true; SIGS.clear(); listedSince.clear(); weak.clear(); areaCooldown.clear(); INBOUND.clear(); probeAlerted.clear(); probeTimer = 0; missing.clear(); alerted.clear(); specAlerted.clear(); watchAlerted.clear(); timer = 0; }

    // GameProfile accessors changed names between versions (getId/id, getName/name): resolve them once by reflection.
    private static Object call(Object o, String a, String b) {
        for (String n : new String[]{a, b}) {
            try { return o.getClass().getMethod(n).invoke(o); } catch (Throwable ignored) { }
        }
        return null;
    }

    private static UUID profileId(Object profile) {
        return call(profile, "id", "getId") instanceof UUID u ? u : new UUID(0, 0);
    }

    private static String profileName(Object profile) {
        Object n = call(profile, "name", "getName");
        return n == null ? "?" : n.toString();
    }

    /**
     * The server's command completion lists every online player, vanished ones included (vanish plugins only edit
     * the tab list packets). Names that complete but are not in the tab list are hidden players.
     */
    public static void suggestions(List<String> names) {
        if (System.currentTimeMillis() <= probeUntil) INBOUND.add(names);
    }

    private void probeStep() {
        if (!nameProbe.get()) return;
        if (probeTimer++ % 10 == 0 && mc.currentScreen == null) {
            probeUntil = System.currentTimeMillis() + 2500;
            mc.getNetworkHandler().sendPacket(new RequestCommandCompletionsC2SPacket(31337, "/minecraft:msg "));
        }
        Set<String> listed = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) listed.add(profileName(en.getProfile()).toLowerCase());
        String me = mc.player.getName().getString().toLowerCase();
        List<String> names;
        long now = System.currentTimeMillis();
        while ((names = INBOUND.poll()) != null) {
            for (String n : names) {
                String k = n.toLowerCase();
                if (!k.matches("[a-z0-9_]{3,16}") || k.equals(me) || listed.contains(k)) continue;
                Long last = probeAlerted.get(k);
                if (last != null && now - last < 60000) continue;
                probeAlerted.put(k, now);
                warn("Hidden player online: " + n + " (not in tab list)");
            }
        }
    }

    // ---- packet feeds (called from the network handler mixin; netty thread, so only queue here)

    public static void sound(String id, double x, double y, double z) {
        if (live) SIGS.add(new Sig("sound", id, x, y, z, System.currentTimeMillis()));
    }

    public static void particle(String id, double x, double y, double z) {
        if (live) SIGS.add(new Sig("particle", id, x, y, z, System.currentTimeMillis()));
    }

    /** A player disappeared from the tab list: normal quits are announced in chat, vanishes usually are not. */
    public static void tabRemoved(UUID id, Object profile) {
        if (!live) return;
        NAMES.put(id, profile == null ? "?" : profileName(profile));
        SIGS.add(new Sig("tab", id.toString(), 0, 0, 0, System.currentTimeMillis()));
    }

    public static void chat(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        if (!l.contains("left") && !l.contains("quit") && !l.contains("disconnect")) return;
        lastLeaveMsg = System.currentTimeMillis();
        LEFT_MSGS.put(l, lastLeaveMsg);
        if (LEFT_MSGS.size() > 40) LEFT_MSGS.values().removeIf(t -> lastLeaveMsg - t > 10000);
    }

    private static final Map<UUID, String> NAMES = Collections.synchronizedMap(new HashMap<>());

    private static boolean strongSound(String p) {
        return p.contains("chest.open") || p.contains("chest.close") || p.contains("barrel.open") || p.contains("barrel.close")
                || p.contains("shulker_box.open") || p.contains("shulker_box.close") || p.contains("chest.locked");
    }

    private static boolean weakSound(String p) {
        return p.contains("door.open") || p.contains("door.close") || p.contains("fence_gate.") || p.contains("button.click")
                || p.contains("lever.click") || p.contains("trapdoor.");
    }

    /** True when a real player, villager or similar is standing near the spot, so the noise has a visible cause. */
    private boolean visibleCause(double x, double y, double z, double r) {
        net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(x - r, y - r, z - r, x + r, y + r, z + r);
        for (net.minecraft.entity.Entity e : mc.world.getOtherEntities(null, box)) {
            if (e instanceof net.minecraft.entity.LivingEntity le && !le.isInvisible()) return true;
        }
        return false;
    }

    private void alertArea(String what, double x, double y, double z) {
        long cell = ((long) Math.floor(x / 6) << 40) ^ ((long) Math.floor(z / 6) << 16) ^ (long) Math.floor(y / 6);
        long now = System.currentTimeMillis();
        Long last = areaCooldown.get(cell);
        if (last != null && now - last < 20000) return;
        areaCooldown.put(cell, now);
        warn("Hidden player " + what + " near " + (int) x + ", " + (int) y + ", " + (int) z + " (" + (int) mc.player.getEyePos().distanceTo(new Vec3d(x, y, z)) + "m)");
    }

    /** Sounds and particles that no visible entity can explain, plus tab removals without a quit message. */
    private void processSignals() {
        long now = System.currentTimeMillis();
        if (mc.options.useKey.isPressed() || mc.options.attackKey.isPressed()) useKeyAt = now;
        Sig sg;
        while ((sg = SIGS.poll()) != null) {
            if (now - sg.t() > 4000 || crowded()) continue;
            if (sg.kind().equals("tab")) {
                if (!tabSense.get()) continue;
                UUID id = UUID.fromString(sg.id());
                Long since = listedSince.get(id);
                String name = NAMES.getOrDefault(id, "?");
                if (since == null || now - since < 8000 || LEFT_MSGS.isEmpty()) continue; // join flicker / server never prints quits
                boolean announced = false;
                String ln = name.toLowerCase(Locale.ROOT);
                for (Map.Entry<String, Long> e : LEFT_MSGS.entrySet()) {
                    if (e.getKey().contains(ln) && Math.abs(e.getValue() - sg.t()) < 4000) announced = true;
                }
                if (!announced) {
                    // wait a moment: the quit line can arrive right after the list packet
                    pendingTab.put(id, new Object[]{name, sg.t()});
                }
                continue;
            }
            if (!soundSense.get()) continue;
            double dx = sg.x() - mc.player.getX(), dy = sg.y() - mc.player.getY(), dz = sg.z() - mc.player.getZ();
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            boolean mine = d < 8 && now - useKeyAt < 2500;
            if (sg.kind().equals("sound")) {
                String p = sg.id();
                if (mine) continue;
                if (strongSound(p) && !visibleCause(sg.x(), sg.y(), sg.z(), 6)) {
                    alertArea("opened a container", sg.x(), sg.y(), sg.z());
                } else if (weakSound(p) && !visibleCause(sg.x(), sg.y(), sg.z(), 10)) {
                    weak.addLast(new double[]{now, sg.x(), sg.y(), sg.z()});
                    while (!weak.isEmpty() && now - weak.peekFirst()[0] > 12000) weak.pollFirst();
                    int near = 0;
                    for (double[] w : weak) if (Math.abs(w[1] - sg.x()) < 8 && Math.abs(w[3] - sg.z()) < 8) near++;
                    if (near >= 3) { alertArea("is using doors/levers", sg.x(), sg.y(), sg.z()); weak.clear(); }
                }
            } else if (sg.id().equals("enchanted_hit") || sg.id().equals("damage_indicator")) {
                if (mine || visibleCause(sg.x(), sg.y(), sg.z(), 4)) continue;
                weak.addLast(new double[]{now, sg.x(), sg.y(), sg.z()});
                while (!weak.isEmpty() && now - weak.peekFirst()[0] > 3000) weak.pollFirst();
                if (weak.size() >= 2) { alertArea("is fighting", sg.x(), sg.y(), sg.z()); weak.clear(); }
            }
        }
        if (!pendingTab.isEmpty()) {
            Iterator<Map.Entry<UUID, Object[]>> it = pendingTab.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Object[]> e = it.next();
                long t = (Long) e.getValue()[1];
                if (now - t < 1500) continue;
                it.remove();
                String ln = ((String) e.getValue()[0]).toLowerCase(Locale.ROOT);
                boolean announced = false;
                for (Map.Entry<String, Long> m : LEFT_MSGS.entrySet()) {
                    if (m.getKey().contains(ln) && Math.abs(m.getValue() - t) < 4000) announced = true;
                }
                if (!announced) warn("Vanished: " + e.getValue()[0] + " left the tab list without a quit message");
            }
        }
    }

    private final Map<UUID, Object[]> pendingTab = new HashMap<>();

    /** Busy places (spawn) are full of AFK admins: stay silent when many players are loaded around you. */
    private boolean crowded() {
        return mc.world != null && mc.world.getPlayers().size() - 1 > crowd.getInt();
    }

    private void warnWatcher(UUID id, String name) {
        if (crowded()) return;
        watcherId = id;
        watcherName = name;
        watcherAt = System.currentTimeMillis();
        titleSent = false;
        warn(name + " is watching you!");
    }

    private void warn(String text) {
        if (crowded()) return;
        flashText = text;
        flashAt = System.currentTimeMillis();
        ZenithClient.info(text);
    }

    /** Players the tab list marks as spectators, and spectators/invisible players parked right on top of you. */
    private void scanSpectators() {
        Set<UUID> specNow = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) {
            if (en.getGameMode() != GameMode.SPECTATOR) continue;
            UUID id = profileId(en.getProfile());
            if (id.equals(mc.player.getUuid())) continue;
            specNow.add(id);
            if (specAlerted.add(id)) warn("Spectator online: " + profileName(en.getProfile()));
        }
        specAlerted.retainAll(specNow);

        Set<UUID> watchNow = new HashSet<>();
        double wd = watchDist.get();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || mc.player.squaredDistanceTo(e) > wd * wd) continue;
            PlayerListEntry en = mc.getNetworkHandler().getPlayerListEntry(e.getUuid());
            boolean spec = en != null && en.getGameMode() == GameMode.SPECTATOR;
            if (!spec && !e.isInvisible() && en != null) continue; // a normal visible player standing close is just a player
            watchNow.add(e.getUuid());
            if (watchAlerted.add(e.getUuid())) warnWatcher(e.getUuid(), e.getName().getString());
        }
        watchAlerted.retainAll(watchNow);
    }

    /** Elder-guardian style jump scare: the watcher's head pops up in the middle of the screen with their name. */
    private static final float[][] FACES = {
            // u, v, corner A (xyz), corner B (xyz, along the texture's u), corner C (xyz, along v), shade
            {8, 8, -1, 1, 1, 1, 1, 1, -1, -1, 1, 1.0f},
            {0, 8, -1, 1, -1, -1, 1, 1, -1, -1, -1, 0.8f},
            {16, 8, 1, 1, 1, 1, 1, -1, 1, -1, 1, 0.8f},
            {8, 0, -1, 1, -1, 1, 1, -1, -1, 1, 1, 0.95f},
            {16, 0, -1, -1, 1, 1, -1, 1, -1, -1, -1, 0.6f},
    };
    private static final float HALF_FOV_TAN = (float) Math.tan(Math.toRadians(35));
    private boolean titleSent;

    /** The skin's texture id: record accessor names differ between mappings, so pick the body skin by shape. */
    private static net.minecraft.util.Identifier skinId(Object textures) {
        if (textures == null) return null;
        net.minecraft.util.Identifier best = null;
        for (java.lang.reflect.Method m : textures.getClass().getMethods()) {
            if (m.getParameterCount() != 0 || m.getReturnType() != net.minecraft.util.Identifier.class) continue;
            try {
                net.minecraft.util.Identifier id = (net.minecraft.util.Identifier) m.invoke(textures);
                if (id == null) continue;
                String p = id.getPath();
                if (p.contains("cape") || p.contains("elytra")) continue;
                best = id;
                if (p.contains("skin") || p.contains("player")) break;
            } catch (Throwable ignored) { }
        }
        return best;
    }

    /** One cube corner: scale, lift it, push it away from the camera, then swing it about the camera's x axis. */
    private static void corner(float[] f, int i, float s, float cosA, float sinA, float[] out) {
        float x = f[i] * s, y = f[i + 1] * s + 0.24f, z = f[i + 2] * s - 1.49f;
        out[0] = x;
        out[1] = y * cosA - z * sinA;
        out[2] = y * sinA + z * cosA;
    }

    /**
     * Ported from the Anubis "StaffGhost" cube: five faces, each cut into 8x8 texels that are projected one by one
     * (a face texel is exactly one skin pixel), back faces skipped, shaded per face, drawn with the given alpha.
     */
    private void drawCube(DrawContext ctx, net.minecraft.util.Identifier tex, float half, float uOff,
                          float cosA, float sinA, float w, float h, float focal, float alpha) {
        var m = ctx.getMatrices();
        float[] a = new float[3], b = new float[3], c = new float[3];
        float[] gx = new float[81], gy = new float[81];
        boolean[] ok = new boolean[81];
        int alp = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f);
        for (float[] f : FACES) {
            corner(f, 2, half, cosA, sinA, a);
            corner(f, 5, half, cosA, sinA, b);
            corner(f, 8, half, cosA, sinA, c);
            float dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
            float ex = c[0] - a[0], ey = c[1] - a[1], ez = c[2] - a[2];
            float nx = dy * ez - dz * ey, ny = dz * ex - dx * ez, nz = dx * ey - dy * ex;
            float mx = a[0] + (dx + ex) * 0.5f, my = a[1] + (dy + ey) * 0.5f, mz = a[2] + (dz + ez) * 0.5f;
            if (nx * mx + ny * my + nz * mz <= 0f) continue;                       // facing away
            if (a[2] > -0.08f && b[2] > -0.08f && c[2] > -0.08f && a[2] + dz + ez > -0.08f) continue; // behind the camera
            for (int r = 0; r <= 8; r++) {
                for (int q = 0; q <= 8; q++) {
                    float fq = q / 8f, fr = r / 8f;
                    float X = a[0] + dx * fq + ex * fr, Y = a[1] + dy * fq + ey * fr, Z = a[2] + dz * fq + ez * fr;
                    int k = r * 9 + q;
                    ok[k] = Z < -0.05f;
                    if (ok[k]) {
                        gx[k] = w * 0.5f + X / -Z * focal;
                        gy[k] = h * 0.5f - Y / -Z * focal;
                    }
                }
            }
            int g = Math.round(f[11] * 255f);
            int color = (alp << 24) | (g << 16) | (g << 8) | g;
            for (int r = 0; r < 8; r++) {
                for (int q = 0; q < 8; q++) {
                    int k = r * 9 + q, k1 = k + 1, k2 = k + 9;
                    if (!ok[k] || !ok[k1] || !ok[k2]) continue;
                    m.pushMatrix();
                    m.mul(new org.joml.Matrix3x2f(gx[k1] - gx[k], gy[k1] - gy[k], gx[k2] - gx[k], gy[k2] - gy[k], gx[k], gy[k]));
                    ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, tex, 0, 0,
                            f[0] + uOff + q, f[1] + r, 1, 1, 1, 1, 64, 64, color);
                    m.popMatrix();
                }
            }
        }
    }

    /**
     * Watcher animation, ported from Anubis: for 1.5 s the watcher's head (a skinned cube, hat layer included)
     * swings down through the view as a see-through ghost; at 1.25 s the vanilla title "WATCHING YOU" with the
     * watcher's name fades in (10 / 40 / 15 ticks).
     */
    private void drawWatcher(DrawContext ctx) {
        long a = System.currentTimeMillis() - watcherAt;
        if (watcherId == null || a < 0) return;
        if (a >= 1250 && !titleSent) {
            titleSent = true;
            var hud = mc.inGameHud;
            hud.setTitleTicks(10, 40, 15);
            hud.setTitle(net.minecraft.text.Text.literal("WATCHING YOU").styled(st -> st.withBold(true).withColor(0xFF3344)));
            hud.setSubtitle(net.minecraft.text.Text.literal(watcherName));
        }
        if (a >= 1500) return;
        float t = a / 1500f;
        var handler = mc.getNetworkHandler();
        var entry = handler == null ? null : handler.getPlayerListEntry(watcherId);
        net.minecraft.util.Identifier tex = entry == null ? null : skinId(entry.getSkinTextures());
        if (tex == null) return;
        float swell = 0.05f + 0.6f * (float) Math.sin(t * Math.PI);
        double ang = Math.toRadians(60.0 - 150.0 * t);
        float cos = (float) Math.cos(ang), sin = (float) Math.sin(ang);
        float w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float focal = h * 0.5f / HALF_FOV_TAN;
        drawCube(ctx, tex, 0.45f, 0f, cos, sin, w, h, focal, swell);
        drawCube(ctx, tex, 0.50625f, 32f, cos, sin, w, h, focal, swell);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (!flash.get()) return;
        drawWatcher(ctx);
        long age = System.currentTimeMillis() - flashAt;
        if (age < 0 || age > 2500) return;
        float fade = 1f - age / 2500f;
        float pulse = 0.55f + 0.45f * (float) Math.sin(age / 85.0);
        int a = (int) (0x90 * fade * pulse);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        int red = 0xE8344F;
        ctx.fillGradient(0, 0, w, h / 4, (a << 24) | red, red);
        ctx.fillGradient(0, h - h / 4, w, h, red, (a << 24) | red);
        String t = "! " + flashText + " !";
        int tw = mc.textRenderer.getWidth(t);
        if (watcherId == null || System.currentTimeMillis() - watcherAt > 5000) // the watcher title already says it
            ctx.drawText(mc.textRenderer, t, w / 2 - tw / 2, h / 5, ((int) (0xFF * Math.min(1f, fade * 2f)) << 24) | 0xFFFFFF, true);
    }

    @Override
    public void onTick() {
        if (mc.world != null && mc.player != null) {
            processSignals();
            if (timer % 20 == 0 && mc.getNetworkHandler() != null) {
                long now = System.currentTimeMillis();
                Set<UUID> inTab = new HashSet<>();
                for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) {
                    UUID pid = profileId(en.getProfile());
                    inTab.add(pid);
                    listedSince.putIfAbsent(pid, now);
                }
                listedSince.keySet().removeIf(k -> !inTab.contains(k) && now - listedSince.get(k) > 15000);
            }
        }
        if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null || timer++ % 10 != 0) return;
        Set<UUID> present = new HashSet<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player) continue;
            UUID id = e.getUuid();
            present.add(id);
            if (mc.getNetworkHandler().getPlayerListEntry(id) != null) { missing.remove(id); alerted.remove(id); continue; }
            int n = missing.merge(id, 1, Integer::sum);
            if (n >= grace.getInt() && alerted.add(id)) {
                warn("Vanished player: " + e.getName().getString() + " at " + (int) e.getX() + ", " + (int) e.getY() + ", " + (int) e.getZ()
                        + " (" + (int) mc.player.distanceTo(e) + "m)");
            }
        }
        if (spectators.get()) scanSpectators();
        probeStep();
        missing.keySet().removeIf(id -> !present.contains(id));
        alerted.removeIf(id -> !present.contains(id));
    }
}
