package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.GameMode;
import net.minecraft.network.packet.c2s.play.RequestCommandCompletionsC2SPacket;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Spots vanished staff/players: a player entity that is rendered in the world but missing from the tab list
 * is hidden by a vanish plugin (real players are always in the list).
 */
public class AntiVanish extends Module {
    private final Setting.Num grace = add(new Setting.Num("Confirm (checks)", 4, 1, 20, 1));
    private final Map<UUID, Integer> missing = new HashMap<>();
    private final Set<UUID> alerted = new HashSet<>();
    private final Setting.Bool spectators = add(new Setting.Bool("Spectator / watcher alert", true));
    private final Setting.Bool flash = add(new Setting.Bool("Screen warning", true));
    private final Setting.Num watchDist = add(new Setting.Num("Watcher distance", 25, 2, 64, 1));
    private final Set<UUID> specAlerted = new HashSet<>();
    private final Set<UUID> watchAlerted = new HashSet<>();
    private final Setting.Num crowd = add(new Setting.Num("Crowd limit (quiet above)", 10, 3, 60, 1));
    private UUID watcherId;
    private String watcherName = "";
    private long watcherAt;
    private long flashAt;
    private String flashText = "";
    private final Setting.Bool nameProbe = add(new Setting.Bool("Name probe (tab-complete)", true));
    private static final ConcurrentLinkedQueue<List<String>> INBOUND = new ConcurrentLinkedQueue<>();
    private static volatile long probeUntil;
    private final Map<String, Long> probeAlerted = new HashMap<>();
    private int timer, probeTimer;

    public AntiVanish() {
        super("AntiVanish", "Detects vanished players: visible in the world but absent from the tab list.", Category.MISC);
    }

    @Override
    protected void onEnable() { INBOUND.clear(); probeAlerted.clear(); probeTimer = 0; missing.clear(); alerted.clear(); specAlerted.clear(); watchAlerted.clear(); timer = 0; }

    // GameProfile accessors changed names between versions (getId/id, getName/name): resolve them once by reflection.
    private static Object call(Object o, String a, String b) {
        for (String n : new String[]{a, b}) {
            try { return o.getClass().getMethod(n).invoke(o); } catch (Throwable ignored) { }
        }
        return null;
    }

    private static UUID profileId(Object profile) {
        return call(profile, "id", "getId") instanceof UUID u ? u : new UUID(0, 0);
    }

    private static String profileName(Object profile) {
        Object n = call(profile, "name", "getName");
        return n == null ? "?" : n.toString();
    }

    /**
     * The server's command completion lists every online player, vanished ones included (vanish plugins only edit
     * the tab list packets). Names that complete but are not in the tab list are hidden players.
     */
    public static void suggestions(List<String> names) {
        if (System.currentTimeMillis() <= probeUntil) INBOUND.add(names);
    }

    private void probeStep() {
        if (!nameProbe.get()) return;
        if (probeTimer++ % 10 == 0 && mc.currentScreen == null) {
            probeUntil = System.currentTimeMillis() + 2500;
            mc.getNetworkHandler().sendPacket(new RequestCommandCompletionsC2SPacket(31337, "/minecraft:msg "));
        }
        Set<String> listed = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) listed.add(profileName(en.getProfile()).toLowerCase());
        String me = mc.player.getName().getString().toLowerCase();
        List<String> names;
        long now = System.currentTimeMillis();
        while ((names = INBOUND.poll()) != null) {
            for (String n : names) {
                String k = n.toLowerCase();
                if (!k.matches("[a-z0-9_]{3,16}") || k.equals(me) || listed.contains(k)) continue;
                Long last = probeAlerted.get(k);
                if (last != null && now - last < 60000) continue;
                probeAlerted.put(k, now);
                warn("Hidden player online: " + n + " (not in tab list)");
            }
        }
    }

    /** Busy places (spawn) are full of AFK admins: stay silent when many players are loaded around you. */
    private boolean crowded() {
        return mc.world != null && mc.world.getPlayers().size() - 1 > crowd.getInt();
    }

    private void warnWatcher(UUID id, String name) {
        if (crowded()) return;
        watcherId = id;
        watcherName = name;
        watcherAt = System.currentTimeMillis();
        warn(name + " is watching you!");
    }

    private void warn(String text) {
        if (crowded()) return;
        flashText = text;
        flashAt = System.currentTimeMillis();
        ZenithClient.info(text);
    }

    /** Players the tab list marks as spectators, and spectators/invisible players parked right on top of you. */
    private void scanSpectators() {
        Set<UUID> specNow = new HashSet<>();
        for (PlayerListEntry en : mc.getNetworkHandler().getPlayerList()) {
            if (en.getGameMode() != GameMode.SPECTATOR) continue;
            UUID id = profileId(en.getProfile());
            if (id.equals(mc.player.getUuid())) continue;
            specNow.add(id);
            if (specAlerted.add(id)) warn("Spectator online: " + profileName(en.getProfile()));
        }
        specAlerted.retainAll(specNow);

        Set<UUID> watchNow = new HashSet<>();
        double wd = watchDist.get();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || mc.player.squaredDistanceTo(e) > wd * wd) continue;
            PlayerListEntry en = mc.getNetworkHandler().getPlayerListEntry(e.getUuid());
            boolean spec = en != null && en.getGameMode() == GameMode.SPECTATOR;
            if (!spec && !e.isInvisible() && en != null) continue; // a normal visible player standing close is just a player
            watchNow.add(e.getUuid());
            if (watchAlerted.add(e.getUuid())) warnWatcher(e.getUuid(), e.getName().getString());
        }
        watchAlerted.retainAll(watchNow);
    }

    /** Elder-guardian style jump scare: the watcher's head pops up in the middle of the screen with their name. */
    private void drawWatcher(DrawContext ctx) {
        long a = System.currentTimeMillis() - watcherAt;
        if (watcherId == null || a < 0 || a > 3600) return;
        float t = a / 3600f;
        float in = Math.min(1f, a / 220f);
        float out = t > 0.75f ? (1f - t) / 0.25f : 1f;
        float alpha = in * out;
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        ctx.fill(0, 0, w, h, ((int) (0x70 * alpha) << 24) | 0x2A0006); // blood-dark veil
        float pulse = 1f + 0.07f * (float) Math.sin(a / 85.0);
        float scale = 3.0f * alpha * pulse;
        float shakeX = (float) Math.sin(a / 31.0) * 3f * (1f - t), shakeY = (float) Math.cos(a / 27.0) * 3f * (1f - t);
        if (scale < 0.05f) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(w / 2f + shakeX, h / 2f + shakeY);
        m.scale(scale, scale);
        var entry = mc.getNetworkHandler().getPlayerListEntry(watcherId);
        if (entry != null) net.minecraft.client.gui.PlayerSkinDrawer.draw(ctx, entry.getSkinTextures(), -16, -16, 32);
        else {
            ctx.fill(-16, -16, 16, 16, 0xFF5A0A14);
            ctx.drawText(mc.textRenderer, "?", -2, -4, 0xFFFFFFFF, true);
        }
        m.popMatrix();
        m.pushMatrix();
        m.translate(w / 2f, h / 2f - 16 * scale - 14);
        float ts = 1.8f * Math.min(1f, alpha * 1.4f);
        m.scale(ts, ts);
        int nw = mc.textRenderer.getWidth(watcherName);
        ctx.drawText(mc.textRenderer, watcherName, -nw / 2, -4, 0xFFFF4D5E, true);
        m.popMatrix();
        String sub = "is watching you";
        int sw = mc.textRenderer.getWidth(sub);
        ctx.drawText(mc.textRenderer, sub, w / 2 - sw / 2, (int) (h / 2f + 16 * scale + 8), ((int) (0xFF * alpha) << 24) | 0xFFB8BE, true);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (!flash.get()) return;
        drawWatcher(ctx);
        long age = System.currentTimeMillis() - flashAt;
        if (age < 0 || age > 2500) return;
        float fade = 1f - age / 2500f;
        float pulse = 0.55f + 0.45f * (float) Math.sin(age / 85.0);
        int a = (int) (0x90 * fade * pulse);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        int red = 0xE8344F;
        ctx.fillGradient(0, 0, w, h / 4, (a << 24) | red, red);
        ctx.fillGradient(0, h - h / 4, w, h, red, (a << 24) | red);
        String t = "! " + flashText + " !";
        int tw = mc.textRenderer.getWidth(t);
        ctx.drawText(mc.textRenderer, t, w / 2 - tw / 2, h / 5, ((int) (0xFF * Math.min(1f, fade * 2f)) << 24) | 0xFFFFFF, true);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null || timer++ % 10 != 0) return;
        Set<UUID> present = new HashSet<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player) continue;
            UUID id = e.getUuid();
            present.add(id);
            if (mc.getNetworkHandler().getPlayerListEntry(id) != null) { missing.remove(id); alerted.remove(id); continue; }
            int n = missing.merge(id, 1, Integer::sum);
            if (n >= grace.getInt() && alerted.add(id)) {
                warn("Vanished player: " + e.getName().getString() + " at " + (int) e.getX() + ", " + (int) e.getY() + ", " + (int) e.getZ()
                        + " (" + (int) mc.player.distanceTo(e) + "m)");
            }
        }
        if (spectators.get()) scanSpectators();
        probeStep();
        missing.keySet().removeIf(id -> !present.contains(id));
        alerted.removeIf(id -> !present.contains(id));
    }
}
