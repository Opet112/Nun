package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.*;

/** Counts and announces every totem a player pops (yours too). */
public class PopCounter extends Module {
    private final Setting.Bool self = add(new Setting.Bool("Include yourself", true));
    private final Setting.Num maxDist = add(new Setting.Num("Max distance", 80, 10, 300, 10));
    private static final Map<UUID, Integer> COUNTS = new HashMap<>();

    public PopCounter() {
        super("PopCounter", "Announces totem pops in chat with a running count per player.", Category.COMBAT);
    }

    @Override
    protected void onEnable() { COUNTS.clear(); }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        COUNTS.keySet().removeIf(id -> {
            PlayerEntity e = mc.world.getPlayerByUuid(id);
            return e != null && e.getHealth() <= 0; // died: start fresh next fight
        });
    }

    /** Called from the packet mixin on the game thread. */
    public static void popped(Entity e) {
        if (!(e instanceof PlayerEntity p)) return;
        PopCounter m = ZenithClient.modules().get(PopCounter.class);
        if (m == null || !m.isEnabled() || m.mc.player == null) return;
        boolean me = p == m.mc.player;
        if (me && !m.self.get()) return;
        if (!me && m.mc.player.distanceTo(p) > m.maxDist.get()) return;
        int n = COUNTS.merge(p.getUuid(), 1, Integer::sum);
        ZenithClient.info((me ? "You" : p.getName().getString()) + " popped " + n + (n == 1 ? " totem" : " totems"));
    }
}
