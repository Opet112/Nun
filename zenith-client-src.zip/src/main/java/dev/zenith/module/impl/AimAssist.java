package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.RotationManager;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class AimAssist extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 5.0, 2.0, 8.0, 0.5));
    private final Setting.Num fov = add(new Setting.Num("FOV", 90, 10, 360, 5));
    private final Setting.Num speed = add(new Setting.Num("Smoothing", 0.25, 0.05, 1.0, 0.05));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", false));
    private final Setting.Bool onlyAttacking = add(new Setting.Bool("Only when attacking", true));

    public AimAssist() {
        super("AimAssist", "Smoothly nudges your aim towards nearby targets.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (onlyAttacking.get() && !mc.options.attackKey.isPressed()) return;

        LivingEntity best = null;
        double bestAngle = fov.get() / 2.0;
        float[] bestRot = null;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStandEntity) continue;
            if (EntityUtil.isFriend(e)) continue;
            boolean ok = (e instanceof PlayerEntity && players.get()) || (e instanceof HostileEntity && hostiles.get());
            if (!ok || p.distanceTo(le) > range.get()) continue;
            float[] rot = EntityUtil.rotationsTo(p, le.getBoundingBox().getCenter());
            double angle = Math.abs(MathHelper.wrapDegrees(rot[0] - p.getYaw()));
            if (angle < bestAngle) { bestAngle = angle; best = le; bestRot = rot; }
        }
        if (best == null) return;
        float s = speed.getFloat();
        float dy = MathHelper.wrapDegrees(bestRot[0] - p.getYaw()) * s;
        float dp = (bestRot[1] - p.getPitch()) * s;
        float[] n = RotationManager.step(p.getYaw(), p.getPitch(), p.getYaw() + dy, p.getPitch() + dp, 25f, true);
        p.setYaw(n[0]);
        p.setPitch(n[1]);
    }
}
