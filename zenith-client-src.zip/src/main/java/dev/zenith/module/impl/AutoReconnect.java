package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

public class AutoReconnect extends Module {
    private static ServerInfo last;
    private final Setting.Num delay = add(new Setting.Num("Delay (s)", 5, 1, 30, 1));
    private int timer;

    public AutoReconnect() {
        super("AutoReconnect", "Reconnects to the last server after being disconnected.", Category.MISC);
    }

    public static void remember(ServerInfo info) {
        if (info != null) last = info;
    }

    @Override
    public void onAlwaysTick() {
        if (!(mc.currentScreen instanceof DisconnectedScreen) || last == null) { timer = 0; return; }
        if (++timer >= delay.getInt() * 20) {
            timer = 0;
            ConnectScreen.connect(new TitleScreen(), mc, ServerAddress.parse(last.address), last, false, null);
        }
    }
}
