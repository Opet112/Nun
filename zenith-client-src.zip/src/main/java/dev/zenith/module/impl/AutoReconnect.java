package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

public class AutoReconnect extends Module {
    private static ServerInfo last;
    private final Setting.Num delay = add(new Setting.Num("Delay (s)", 5, 1, 30, 1));
    private final Setting.Num maxTries = add(new Setting.Num("Max attempts (0 = endless)", 0, 0, 50, 1));
    private final Setting.Bool backoff = add(new Setting.Bool("Wait longer each try", true));
    private int timer, tries;

    public AutoReconnect() {
        super("AutoReconnect", "Reconnects to the last server after being disconnected.", Category.MISC);
    }

    public static void remember(ServerInfo info) {
        if (info != null) last = info;
    }

    @Override
    public void onAlwaysTick() {
        if (mc.world != null) tries = 0; // connected again
        if (!(mc.currentScreen instanceof DisconnectedScreen) || last == null) { timer = 0; return; }
        if (maxTries.getInt() > 0 && tries >= maxTries.getInt()) return;
        int wait = delay.getInt() * 20 * (backoff.get() ? 1 + Math.min(tries, 6) : 1);
        if (++timer >= wait) {
            timer = 0;
            tries++;
            ConnectScreen.connect(new TitleScreen(), mc, ServerAddress.parse(last.address), last, false, null);
        }
    }
}
