package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class Criticals extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Legit", "Legit", "Packet"));

    public Criticals() {
        super("Criticals", "Turns attacks from KillAura/TriggerBot/AutoClicker into critical hits using packets.", Category.COMBAT);
    }

    /**
     * Legit mode: instead of spoofing packets (the most commonly flagged thing), the attack is simply held back
     * while you are rising from a jump and released once you are falling, which is a real critical hit.
     */
    public static boolean shouldWait() {
        Criticals c = ZenithClient.modules().get(Criticals.class);
        if (c == null || !c.isEnabled() || !c.mode.is("Legit")) return false;
        var p = mc.player;
        if (p == null || p.isOnGround() || p.isTouchingWater() || p.isClimbing() || p.isGliding()) return false;
        return p.getVelocity().y > -0.05; // still going up: wait for the fall
    }

    /** Call right before sending an attack. */
    public static void apply() {
        Criticals c = ZenithClient.modules().get(Criticals.class);
        if (c == null || !c.isEnabled() || !c.mode.is("Packet")) return;
        var p = mc.player;
        var handler = mc.getNetworkHandler();
        if (p == null || handler == null || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        handler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, p.horizontalCollision));
        handler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, p.horizontalCollision));
    }
}
