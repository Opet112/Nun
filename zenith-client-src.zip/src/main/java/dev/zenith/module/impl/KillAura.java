package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Attacks only when the rotation the server already knows points at the target, the weapon is charged
 * (with a randomised threshold) and - optionally - the target is visible. Rotations are speed limited
 * and quantised to the mouse GCD (see RotationManager).
 */
public class KillAura extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 3.0, 1.0, 6.0, 0.1));
    private final Setting.Mode priority = add(new Setting.Mode("Priority", "Distance", "Distance", "Health"));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", false));
    private final Setting.Mode rotate = add(new Setting.Mode("Rotation", "Silent", "None", "Client", "Silent"));
    private final Setting.Num rotSpeed = add(new Setting.Num("Rotation speed", 55, 10, 180, 5));
    private final Setting.Bool gcd = add(new Setting.Bool("GCD fix", true));
    private final Setting.Bool lookCheck = add(new Setting.Bool("Only hit when looking", true));
    private final Setting.Bool walls = add(new Setting.Bool("Through walls", false));
    private final Setting.Num cooldown = add(new Setting.Num("Charge", 0.92, 0.5, 1.0, 0.01));
    private final Setting.Bool randomize = add(new Setting.Bool("Randomize", true));
    private final Setting.Bool sticky = add(new Setting.Bool("Stick to target", true));
    private final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon only", false));
    private final Setting.Bool ignoreInvisible = add(new Setting.Bool("Ignore invisible", false));
    private final Setting.Num reaction = add(new Setting.Num("Reaction (ticks)", 3, 0, 10, 1));
    private final Setting.Num missChance = add(new Setting.Num("Miss chance %", 4, 0, 30, 1));
    private final Setting.Bool pauseUsing = add(new Setting.Bool("Pause while using item", true));
    private LivingEntity current, lastSeen;
    private int acquired;

    private final Random rng = new Random();
    private float threshold = 0.92f;

    public KillAura() {
        super("KillAura", "Automatically attacks nearby entities.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || p == null || mc.interactionManager == null) return;

        if (weaponOnly.get()) {
            var held = p.getMainHandStack();
            if (!(held.isIn(net.minecraft.registry.tag.ItemTags.SWORDS) || held.isIn(net.minecraft.registry.tag.ItemTags.AXES)
                    || held.isOf(net.minecraft.item.Items.MACE) || held.isOf(net.minecraft.item.Items.TRIDENT))) { current = null; return; }
        }
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        // keep the previous target while it is still valid, so we do not flick between players
        if (sticky.get() && current != null && current.isAlive() && !current.isRemoved() && valid(current)
                && !EntityUtil.isFriend(current) && p.distanceTo(current) <= range.get() + 0.5
                && (walls.get() || p.canSee(current))) {
            best = current;
            bestScore = -1;
        }
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStandEntity) continue;
            if (bestScore < 0) break;
            if (EntityUtil.isFriend(le) || !valid(le)) continue;
            if (ignoreInvisible.get() && le.isInvisible()) continue;
            double dist = p.distanceTo(le);
            if (dist > range.get() + 0.5) continue;
            if (!walls.get() && !p.canSee(le)) continue;
            double score = priority.is("Health") ? le.getHealth() : dist;
            if (score < bestScore) { bestScore = score; best = le; }
        }
        current = best;
        if (best == null) { lastSeen = null; return; }
        if (best != lastSeen) { lastSeen = best; acquired = 0; }
        acquired++;

        Box box = best.getBoundingBox();
        Vec3d aim = EntityUtil.aimPoint(p, box);
        double reach = range.get();
        boolean onTarget;

        if (rotate.is("Silent")) {
            onTarget = RotationManager.aim(p, box, aim, reach, rotSpeed.getFloat(), gcd.get());
        } else if (rotate.is("Client")) {
            onTarget = RotationManager.lookingAt(p, p.getYaw(), p.getPitch(), box, reach);
            float[] want = EntityUtil.rotationsTo(p, aim);
            float[] n = RotationManager.step(p.getYaw(), p.getPitch(), want[0], want[1], rotSpeed.getFloat(), gcd.get());
            p.setYaw(n[0]);
            p.setPitch(n[1]);
        } else {
            onTarget = RotationManager.lookingAt(p, p.getYaw(), p.getPitch(), box, reach);
        }

        if (pauseUsing.get() && p.isUsingItem()) return;
        if (acquired <= reaction.getInt()) return; // a human needs a moment to react to a new target
        if (p.distanceTo(best) > reach) return;
        if (lookCheck.get() && !onTarget) return;
        if (p.getAttackCooldownProgress(0.5f) < threshold) return;

        threshold = cooldown.getFloat() + (randomize.get() ? (rng.nextFloat() - 0.5f) * 0.08f : 0f);
        threshold = Math.min(threshold, 1.0f);
        if (rng.nextInt(100) < missChance.getInt()) return; // skip an occasional swing

        if (Criticals.shouldWait()) return;
        Criticals.apply();
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }

    private boolean valid(LivingEntity e) {
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof HostileEntity) return hostiles.get();
        if (e instanceof AnimalEntity) return animals.get();
        return false;
    }

    @Override
    public String getSuffix() { return rotate.get(); }
}
