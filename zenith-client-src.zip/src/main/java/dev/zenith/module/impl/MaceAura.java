package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** Smash attacks: while falling onto a player with a mace in the hotbar, aims and hits for the big fall bonus. */
public class MaceAura extends Module {
    private final Setting.Num reach = add(new Setting.Num("Reach", 3.0, 2, 4.5, 0.1));
    private final Setting.Num minFall = add(new Setting.Num("Min fall speed", 0.55, 0.2, 2.0, 0.05));
    private final Setting.Num range = add(new Setting.Num("Target range", 6, 3, 12, 0.5));
    private final Setting.Bool visibleOnly = add(new Setting.Bool("Only visible targets", true));
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));

    public MaceAura() {
        super("MaceAura", "Auto smash attack with a mace while falling.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.isOnGround() || p.getVelocity().y > -minFall.get()) return;
        PlayerEntity t = EntityUtil.nearestPlayer(range.get());
        if (t == null || (visibleOnly.get() && !p.canSee(t))) return;
        int mace = InventoryUtil.findHotbar(Items.MACE);
        if (mace < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        InventoryUtil.select(mace);
        boolean on = RotationManager.aim(p, t.getBoundingBox(), EntityUtil.aimPoint(p, t.getBoundingBox()), reach.get(), 70f, true);
        if (on && p.getEyePos().distanceTo(EntityUtil.aimPoint(p, t.getBoundingBox())) <= reach.get()) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            if (switchBack.get()) InventoryUtil.select(prev);
        }
    }
}
