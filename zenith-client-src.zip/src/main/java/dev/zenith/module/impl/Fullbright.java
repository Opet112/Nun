package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    private boolean added;

    public Fullbright() {
        super("Fullbright", "See in the dark (client-side night vision).", Category.RENDER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        StatusEffectInstance current = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || (added && current.getDuration() < 400)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            added = true;
        }
        // a real potion with a long duration is left alone
    }

    @Override
    protected void onDisable() {
        // only remove the effect we gave ourselves, never a real night vision potion
        if (mc.player != null && added) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        added = false;
    }
}
