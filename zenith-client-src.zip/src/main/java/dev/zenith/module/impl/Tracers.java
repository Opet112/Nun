package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public class Tracers extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 96, 8, 200, 8));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", false));

    public Tracers() {
        super("Tracers", "Lines from the bottom of your screen to entities.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !BoxEsp.wanted(e, players.get(), hostiles.get(), false)) continue;
            if (mc.player.distanceTo(e) > range.get()) continue;
            Vec3d feet = e.getLerpedPos(partial).add(0, e.getHeight() / 2.0, 0);
            double[] s = pr.project(feet);
            if (s == null) continue;
            DrawUtil.line(ctx, pr.width / 2.0, pr.height, s[0], s[1], BoxEsp.colorOf(e), pr.width, pr.height);
        }
    }
}
