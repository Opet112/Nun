package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Spinbot extends Module {
    private final Setting.Num speed = add(new Setting.Num("Speed", 30, 5, 90, 5));
    private final Setting.Num pitch = add(new Setting.Num("Pitch", 0, -90, 90, 15));

    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Silent", "Silent", "Camera"));
    private float angle;

    public Spinbot() {
        super("Spinbot", "Spins your character (visible to other players).", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (mode.is("Silent")) {
            // only what the server sees spins; your own camera stays still
            angle = net.minecraft.util.math.MathHelper.wrapDegrees(angle + speed.getFloat());
            dev.zenith.util.RotationManager.request(p, angle, pitch.getFloat(), 180f, false);
            return;
        }
        p.setYaw(p.getYaw() + speed.getFloat());
        p.setPitch(pitch.getFloat());
    }
}
