package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.InventoryUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws experience bottles at your feet while your armor is damaged, so Mending repairs it. */
public class AutoXP extends Module {
    private final Setting.Num threshold = add(new Setting.Num("Repair below %", 90, 10, 100, 5));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 4, 1, 20, 1));
    private final Setting.Bool onlyStill = add(new Setting.Bool("Only when standing still", false));
    private final Setting.Bool hands = add(new Setting.Bool("Include hands", true));
    private final Setting.Num enemySafe = add(new Setting.Num("Pause if enemy within", 0, 0, 20, 1));
    private int wait;

    public AutoXP() {
        super("AutoXP", "Throws XP bottles downward to mend damaged armor.", Category.PLAYER);
    }

    private boolean needsRepair() {
        EquipmentSlot[] slots = hands.get()
                ? new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}
                : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot s : slots) {
            ItemStack st = mc.player.getEquippedStack(s);
            if (st.isEmpty() || !st.isDamageable()) continue;
            double left = 100.0 * (1.0 - st.getDamage() / (double) Math.max(1, st.getMaxDamage()));
            if (left < threshold.get()) return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;
        if (onlyStill.get() && p.getVelocity().horizontalLengthSquared() > 0.001) return;
        if (!needsRepair()) return;
        if (enemySafe.get() > 0 && dev.zenith.util.EntityUtil.nearestPlayer(enemySafe.get()) != null) return;
        int slot = InventoryUtil.findHotbar(Items.EXPERIENCE_BOTTLE);
        if (slot < 0) return;

        int previous = p.getInventory().getSelectedSlot();
        float oldPitch = p.getPitch();
        InventoryUtil.select(slot);
        p.setPitch(90f); // the use packet carries the camera pitch, so look straight down for this one call
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.setPitch(oldPitch);
        InventoryUtil.select(previous);
        wait = delay.getInt();
    }
}
