package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.text.Text;

public class AutoLog extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", 6, 1, 19, 1));

    private final Setting.Num playerRange = add(new Setting.Num("Player in range (0 = off)", 0, 0, 64, 4));
    private final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore friends", true));

    public AutoLog() {
        super("AutoLog", "Disconnects when your health drops too low.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.networkHandler == null) return;
        if (playerRange.get() > 0 && mc.world != null) {
            for (var o : mc.world.getPlayers()) {
                if (o == p || (ignoreFriends.get() && EntityUtil.isFriend(o))) continue;
                if (p.distanceTo(o) <= playerRange.get()) {
                    setEnabled(false);
                    p.networkHandler.getConnection().disconnect(Text.literal("[Zenith] AutoLog: " + o.getName().getString() + " came within range"));
                    return;
                }
            }
        }
        if (p.getHealth() <= health.get()) {
            setEnabled(false);
            p.networkHandler.getConnection().disconnect(Text.literal("[Zenith] AutoLog: health " + (int) p.getHealth()));
        }
    }
}
