package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/** Walls the nearest player in with obsidian: feet level, head level, then the roof. */
public class AutoTrap extends Module {
    private final Setting.Num range = add(new Setting.Num("Target range", 5, 2, 6, 0.5));
    private final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 2, 1, 4, 1));
    private final Setting.Bool autoOff = add(new Setting.Bool("Disable when done", false));
    private final Setting.Bool roof = add(new Setting.Bool("Roof", true));
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));

    public AutoTrap() {
        super("AutoTrap", "Traps the nearest player in obsidian.", Category.COMBAT);
    }

    private static BlockPos at(BlockPos b, int x, int y, int z) {
        return new BlockPos(b.getX() + x, b.getY() + y, b.getZ() + z);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        PlayerEntity target = EntityUtil.nearestPlayer(range.get());
        if (target == null) return;
        int slot = Surround.findBlock();
        if (slot < 0) return;

        BlockPos feet = target.getBlockPos();
        List<BlockPos> plan = new ArrayList<>();
        for (int y = 0; y <= 1; y++) {
            plan.add(at(feet, 1, y, 0));
            plan.add(at(feet, -1, y, 0));
            plan.add(at(feet, 0, y, 1));
            plan.add(at(feet, 0, y, -1));
        }
        if (roof.get()) plan.add(at(feet, 0, 2, 0));

        if (autoOff.get()) {
            boolean complete = true;
            for (BlockPos pos : plan) if (BlockUtil.canPlaceAt(pos)) { complete = false; break; }
            if (complete) { setEnabled(false); return; }
        }
        int previous = p.getInventory().getSelectedSlot();
        int placed = 0;
        for (BlockPos pos : plan) {
            if (placed >= perTick.getInt()) break;
            if (!BlockUtil.canPlaceAt(pos)) continue;
            if (p.getEyePos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 20.0) continue;
            if (!BlockUtil.hasSupport(pos)) continue;
            InventoryUtil.select(slot);
            if (BlockUtil.place(pos, Hand.MAIN_HAND, true)) placed++;
        }
        if (placed > 0 && switchBack.get()) InventoryUtil.select(previous);
    }
}
