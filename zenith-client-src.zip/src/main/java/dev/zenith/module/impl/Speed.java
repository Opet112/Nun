package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final Setting.Mode mode = add(new Setting.Mode("Mode", "Strafe", "Strafe", "Boost"));
    private final Setting.Num multiplier = add(new Setting.Num("Multiplier", 1.25, 1.0, 3.0, 0.05));
    private final Setting.Num strafeSpeed = add(new Setting.Num("Strafe speed", 0.22, 0.1, 0.8, 0.01));
    private final Setting.Bool autoJump = add(new Setting.Bool("Auto jump", false));
    private final Setting.Bool inLiquid = add(new Setting.Bool("In liquids", false));

    public Speed() {
        super("Speed", "Moves faster. Strafe sets speed along your input; Boost multiplies it.", Category.MOVEMENT);
    }

    @Override
    public String getSuffix() { return mode.get(); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || p.isGliding() || p.getAbilities().flying || p.isClimbing()) return;
        if (!inLiquid.get() && (p.isTouchingWater() || p.isInLava())) return;
        float f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return;
        if (autoJump.get() && p.isOnGround()) p.jump();
        Vec3d v = p.getVelocity();
        if (mode.is("Strafe")) {
            double len = Math.sqrt(f * f + s * s);
            f /= len; s /= len;
            double yaw = Math.toRadians(p.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            double speed = strafeSpeed.get();
            // keep vanilla speed potions: scale by current horizontal speed ratio to base walk speed
            double base = Math.max(1.0, p.getMovementSpeed() / 0.1);
            speed *= base;
            double nx = (-sin * f + cos * s) * speed;
            double nz = (cos * f + sin * s) * speed;
            p.setVelocity(nx, v.y, nz);
            return;
        }
        double m = multiplier.get();
        double hx = v.x * m, hz = v.z * m;
        double h = Math.sqrt(hx * hx + hz * hz);
        double cap = 0.6 * m;
        if (h > cap) { hx *= cap / h; hz *= cap / h; }
        p.setVelocity(hx, v.y, hz);
    }
}
