package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Surround extends Module {
    private final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 2, 1, 4, 1));
    private final Setting.Bool disableOnMove = add(new Setting.Bool("Disable when moved", true));
    private final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));
    private final Setting.Bool floor = add(new Setting.Bool("Floor", false));
    private BlockPos origin;

    /** Obsidian first, then crying obsidian, then ender chests. */
    static int findBlock() {
        int slot = findBlock();
        if (slot < 0) slot = InventoryUtil.findHotbar(Items.CRYING_OBSIDIAN);
        if (slot < 0) slot = InventoryUtil.findHotbar(Items.ENDER_CHEST);
        return slot;
    }

    public Surround() {
        super("Surround", "Boxes your feet in with obsidian.", Category.COMBAT);
    }

    @Override
    protected void onEnable() { origin = mc.player == null ? null : mc.player.getBlockPos(); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (origin == null) origin = p.getBlockPos();
        if (disableOnMove.get() && !p.getBlockPos().equals(origin)) { setEnabled(false); return; }

        int slot = findBlock();
        if (slot < 0) return;

        int previous = p.getInventory().getSelectedSlot();
        int placed = 0;
        java.util.List<BlockPos> plan = new java.util.ArrayList<>();
        if (floor.get()) plan.add(origin.down());
        for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) plan.add(origin.offset(d));
        for (BlockPos pos : plan) {
            if (placed >= perTick.getInt()) break;
            if (!BlockUtil.canPlaceAt(pos)) continue;
            InventoryUtil.select(slot);
            if (BlockUtil.place(pos, Hand.MAIN_HAND, true)) placed++;
        }
        if (placed > 0 && switchBack.get()) InventoryUtil.select(previous);
    }
}
