package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));
    private final Setting.Num health = add(new Setting.Num("Only below HP", 20, 2, 20, 1));
    private final Setting.Bool inInventory = add(new Setting.Bool("Work in inventory", true));
    private int wait;

    public AutoTotem() {
        super("AutoTotem", "Keeps a Totem of Undying in your offhand (set 'Only below HP' to swap only when hurt).", Category.COMBAT);
    }

    @Override
    public String getSuffix() {
        if (mc.player == null) return null;
        int n = 0;
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n++;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) n++;
        return String.valueOf(n);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null && !(inInventory.get() && mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen)) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) { wait = delay.getInt(); return; }
        if (p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
        if (wait-- > 0) return;

        // Prefer a totem from the main inventory so the hotbar totem stays reachable.
        int found = -1;
        for (int i = 35; i >= 0; i--) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) { found = i; break; }
        }
        if (found < 0) return;
        int slot = found < 9 ? 36 + found : found; // hotbar -> 36..44, main inventory -> 9..35
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        wait = delay.getInt();
    }
}
