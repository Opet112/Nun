package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.ArrayList;
import java.util.List;

/** Holds back your movement packets; other players see you stand still, then jump to the new position on release. */
public class Blink extends Module {
    private final Setting.Num maxTicks = add(new Setting.Num("Max ticks", 60, 10, 200, 10));
    private final Setting.Bool releaseOnHurt = add(new Setting.Bool("Release when hurt", true));
    private final Setting.Bool ghost = add(new Setting.Bool("Show real position", true));
    private net.minecraft.util.math.Vec3d startPos;
    private final List<Packet<?>> queue = new ArrayList<>();
    private boolean flushing;
    private int ticks;

    public Blink() {
        super("Blink", "Holds back movement packets until you turn it off.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        queue.clear();
        ticks = 0;
        startPos = mc.player == null ? null : new net.minecraft.util.math.Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());
    }

    /** Draws a box where the server still thinks you are standing. */
    @Override
    public void onRender(net.minecraft.client.gui.DrawContext ctx) {
        if (!ghost.get() || startPos == null || mc.world == null) return;
        var pr = dev.zenith.util.Projector.create(ZenithClient.partial());
        if (pr == null) return;
        double[] b = pr.boxClamped(new net.minecraft.util.math.Box(startPos.x - 0.3, startPos.y, startPos.z - 0.3, startPos.x + 0.3, startPos.y + 1.8, startPos.z + 0.3));
        if (b == null) return;
        dev.zenith.util.DrawUtil.outline(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], 0xFF35D6E8);
    }

    @Override
    public boolean onPacketSend(Packet<?> packet) {
        if (flushing || mc.player == null) return false;
        if (packet instanceof PlayerMoveC2SPacket) {
            queue.add(packet);
            return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        if (releaseOnHurt.get() && mc.player != null && mc.player.hurtTime > 0) { flush(); setEnabled(false); return; }
        if (++ticks >= maxTicks.getInt()) {
            flush();
            ticks = 0;
            if (mc.player != null) startPos = new net.minecraft.util.math.Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        }
    }

    @Override
    protected void onDisable() { flush(); }

    private void flush() {
        var handler = mc.getNetworkHandler();
        flushing = true;
        try {
            if (handler != null) for (Packet<?> p : queue) handler.sendPacket(p);
        } finally {
            flushing = false;
            queue.clear();
        }
    }

    @Override
    public String getSuffix() { return String.valueOf(queue.size()); }
}
