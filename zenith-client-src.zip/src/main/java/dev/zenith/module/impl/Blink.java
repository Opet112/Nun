package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.ArrayList;
import java.util.List;

/** Holds back your movement packets; other players see you stand still, then jump to the new position on release. */
public class Blink extends Module {
    private final Setting.Num maxTicks = add(new Setting.Num("Max ticks", 60, 10, 200, 10));
    private final List<Packet<?>> queue = new ArrayList<>();
    private boolean flushing;
    private int ticks;

    public Blink() {
        super("Blink", "Holds back movement packets until you turn it off.", Category.MISC);
    }

    @Override
    protected void onEnable() { queue.clear(); ticks = 0; }

    @Override
    public boolean onPacketSend(Packet<?> packet) {
        if (flushing || mc.player == null) return false;
        if (packet instanceof PlayerMoveC2SPacket) {
            queue.add(packet);
            return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        if (++ticks >= maxTicks.getInt()) { flush(); ticks = 0; }
    }

    @Override
    protected void onDisable() { flush(); }

    private void flush() {
        var handler = mc.getNetworkHandler();
        flushing = true;
        try {
            if (handler != null) for (Packet<?> p : queue) handler.sendPacket(p);
        } finally {
            flushing = false;
            queue.clear();
        }
    }

    @Override
    public String getSuffix() { return String.valueOf(queue.size()); }
}
