package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Holds your shield up whenever a player is close, and lets go while you attack. */
public class AutoShield extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 6, 2, 16, 0.5));
    private final Setting.Bool dropOnAttack = add(new Setting.Bool("Lower while attacking", true));
    private boolean held;

    public AutoShield() {
        super("AutoShield", "Raises your shield automatically when an enemy player is near.", Category.COMBAT);
    }

    @Override
    protected void onDisable() { release(); }

    private void release() {
        if (held && mc.options != null) mc.options.useKey.setPressed(false);
        held = false;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) { release(); return; }
        boolean shield = p.getOffHandStack().isOf(Items.SHIELD) || p.getMainHandStack().isOf(Items.SHIELD);
        boolean near = shield && EntityUtil.nearestPlayer(range.get()) != null;
        boolean attacking = dropOnAttack.get() && mc.options.attackKey.isPressed();
        if (near && !attacking) { mc.options.useKey.setPressed(true); held = true; }
        else release();
    }
}
