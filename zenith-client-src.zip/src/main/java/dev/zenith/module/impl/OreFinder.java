package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Scans the blocks the server actually sent and only reports ore clusters. Anti-xray plugins scatter single fake
 * ores through hidden stone, so requiring a minimum cluster size filters most of them out.
 */
public class OreFinder extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 24, 8, 128, 4));
    private final Setting.Bool exposedOnly = add(new Setting.Bool("Exposed only (ignore fake ores)", true));
    private final Setting.Num minCluster = add(new Setting.Num("Min cluster", 1, 1, 6, 1));
    private final Setting.Bool diamond = add(new Setting.Bool("Diamond", false));
    private final Setting.Bool debris = add(new Setting.Bool("Ancient Debris", false));
    private final Setting.Bool emerald = add(new Setting.Bool("Emerald", false));
    private final Setting.Bool gold = add(new Setting.Bool("Gold", false));
    private final Setting.Bool iron = add(new Setting.Bool("Iron", false));
    private final Setting.Bool lapis = add(new Setting.Bool("Lapis", false));
    private final Setting.Bool redstone = add(new Setting.Bool("Redstone", false));
    private final Setting.Bool coal = add(new Setting.Bool("Coal", false));
    private final Setting.Bool copper = add(new Setting.Bool("Copper", false));
    private final Setting.Bool quartz = add(new Setting.Bool("Nether Quartz", false));

    private final Setting.Num opacity = add(new Setting.Num("Opacity", 120, 20, 255, 10));
    private final Setting.Bool nearestLabel = add(new Setting.Bool("Nearest label", true));
    private final Map<Long, Block> next = new HashMap<>();
    private volatile Map<Long, Block> shown = new HashMap<>();
    private int dzCursor = Integer.MIN_VALUE;
    private int layer;

    public OreFinder() {
        super("OreFinder", "Shows ore clusters through walls; ignores lone (likely fake) ores.", Category.RENDER);
    }

    @Override
    protected void onEnable() { layer = 0; next.clear(); shown = new HashMap<>(); }

    private boolean wanted(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE) return diamond.get();
        if (b == Blocks.ANCIENT_DEBRIS) return debris.get();
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return emerald.get();
        if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return gold.get();
        if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return iron.get();
        if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return lapis.get();
        if (b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE) return redstone.get();
        if (b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE) return coal.get();
        if (b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE) return copper.get();
        if (b == Blocks.NETHER_QUARTZ_ORE) return quartz.get();
        return false;
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        BlockPos.Mutable m = new BlockPos.Mutable(), nb = new BlockPos.Mutable();
        int budget = 24000; // per-tick cap: a big range just refreshes more slowly
        if (dzCursor < -r || dzCursor > r + 1) dzCursor = -r;
        while (budget > 0) {
            if (dzCursor > r) {
                dzCursor = -r;
                layer++;
                if (layer > r * 2) {
                    layer = 0;
                    shown = filter(new HashMap<>(next));
                    next.clear();
                }
            }
            int dx = layer - r, dz = dzCursor++;
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block b = mc.world.getBlockState(m).getBlock();
                if (wanted(b) && (!exposedOnly.get() || exposed(nb, px + dx, py + dy, pz + dz))) next.put(m.asLong(), b);
            }
            budget -= 2 * r + 1;
        }
    }


    /** True when at least one face of the block touches air, fluid or another non-solid block. */
    private boolean exposed(BlockPos.Mutable n, int x, int y, int z) {
        int[][] d = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        for (int[] o : d) {
            n.set(x + o[0], y + o[1], z + o[2]);
            if (!mc.world.getBlockState(n).isSolidBlock(mc.world, n)) return true;
        }
        return false;
    }

    private Map<Long, Block> filter(Map<Long, Block> all) {
        int min = minCluster.getInt();
        if (min <= 1) return all;
        Map<Long, Block> keep = new HashMap<>();
        Set<Long> seen = new HashSet<>();
        for (Long start : all.keySet()) {
            if (seen.contains(start)) continue;
            Set<Long> group = new HashSet<>();
            ArrayDeque<Long> queue = new ArrayDeque<>();
            queue.add(start);
            seen.add(start);
            while (!queue.isEmpty()) {
                long cur = queue.poll();
                group.add(cur);
                BlockPos p = BlockPos.fromLong(cur);
                for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) for (int z = -1; z <= 1; z++) {
                    long n = BlockPos.asLong(p.getX() + x, p.getY() + y, p.getZ() + z);
                    if (all.containsKey(n) && seen.add(n)) queue.add(n);
                }
            }
            if (group.size() >= min) for (Long g : group) keep.put(g, all.get(g));
        }
        return keep;
    }

    private static int colorOf(Block b) {
        if (b == Blocks.ANCIENT_DEBRIS) return 0xFFB5651D;
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return 0xFF2FD27E;
        if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return 0xFFFFD84A;
        if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return 0xFFD8B08C;
        if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return 0xFF3F6BFF;
        if (b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE) return 0xFFE8344F;
        if (b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE) return 0xFF8A8F9E;
        if (b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE) return 0xFFE0834A;
        if (b == Blocks.NETHER_QUARTZ_ORE) return 0xFFF2EEE6;
        return 0xFF35D6E8; // diamond
    }

    private static String nameOf(Block b) {
        if (b == Blocks.ANCIENT_DEBRIS) return "Debris";
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return "Emerald";
        if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return "Gold";
        if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return "Iron";
        if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return "Lapis";
        if (b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE) return "Redstone";
        if (b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE) return "Coal";
        if (b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE) return "Copper";
        if (b == Blocks.NETHER_QUARTZ_ORE) return "Quartz";
        return "Diamond";
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        long nearestKey = 0;
        double nearest = Double.MAX_VALUE;
        for (Map.Entry<Long, Block> e : shown.entrySet()) {
            if (!wanted(e.getValue())) continue;
            BlockPos bp = BlockPos.fromLong(e.getKey());
            double d = bp.getSquaredDistance(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            if (d < nearest) { nearest = d; nearestKey = e.getKey(); }
            if (!wanted(mc.world.getBlockState(bp).getBlock())) continue; // already mined
            int color = colorOf(e.getValue());
            int fillCol = (opacity.getInt() << 24) | (color & 0xFFFFFF);
            DrawUtil.fillBlock(ctx, pr, new Box(bp), fillCol);
        }
        if (nearestLabel.get() && nearest < Double.MAX_VALUE) {
            BlockPos bp = BlockPos.fromLong(nearestKey);
            double[] s = pr.box(new Box(bp));
            if (s != null) {
                String t = nameOf(shown.get(nearestKey)) + " " + (int) Math.sqrt(nearest) + "m";
                int w = mc.textRenderer.getWidth(t);
                int x = (int) ((s[0] + s[2]) / 2) - w / 2, y = (int) s[1] - 11;
                ctx.fill(x - 2, y - 1, x + w + 2, y + 9, 0x90101216);
                ctx.drawText(mc.textRenderer, t, x, y, colorOf(shown.get(nearestKey)), true);
            }
        }
    }
}
