package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DamageUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class CrystalAura extends Module {
    private static final float POWER = 6.0f;

    private final Setting.Num range = add(new Setting.Num("Range", 4.5, 2.0, 6.0, 0.1));
    private final Setting.Num targetRange = add(new Setting.Num("Target range", 10, 4, 16, 1));
    private final Setting.Num minDamage = add(new Setting.Num("Min damage", 4, 1, 20, 0.5));
    private final Setting.Num maxSelf = add(new Setting.Num("Max self damage", 6, 1, 20, 0.5));
    private final Setting.Num placeDelay = add(new Setting.Num("Place delay", 2, 0, 10, 1));
    private final Setting.Num breakDelay = add(new Setting.Num("Break delay", 1, 0, 10, 1));
    private final Setting.Bool place = add(new Setting.Bool("Place", true));
    private final Setting.Bool breakCrystals = add(new Setting.Bool("Break", true));
    private final Setting.Mode priority = add(new Setting.Mode("Target", "Distance", "Distance", "Health"));
    private final Setting.Bool pauseUsing = add(new Setting.Bool("Pause while eating", true));
    private final Setting.Num facePlaceHp = add(new Setting.Num("Face place below HP", 0, 0, 20, 1));
    private final Setting.Bool autoSwitch = add(new Setting.Bool("Auto switch", true));
    private final Setting.Bool rotate = add(new Setting.Bool("Rotate (silent)", true));
    private final Setting.Num rotSpeed = add(new Setting.Num("Rotation speed", 70, 20, 180, 5));

    private static final int NONE = 0, DONE = 1, ROTATING = 2;

    private int placeWait, breakWait;

    public CrystalAura() {
        super("CrystalAura", "Places and detonates end crystals near the closest player.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (pauseUsing.get() && p.isUsingItem()) return;
        PlayerEntity target = pickTarget();
        if (target == null) return;

        placeWait--;
        breakWait--;
        if (breakCrystals.get() && breakWait <= 0) {
            int r = doBreak(target);
            if (r == DONE) { breakWait = breakDelay.getInt(); return; }
            if (r == ROTATING) return;
        }
        if (place.get() && placeWait <= 0) {
            int r = doPlace(target);
            if (r == DONE) placeWait = placeDelay.getInt();
        }
    }

    private PlayerEntity pickTarget() {
        if (priority.is("Distance")) return EntityUtil.nearestPlayer(targetRange.get());
        PlayerEntity best = null;
        float bestHp = Float.MAX_VALUE;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || !o.isAlive() || EntityUtil.isFriend(o) || mc.player.distanceTo(o) > targetRange.get()) continue;
            float hp = o.getHealth() + o.getAbsorptionAmount();
            if (hp < bestHp) { bestHp = hp; best = o; }
        }
        return best;
    }

    /** Minimum damage for this target; drops to 1 when the target is nearly dead (face place). */
    private double minFor(PlayerEntity target) {
        if (facePlaceHp.get() > 0 && target.getHealth() + target.getAbsorptionAmount() <= facePlaceHp.get()) return 1.0;
        return minDamage.get();
    }

    private boolean safe(float selfDamage) {
        var p = mc.player;
        return selfDamage <= maxSelf.get() && selfDamage < p.getHealth() + p.getAbsorptionAmount() - 1f;
    }

    private int doBreak(PlayerEntity target) {
        var p = mc.player;
        EndCrystalEntity best = null;
        double bestScore = -Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity crystal) || !crystal.isAlive()) continue;
            if (p.distanceTo(crystal) > range.get()) continue;
            Vec3d c = new Vec3d(crystal.getX(), crystal.getY(), crystal.getZ());
            float dt = DamageUtil.explosion(c, target, POWER);
            float ds = DamageUtil.explosion(c, p, POWER);
            if (dt < minFor(target) || !safe(ds)) continue;
            double score = dt - ds * 0.5;
            if (score > bestScore) { bestScore = score; best = crystal; }
        }
        if (best == null) return NONE;

        if (rotate.get()) {
            Box box = best.getBoundingBox();
            boolean on = RotationManager.aim(p, box, EntityUtil.aimPoint(p, box), range.get() + 0.5, rotSpeed.getFloat(), true);
            if (!on) return ROTATING;
        }
        Criticals.apply();
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        return DONE;
    }

    private int doPlace(PlayerEntity target) {
        var p = mc.player;

        Hand hand;
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.MAIN_HAND;
        } else if (autoSwitch.get() && InventoryUtil.findHotbar(Items.END_CRYSTAL) >= 0) {
            InventoryUtil.select(InventoryUtil.findHotbar(Items.END_CRYSTAL));
            hand = Hand.MAIN_HAND;
        } else {
            return NONE;
        }

        int r = (int) Math.ceil(range.get());
        BlockPos origin = p.getBlockPos();
        Vec3d eye = p.getEyePos();
        BlockPos bestPos = null;
        double bestScore = -Double.MAX_VALUE;

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    var state = mc.world.getBlockState(pos);
                    if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(pos)) > range.get()) continue;
                    if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) continue;
                    Box space = new Box(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
                    if (!mc.world.getOtherEntities(null, space).isEmpty()) continue;

                    Vec3d center = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    float dt = DamageUtil.explosion(center, target, POWER);
                    if (dt < minFor(target)) continue;
                    float ds = DamageUtil.explosion(center, p, POWER);
                    if (!safe(ds)) continue;
                    double score = dt - ds * 0.5;
                    if (score > bestScore) { bestScore = score; bestPos = pos; }
                }
            }
        }
        if (bestPos == null) return NONE;

        // click the face that is really visible from the eyes, aiming at its centre
        Direction face = BlockUtil.bestFace(bestPos, eye);
        Vec3d hit = Vec3d.ofCenter(bestPos).add(Vec3d.of(face.getVector()).multiply(0.5));
        if (rotate.get()) {
            boolean on = RotationManager.aim(p, new Box(bestPos), hit, range.get() + 0.5, rotSpeed.getFloat(), true);
            if (!on) return ROTATING;
        }
        mc.interactionManager.interactBlock(p, hand, new BlockHitResult(hit, face, bestPos, false));
        p.swingHand(hand);
        return DONE;
    }
}
