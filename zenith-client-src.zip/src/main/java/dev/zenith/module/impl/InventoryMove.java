package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class InventoryMove extends Module {
    public InventoryMove() {
        super("InventoryMove", "Keep walking while an inventory or container is open.", Category.MISC);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) return;
        // text fields / sign editors / the ClickGUI should keep keyboard focus
        String cls = mc.currentScreen.getClass().getSimpleName();
        if (cls.contains("Sign") || cls.contains("Book") || cls.contains("Anvil") || cls.contains("Command")
                || cls.contains("ClickGui") || cls.contains("Creative")) return;
        long handle = mc.getWindow().getHandle();
        var o = mc.options;
        for (KeyBinding k : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sprintKey, o.sneakKey}) {
            int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
            k.setPressed(code >= 0 && GLFW.glfwGetKey(handle, code) == GLFW.GLFW_PRESS);
        }
    }
}
