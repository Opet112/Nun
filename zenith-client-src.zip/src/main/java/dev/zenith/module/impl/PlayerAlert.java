package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerAlert extends Module {
    private final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore friends", false));
    private final Setting.Bool leaveMsg = add(new Setting.Bool("Leave messages", true));
    private final Setting.Bool details = add(new Setting.Bool("Show held item + coords", true));
    private final java.util.Map<UUID, String> names = new java.util.HashMap<>();
    private final Set<UUID> known = new HashSet<>();
    private boolean primed;

    public PlayerAlert() {
        super("PlayerAlert", "Tells you in chat when a player comes into range.", Category.MISC);
    }

    @Override
    protected void onEnable() { known.clear(); primed = false; }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        Set<UUID> now = new HashSet<>();
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == mc.player) continue;
            if (ignoreFriends.get() && EntityUtil.isFriend(other)) continue;
            now.add(other.getUuid());
            names.put(other.getUuid(), other.getName().getString());
            if (primed && known.add(other.getUuid())) {
                String tag = EntityUtil.isFriend(other) ? "§b" : "§c";
                String extra = details.get()
                        ? " holding " + (other.getMainHandStack().isEmpty() ? "nothing" : other.getMainHandStack().getName().getString())
                          + " at " + other.getBlockX() + " " + other.getBlockY() + " " + other.getBlockZ()
                        : "";
                ZenithClient.info(tag + other.getName().getString() + "§f entered range (" + (int) mc.player.distanceTo(other) + "m)" + extra);
            }
        }
        if (leaveMsg.get() && primed) {
            for (UUID id : known) if (!now.contains(id) && names.containsKey(id)) ZenithClient.info("§7" + names.get(id) + " left range");
        }
        known.retainAll(now);
        known.addAll(now);
        primed = true;
    }
}
