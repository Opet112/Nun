package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import dev.zenith.util.RotationManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws fishing rods, snowballs and eggs at a nearby player (knockback / combo breaker), then swaps back. */
public class ProjectileAura extends Module {
    private final Setting.Num minRange = add(new Setting.Num("Min range", 3, 1, 8, 0.5));
    private final Setting.Num maxRange = add(new Setting.Num("Max range", 10, 4, 25, 1));
    private final Setting.Bool visibleOnly = add(new Setting.Bool("Only visible targets", true));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 8, 2, 40, 1));
    private final Setting.Num turn = add(new Setting.Num("Turn speed", 50, 10, 90, 5));
    private final Setting.Bool rod = add(new Setting.Bool("Fishing rod", true));
    private final Setting.Bool snowball = add(new Setting.Bool("Snowballs", true));
    private final Setting.Bool egg = add(new Setting.Bool("Eggs", false));
    private int wait;

    public ProjectileAura() {
        super("ProjectileAura", "Throws rods, snowballs and eggs at nearby players to knock them back.", Category.COMBAT);
    }

    private Item pick() {
        if (rod.get() && InventoryUtil.findHotbar(Items.FISHING_ROD) >= 0) return Items.FISHING_ROD;
        if (snowball.get() && InventoryUtil.findHotbar(Items.SNOWBALL) >= 0) return Items.SNOWBALL;
        if (egg.get() && InventoryUtil.findHotbar(Items.EGG) >= 0) return Items.EGG;
        return null;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait > 0) { wait--; return; }
        PlayerEntity t = EntityUtil.nearestPlayer(maxRange.get());
        if (t == null || p.distanceTo(t) < minRange.get() || (visibleOnly.get() && !p.canSee(t))) return;
        Item item = pick();
        if (item == null) return;
        int prev = p.getInventory().getSelectedSlot();
        InventoryUtil.select(InventoryUtil.findHotbar(item));
        boolean on = RotationManager.aim(p, t.getBoundingBox(), t.getBoundingBox().getCenter(), maxRange.get(), (float) turn.get(), true);
        if (on) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            InventoryUtil.select(prev);
            wait = delay.getInt();
        }
    }
}
