package dev.zenith.module;

import dev.zenith.ZenithClient;
import dev.zenith.gui.ClickGuiScreen;
import dev.zenith.module.impl.*;
import dev.zenith.util.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    public static final int GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private final List<Module> modules = new ArrayList<>();
    private final Map<Integer, Boolean> keyState = new HashMap<>();

    public void init() {
        // Combat
        register(new KillAura());
        register(new ShieldBreaker());
        register(new MaceAura());
        register(new BowSpam());
        register(new BowAimbot());
        register(new AntiVanish());
        register(new ProjectileAura());
        register(new AutoShield());
        register(new AutoGap());
        register(new PopCounter());
        register(new PearlEsp());
        register(new ArmorWarning());
        register(new TriggerBot());
        register(new AimAssist());
        register(new AutoClicker());
        register(new AutoTotem());
        register(new AutoArmor());
        register(new AutoWeapon());
        register(new JumpReset());
        register(new WTap());
        register(new Criticals());
        register(new CrystalAura());
        register(new AnchorAura());
        register(new Surround());
        register(new Velocity());
        register(new HitBoxes());
        register(new AutoTrap());
        register(new AutoWeb());
        register(new HoleFill());
        // Movement
        register(new Sprint());
        register(new Flight());
        register(new Speed());
        register(new Step());
        register(new Spider());
        register(new NoFall());
        register(new Glide());
        register(new Jesus());
        register(new Eagle());
        register(new Parkour());
        register(new FastLadder());
        register(new AutoWalk());
        register(new AutoJump());
        register(new Sneak());
        register(new ElytraFly());
        register(new ElytraSwap());
        register(new NoSlow());
        register(new Timer());
        register(new NoJumpDelay());
        register(new FastFall());
        // Render
        register(new Fullbright());
        register(new GlowEsp());
        register(new Zoom());
        register(new NoWeather());
        register(new Radar());
        register(new TargetHud());
        register(new ArmorHud());
        register(new Keystrokes());
        register(new BoxEsp());
        register(new Tracers());
        register(new NameTags());
        register(new Freecam());
        register(new Xray());
        register(new Waypoints());
        register(new ItemEsp());
        register(new LogoutSpots());
        register(new Trajectories());
        register(new OreFinder());
        register(new BlockEsp());
        register(new BaseFinder());
        register(new StorageEsp());
        register(new HoleEsp());
        register(new TargetEsp());
        register(new LowHealthWarning());
        register(new Breadcrumbs());
        // Player
        register(new AutoRespawn());
        register(new AntiAfk());
        register(new AutoEat());
        register(new AutoTool());
        register(new AutoReplenish());
        register(new AutoLog());
        register(new AutoFish());
        register(new FastPlace());
        register(new FastBreak());
        register(new NoPush());
        register(new AutoBuild());
        register(new AutoXP());
        register(new MiddleClick());
        register(new Nuker());
        register(new Printer());
        // Misc
        register(new Scaffold());
        register(new ChestStealer());
        register(new Spammer());
        register(new PlayerAlert());
        register(new DeathCoords());
        register(new Spinbot());
        register(new InventoryMove());
        register(new Freeze());
        register(new HighJump());
        register(new Blink());
        register(new AutoReconnect());
        // Client
        register(new HudModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return modules;
    }

    public List<Module> in(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == category) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public Module byName(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void preTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onPreTick();
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} crashed and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    /** Returns true if a module wants the outgoing packet cancelled. */
    public boolean dispatchSend(Packet<?> packet) {
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                if (m.onPacketSend(packet)) return true;
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} failed in packet hook", m.name, t);
            }
        }
        return false;
    }

    public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        pollKeys(mc);
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onAlwaysTick();
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} crashed and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
        if (mc.player == null || mc.world == null) { RotationManager.reset(); return; }
        RotationManager.tick(mc.player);
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onTick();
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} crashed and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    /** Keybinds are polled straight from GLFW so no vanilla keybinding registration is needed. */
    private void pollKeys(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long handle = mc.getWindow().getHandle();
        boolean canType = mc.currentScreen == null;

        boolean guiDown = GLFW.glfwGetKey(handle, GUI_KEY) == GLFW.GLFW_PRESS;
        boolean guiWas = keyState.getOrDefault(GUI_KEY, false);
        if (guiDown && !guiWas && canType) mc.setScreen(new ClickGuiScreen());
        keyState.put(GUI_KEY, guiDown);

        for (Module m : modules) {
            int key = m.getKey();
            if (key < 0 || key == GUI_KEY) continue;
            boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            boolean was = keyState.getOrDefault(key, false);
            if (down && !was && canType && mc.player != null) m.toggle();
            keyState.put(key, down);
        }
    }
}
