package dev.zenith.module;

import dev.zenith.ZenithClient;
import dev.zenith.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.network.packet.Packet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final Category category;

    private boolean enabled;
    private int key = -1;
    /** Whether the module is listed in the HUD array list. */
    public boolean visible = true;

    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public List<Setting> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
        ZenithClient.toggled(this);
    }

    /** Sets the flag without firing callbacks (used when loading config). */
    public void setEnabledSilently(boolean value) { enabled = value; }

    public void toggle() { setEnabled(!enabled); }

    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    /** Extra text shown next to the name in the array list. */
    public String getSuffix() { return null; }

    /** False for modules that must never start enabled (e.g. Freecam needs a live camera state). */
    public boolean persistEnabled() { return true; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    /** Runs at the very start of each client tick, before vanilla reads input. */
    public void onPreTick() {}
    /** Runs every tick even without a world (menus, disconnect screen). */
    public void onAlwaysTick() {}
    /** Return true to cancel an outgoing packet. */
    public boolean onPacketSend(Packet<?> packet) { return false; }
    /** Draw on the HUD (called every frame while enabled). */
    public void onRender(DrawContext ctx) {}
    /** Called when the game closes; undo anything that would persist (e.g. options). */
    public void onShutdown() {}
}
