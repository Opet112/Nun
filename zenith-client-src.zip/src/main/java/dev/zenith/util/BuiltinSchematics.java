package dev.zenith.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Blueprints generated in code. Every build starts 2 blocks east and south of where you stand (so you are not inside it)
 * and sits on top of the ground. Only plain blocks are used (no doors, stairs, beds or water), because the Printer places
 * block types without orientation; add water and till farmland yourself.
 */
public final class BuiltinSchematics {
    private BuiltinSchematics() {}

    private static final String COBBLE = "minecraft:cobblestone", PLANKS = "minecraft:oak_planks", BRICKS = "minecraft:stone_bricks",
            GLASS = "minecraft:glass_pane", OBI = "minecraft:obsidian", DIRT = "minecraft:dirt", SAND = "minecraft:sand",
            FENCE = "minecraft:oak_fence", GATE = "minecraft:oak_fence_gate", TORCH = "minecraft:torch", CHEST = "minecraft:chest",
            LOG = "minecraft:oak_log";

    public static final Map<String, Supplier<Schematic>> ALL = new LinkedHashMap<>();
    public static final Map<String, String> INFO = new LinkedHashMap<>();

    private static void reg(String name, String info, Supplier<Schematic> s) {
        ALL.put(name, s);
        INFO.put(name, info);
    }

    static {
        reg("starter_base", "7x7 cobblestone house, plank roof, windows, torches, crafting table, furnace, 2 chests", BuiltinSchematics::starterBase);
        reg("bunker", "5x5x4 sealed obsidian bunker with a 1x2 entrance", BuiltinSchematics::bunker);
        reg("wheat_farm", "9x9 dirt farm with a water hole in the middle (till it and add water yourself), fenced", BuiltinSchematics::wheatFarm);
        reg("sugarcane_farm", "11x5 sand rows with water channels (add the water)", BuiltinSchematics::sugarcaneFarm);
        reg("animal_pen", "9x9 fence pen with a gate", BuiltinSchematics::animalPen);
        reg("storage_room", "9x4x5 stone brick room with 2 rows of chests and torches", BuiltinSchematics::storageRoom);
        reg("nether_portal", "4x5 obsidian portal frame (light it yourself)", BuiltinSchematics::netherPortal);
        reg("lookout_tower", "4 pillars, 10 high, platform and fence rim", BuiltinSchematics::lookoutTower);
        reg("bridge", "3 wide, 24 long stone brick bridge with fence rails", BuiltinSchematics::bridge);
        reg("wall", "21x5 cobblestone wall, 2 thick", BuiltinSchematics::wall);
    }

    private static Schematic base() { return new Schematic(); }

    private static Schematic starterBase() {
        Schematic s = base();
        int o = 2, w = 7;
        s.shell(o, 0, o, o + w - 1, 3, o + w - 1, COBBLE);
        s.fill(o, 4, o, o + w - 1, 4, o + w - 1, PLANKS);
        for (int y = 0; y <= 3; y++) for (int x = o + 1; x <= o + w - 2; x++) for (int z = o + 1; z <= o + w - 2; z++) s.clear(x, y, z);
        s.clear(o + 3, 0, o); s.clear(o + 3, 1, o); // doorway on the north side
        for (int x : new int[]{o + 2, o + 4}) { s.clear(o + w - 1, 1, x); s.set(o + w - 1, 1, x, GLASS); s.clear(o + w - 1, 2, x); s.set(o + w - 1, 2, x, GLASS); }
        for (int z : new int[]{o + 2, o + 4}) { s.clear(o, 1, z); s.set(o, 1, z, GLASS); s.clear(o, 2, z); s.set(o, 2, z, GLASS); }
        s.set(o + 1, 0, o + 1, "minecraft:crafting_table");
        s.set(o + 2, 0, o + 1, "minecraft:furnace");
        s.set(o + w - 2, 0, o + w - 2, CHEST);
        s.set(o + w - 4, 0, o + w - 2, CHEST);
        s.set(o + 1, 2, o + 1, TORCH); s.set(o + w - 2, 2, o + 1, TORCH);
        s.set(o + 1, 2, o + w - 2, TORCH); s.set(o + w - 2, 2, o + w - 2, TORCH);
        return s;
    }

    private static Schematic bunker() {
        Schematic s = base();
        int o = 2;
        s.shell(o, 0, o, o + 4, 3, o + 4, OBI);
        s.clear(o + 2, 0, o); s.clear(o + 2, 1, o);
        return s;
    }

    private static Schematic wheatFarm() {
        Schematic s = base();
        int o = 2;
        s.shell(o, 0, o, o + 8, 0, o + 8, BRICKS);
        s.fill(o + 1, 0, o + 1, o + 7, 0, o + 7, DIRT);
        s.clear(o + 4, 0, o + 4); // water hole
        s.shell(o, 1, o, o + 8, 1, o + 8, FENCE);
        s.clear(o + 4, 1, o); s.set(o + 4, 1, o, GATE);
        for (int x : new int[]{o + 1, o + 7}) for (int z : new int[]{o + 1, o + 7}) s.set(x, 1, z, TORCH);
        return s;
    }

    private static Schematic sugarcaneFarm() {
        Schematic s = base();
        int o = 2;
        s.fill(o, 0, o, o + 10, 0, o + 4, BRICKS);
        for (int z : new int[]{o, o + 2, o + 4}) s.fill(o + 1, 1, z, o + 9, 1, z, SAND);
        for (int z = o; z <= o + 4; z++) { s.set(o, 1, z, BRICKS); s.set(o + 10, 1, z, BRICKS); }
        return s;
    }

    private static Schematic animalPen() {
        Schematic s = base();
        int o = 2;
        s.shell(o, 0, o, o + 8, 0, o + 8, FENCE);
        s.clear(o + 4, 0, o); s.set(o + 4, 0, o, GATE);
        return s;
    }

    private static Schematic storageRoom() {
        Schematic s = base();
        int o = 2;
        s.shell(o, 0, o, o + 8, 3, o + 4, BRICKS);
        for (int y = 0; y <= 3; y++) for (int x = o + 1; x <= o + 7; x++) for (int z = o + 1; z <= o + 3; z++) s.clear(x, y, z);
        s.clear(o + 4, 0, o); s.clear(o + 4, 1, o);
        for (int x = o + 1; x <= o + 7; x += 2) { s.set(x, 0, o + 4 - 1, CHEST); s.set(x, 0, o + 1, CHEST); }
        s.set(o + 1, 2, o + 2, TORCH); s.set(o + 7, 2, o + 2, TORCH);
        return s;
    }

    private static Schematic netherPortal() {
        Schematic s = base();
        int o = 2;
        s.fill(o + 1, 0, o, o + 2, 0, o, OBI);
        s.fill(o + 1, 4, o, o + 2, 4, o, OBI);
        s.fill(o, 1, o, o, 3, o, OBI);
        s.fill(o + 3, 1, o, o + 3, 3, o, OBI);
        return s;
    }

    private static Schematic lookoutTower() {
        Schematic s = base();
        int o = 2;
        for (int x : new int[]{o, o + 3}) for (int z : new int[]{o, o + 3}) s.fill(x, 0, z, x, 9, z, LOG);
        s.fill(o, 10, o, o + 3, 10, o + 3, PLANKS);
        s.shell(o, 11, o, o + 3, 11, o + 3, FENCE);
        return s;
    }

    private static Schematic bridge() {
        Schematic s = base();
        int o = 2;
        s.fill(o, 0, o, o + 2, 0, o + 23, BRICKS);
        s.fill(o, 1, o, o, 1, o + 23, FENCE);
        s.fill(o + 2, 1, o, o + 2, 1, o + 23, FENCE);
        return s;
    }

    private static Schematic wall() {
        Schematic s = base();
        int o = 2;
        s.fill(o, 0, o, o + 20, 4, o + 1, COBBLE);
        return s;
    }

    public static Schematic build(String name) {
        Supplier<Schematic> sup = ALL.get(name.toLowerCase(java.util.Locale.ROOT));
        return sup == null ? null : sup.get();
    }
}
