package dev.zenith.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

/** "Silent" rotations: the server sees the look packet, your own camera does not move. */
public final class RotationUtil {
    private RotationUtil() {}

    public static void send(ClientPlayerEntity p, float yaw, float pitch) {
        var handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler == null) return;
        handler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }

    public static void sendTo(ClientPlayerEntity p, Vec3d target) {
        float[] r = EntityUtil.rotationsTo(p, target);
        send(p, r[0], r[1]);
    }

    /** Re-sends the real camera rotation so the server is not left looking at the fake one. */
    public static void restore(ClientPlayerEntity p) {
        send(p, p.getYaw(), p.getPitch());
    }
}
