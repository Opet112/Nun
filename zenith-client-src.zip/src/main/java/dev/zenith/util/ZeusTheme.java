package dev.zenith.util;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

import java.util.Random;

/** Zeus / lightning look shared by the HUD, title screen and loading screens. */
public final class ZeusTheme {
    private ZeusTheme() {}

    public static final int GOLD = 0xFFFFD84A;
    public static final int ELECTRIC = 0xFF6FD3FF;
    public static final int STORM_TOP = 0xFF050A1C;
    public static final int STORM_BOTTOM = 0xFF1B2C5E;

    public static int lerp(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Gold-to-electric-blue pulse; {@code offset} shifts it per row. */
    public static int accent(int offset) {
        double t = (System.currentTimeMillis() % 2400L) / 2400.0 * Math.PI * 2 + offset * 0.5;
        return lerp(GOLD, ELECTRIC, (float) (Math.sin(t) * 0.5 + 0.5));
    }

    /** A jagged bolt from (x, y) down {@code length} pixels; the same seed always gives the same shape. */
    public static void bolt(DrawContext ctx, int x, int y, int length, long seed, int color, int w, int h) {
        Random rnd = new Random(seed);
        int cx = x, cy = y;
        int end = y + length;
        while (cy < end) {
            int dy = 6 + rnd.nextInt(10);
            int nx = cx + rnd.nextInt(17) - 8;
            int ny = Math.min(end, cy + dy);
            DrawUtil.line(ctx, cx - 1, cy, nx - 1, ny, (color & 0xFFFFFF) | 0x40000000, w, h);
            DrawUtil.line(ctx, cx + 1, cy, nx + 1, ny, (color & 0xFFFFFF) | 0x40000000, w, h);
            DrawUtil.line(ctx, cx, cy, nx, ny, 0xFFFFFFFF, w, h);
            cx = nx;
            cy = ny;
        }
    }

    /** Storm sky with bolts that flash every couple of seconds. {@code tint} 0..255 is the sky opacity. */
    public static void storm(DrawContext ctx, int w, int h, int tint) {
        ctx.fillGradient(0, 0, w, h, (tint << 24) | (STORM_TOP & 0xFFFFFF), (tint << 24) | (STORM_BOTTOM & 0xFFFFFF));
        long now = System.currentTimeMillis();
        long bucket = now / 2600L;
        long phase = now % 2600L;
        if (phase < 260L) {
            int flash = (int) ((1.0 - phase / 260.0) * 70);
            ctx.fill(0, 0, w, h, (flash << 24) | 0xCFE8FF);
            Random rnd = new Random(bucket * 31L);
            int bolts = 1 + rnd.nextInt(3);
            for (int i = 0; i < bolts; i++) {
                bolt(ctx, rnd.nextInt(Math.max(1, w)), 0, h / 2 + rnd.nextInt(Math.max(1, h / 3)), bucket * 97L + i, ELECTRIC, w, h);
            }
        }
    }

    /** Centered "ZENITH" banner with bolts on both sides. */
    public static void banner(DrawContext ctx, TextRenderer tr, int w, int y, String subtitle) {
        String title = "Z E N I T H";
        int tw = tr.getWidth(title);
        int x = w / 2 - tw / 2;
        ctx.fill(x - 18, y - 6, x + tw + 18, y + 26, 0x90050A1C);
        DrawUtil.outline(ctx, x - 18, y - 6, x + tw + 17, y + 25, accent(0));
        ctx.drawCenteredTextWithShadow(tr, title, w / 2, y, accent(0));
        ctx.drawCenteredTextWithShadow(tr, subtitle, w / 2, y + 13, ELECTRIC);
        bolt(ctx, x - 28, y - 4, 30, 11L, GOLD, w, 100000);
        bolt(ctx, x + tw + 28, y - 4, 30, 23L, GOLD, w, 100000);
    }
}
