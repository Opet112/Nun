package dev.zenith.util;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

import java.util.Random;

/** Zeus / lightning look shared by the HUD, title screen and loading screens. */
public final class ZeusTheme {
    private ZeusTheme() {}

    public static final int GOLD = 0xFFFFD84A;
    public static final int ELECTRIC = 0xFF6FD3FF;
    public static final int STORM_TOP = 0xFF050A1C;
    public static final int STORM_BOTTOM = 0xFF1B2C5E;

    public static int lerp(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Gold-to-electric-blue pulse; {@code offset} shifts it per row. */
    public static int accent(int offset) {
        double t = (System.currentTimeMillis() % 2400L) / 2400.0 * Math.PI * 2 + offset * 0.5;
        return lerp(GOLD, ELECTRIC, (float) (Math.sin(t) * 0.5 + 0.5));
    }

    /** A jagged bolt from (x, y) down {@code length} pixels; the same seed always gives the same shape. */
    public static void bolt(DrawContext ctx, int x, int y, int length, long seed, int color, int w, int h) {
        Random rnd = new Random(seed);
        int cx = x, cy = y;
        int end = y + length;
        while (cy < end) {
            int dy = 6 + rnd.nextInt(10);
            int nx = cx + rnd.nextInt(17) - 8;
            int ny = Math.min(end, cy + dy);
            DrawUtil.line(ctx, cx - 1, cy, nx - 1, ny, (color & 0xFFFFFF) | 0x40000000, w, h);
            DrawUtil.line(ctx, cx + 1, cy, nx + 1, ny, (color & 0xFFFFFF) | 0x40000000, w, h);
            DrawUtil.line(ctx, cx, cy, nx, ny, 0xFFFFFFFF, w, h);
            cx = nx;
            cy = ny;
        }
    }

    /** Storm sky with bolts that flash every couple of seconds. {@code tint} 0..255 is the sky opacity. */
    public static void storm(DrawContext ctx, int w, int h, int tint) {
        ctx.fillGradient(0, 0, w, h, (tint << 24) | (STORM_TOP & 0xFFFFFF), (tint << 24) | (STORM_BOTTOM & 0xFFFFFF));
        long now = System.currentTimeMillis();
        long bucket = now / 2600L;
        long phase = now % 2600L;
        if (phase < 260L) {
            int flash = (int) ((1.0 - phase / 260.0) * 70);
            ctx.fill(0, 0, w, h, (flash << 24) | 0xCFE8FF);
            Random rnd = new Random(bucket * 31L);
            int bolts = 1 + rnd.nextInt(3);
            for (int i = 0; i < bolts; i++) {
                bolt(ctx, rnd.nextInt(Math.max(1, w)), 0, h / 2 + rnd.nextInt(Math.max(1, h / 3)), bucket * 97L + i, ELECTRIC, w, h);
            }
        }
    }

    /** Centered "ZENITH" banner with bolts on both sides. */
    public static void banner(DrawContext ctx, TextRenderer tr, int w, int y, String subtitle) {
        String title = "Z E N I T H";
        int tw = tr.getWidth(title);
        int x = w / 2 - tw / 2;
        ctx.fill(x - 18, y - 6, x + tw + 18, y + 26, 0x90050A1C);
        DrawUtil.outline(ctx, x - 18, y - 6, x + tw + 17, y + 25, accent(0));
        ctx.drawCenteredTextWithShadow(tr, title, w / 2, y, accent(0));
        ctx.drawCenteredTextWithShadow(tr, subtitle, w / 2, y + 13, ELECTRIC);
        bolt(ctx, x - 28, y - 4, 30, 11L, GOLD, w, 100000);
        bolt(ctx, x + tw + 28, y - 4, 30, 23L, GOLD, w, 100000);
    }

    // ---- painted scene (storm sky, golden glow, clouds, floating islands, temple) ----

    private static int shade(int argb, int alpha) { return (alpha << 24) | (argb & 0xFFFFFF); }

    /** Full-screen storm scene. {@code temple} adds the lit temple island on the right. */
    public static void scene(DrawContext ctx, int w, int h, boolean temple) {
        long now = System.currentTimeMillis();
        int u = Math.max(1, h / 240);
        int split = h * 55 / 100;
        ctx.fillGradient(0, 0, w, split, 0xFF050917, 0xFF141F4A);
        ctx.fillGradient(0, split, w, h, 0xFF141F4A, 0xFF4A3220);

        // warm glow low on the right
        int gx = w * 76 / 100, gy = h * 72 / 100;
        for (int layer = 0; layer < 3; layer++) {
            int r = h * (36 - layer * 9) / 100;
            for (int dy = -r; dy <= r; dy += 3) {
                int hw = (int) (Math.sqrt((double) r * r - (double) dy * dy) * 1.9);
                ctx.fill(gx - hw, gy + dy, gx + hw, gy + dy + 3, shade(0xFFB347, 22));
            }
        }

        // drifting clouds
        Random rnd = new Random(7);
        for (int c = 0; c < 16; c++) {
            double speed = 0.004 + rnd.nextDouble() * 0.010;
            int cw = (60 + rnd.nextInt(120)) * u, ch = (10 + rnd.nextInt(14)) * u;
            int cy = (int) (rnd.nextDouble() * h * 0.8);
            int start = rnd.nextInt(w + 400);
            int x = (int) ((start + now * speed * u) % (w + cw * 2)) - cw;
            boolean warm = cy > h * 45 / 100;
            for (int k = 0; k < 5; k++) {
                int bw = cw - Math.abs(k - 2) * cw / 6;
                int bx = x + (cw - bw) / 2, by = cy + k * ch / 5;
                int col = warm ? (k == 4 ? shade(0xE0A04A, 120) : shade(0x2A1D2E, 140)) : (k == 0 ? shade(0x6FD3FF, 60) : shade(0x080D24, 150));
                ctx.fill(bx, by, bx + bw, by + ch / 5 + 1, col);
            }
        }

        // floating islands
        island(ctx, w * 14 / 100, h * 30 / 100, 26 * u, 22 * u, u);
        island(ctx, w * 90 / 100, h * 20 / 100, 20 * u, 16 * u, u);
        if (temple) {
            int cx = w * 76 / 100, top = h * 66 / 100;
            island(ctx, cx, top, 58 * u, 36 * u, u);
            templeAt(ctx, cx, top, u);
        } else {
            island(ctx, w * 78 / 100, h * 68 / 100, 34 * u, 26 * u, u);
        }

        lightning(ctx, w, h, now);

        ctx.fillGradient(0, h * 72 / 100, w, h, 0x00000000, 0xAA000000);
        ctx.fillGradient(0, 0, w, h * 22 / 100, 0x99000000, 0x00000000);
    }

    private static void island(DrawContext ctx, int cx, int topY, int halfW, int depth, int u) {
        for (int i = 0; i < depth; i++) {
            double f = 1.0 - (double) i / depth;
            int hw = (int) (halfW * Math.pow(f, 0.7));
            int col = lerp(0xFF2B2417, 0xFF0B0D12, (float) i / depth);
            ctx.fill(cx - hw, topY + i, cx + hw, topY + i + 1, col);
        }
        ctx.fill(cx - halfW, topY - u, cx + halfW, topY + 2 * u, 0xFF2C4A2E);
        ctx.fill(cx - halfW, topY - u, cx + halfW, topY, 0xFF3F6A3A);
        int fx = cx - halfW / 3;
        ctx.fill(fx, topY + depth / 3, fx + u, topY + depth + 70 * u, shade(0xBFE6FF, 90));
    }

    private static void templeAt(DrawContext ctx, int cx, int baseY, int u) {
        int tw = 44 * u, th = 18 * u;
        int left = cx - tw / 2;
        ctx.fill(left - 3 * u, baseY - th - 12 * u, left + tw + 3 * u, baseY, shade(0xFFC857, 34));
        ctx.fill(left - 2 * u, baseY - u, left + tw + 2 * u, baseY, 0xFFB8A682);
        ctx.fill(left - u, baseY - 2 * u, left + tw + u, baseY - u, 0xFFD2C29A);
        int n = 7, cwid = 2 * u, gap = (tw - cwid) / (n - 1);
        for (int i = 0; i < n - 1; i++) {
            int x = left + i * gap + cwid;
            ctx.fill(x, baseY - th + 2 * u, x + gap - cwid, baseY - 2 * u, shade(0xFFC857, 150));
        }
        for (int i = 0; i < n; i++) {
            int x = left + i * gap;
            ctx.fill(x, baseY - th, x + cwid, baseY - 2 * u, 0xFFE6D8B0);
            ctx.fill(x + cwid - u, baseY - th, x + cwid, baseY - 2 * u, 0xFFB9A57A);
        }
        ctx.fill(left - u, baseY - th - 2 * u, left + tw + u, baseY - th, 0xFFD8C89E);
        int rows = 9 * u;
        for (int r = 0; r < rows; r++) {
            int hw = (tw / 2 + u) * (rows - r) / rows;
            ctx.fill(cx - hw, baseY - th - 2 * u - r - 1, cx + hw, baseY - th - 2 * u - r, r == 0 ? 0xFFFFD27A : 0xFFC9B78C);
        }
    }

    private static void lightning(DrawContext ctx, int w, int h, long now) {
        long period = 2600L, bucket = now / period, phase = now % period;
        boolean flick = phase < 120L || (phase > 190L && phase < 300L);
        if (!flick) return;
        int flash = phase < 120L ? 55 : 30;
        ctx.fill(0, 0, w, h, (flash << 24) | 0xCFE8FF);
        Random rnd = new Random(bucket * 31L);
        int bolts = 1 + rnd.nextInt(3);
        for (int i = 0; i < bolts; i++) {
            bolt(ctx, rnd.nextInt(Math.max(1, w)), 0, h * 45 / 100 + rnd.nextInt(Math.max(1, h / 3)), bucket * 97L + i, ELECTRIC, w, h);
        }
    }

    /** Gold-framed progress bar with a label above and the percentage below. */
    public static void progressBar(DrawContext ctx, TextRenderer tr, int cx, int y, int w, float frac, String label) {
        frac = Math.max(0f, Math.min(1f, frac));
        int x0 = cx - w / 2;
        ctx.drawCenteredTextWithShadow(tr, label, cx, y - 14, 0xFFEDE6CC);
        ctx.fill(x0 - 3, y - 3, x0 + w + 3, y + 9, 0xFF8A6414);
        ctx.fill(x0 - 2, y - 2, x0 + w + 2, y + 8, 0xFFFFD84A);
        ctx.fill(x0 - 1, y - 1, x0 + w + 1, y + 7, 0xFF0B1030);
        int fw = (int) (w * frac);
        if (fw > 0) {
            ctx.fillGradient(x0, y, x0 + fw, y + 6, 0xFFFFEE99, 0xFFE0A81C);
            int sx = x0 + (int) ((System.currentTimeMillis() % 1400L) / 1400.0 * (fw + 20)) - 10;
            int a = Math.max(x0, sx), b = Math.min(x0 + fw, sx + 10);
            if (b > a) ctx.fill(a, y, b, y + 6, 0x66FFFFFF);
        }
        ctx.drawCenteredTextWithShadow(tr, (int) (frac * 100) + "%", cx, y + 14, 0xFFEDE6CC);
    }
}
