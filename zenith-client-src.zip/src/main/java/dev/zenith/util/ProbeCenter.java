package dev.zenith.util;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Asks the server what a far block really is. A block action aimed at a position outside interaction range is
 * refused, and the server answers every refusal with a block update carrying the true state. That answer is what
 * tells a real ore from a decoy. The packet mixin feeds answers in here.
 */
public final class ProbeCenter {
    private static final Set<Long> WAITING = ConcurrentHashMap.newKeySet();
    private static final Map<Long, Block> ANSWERS = new ConcurrentHashMap<>();

    private ProbeCenter() {}

    /** Network thread: record the reply, but only for positions we actually asked about. */
    public static void answered(BlockPos pos, BlockState state) {
        long k = pos.asLong();
        if (WAITING.remove(k)) ANSWERS.put(k, state.getBlock());
    }

    public static Block answer(long pos) { return ANSWERS.get(pos); }
    public static void forget(long pos) { ANSWERS.remove(pos); WAITING.remove(pos); }
    public static void clear() { ANSWERS.clear(); WAITING.clear(); }

    public static void send(long pos) {
        var h = MinecraftClient.getInstance().getNetworkHandler();
        if (h == null) return;
        WAITING.add(pos);
        h.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK, BlockPos.fromLong(pos), Direction.UP));
    }
}
