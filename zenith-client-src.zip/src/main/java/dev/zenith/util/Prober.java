package dev.zenith.util;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;

import java.util.*;
import java.util.function.Predicate;

/** Drives ProbeCenter for one module: picks the nearest unchecked candidates, collects the server's answers. */
public final class Prober {
    private final Map<Long, Integer> probing = new HashMap<>();
    private final Set<Long> noReply = new HashSet<>();
    public final Set<Long> rejected = new HashSet<>();
    private int tick;
    private double carry;

    public void clear() {
        probing.clear(); noReply.clear(); rejected.clear(); carry = 0;
        ProbeCenter.clear();
    }

    public int pending() { return probing.size(); }
    public int silent() { return noReply.size(); }

    public void step(Collection<Long> candidates, Map<Long, Block> verified, Predicate<Block> wanted, double perSecond) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        tick++;
        Iterator<Map.Entry<Long, Integer>> it = probing.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Long, Integer> e = it.next();
            Block a = ProbeCenter.answer(e.getKey());
            if (a != null) {
                ProbeCenter.forget(e.getKey());
                if (wanted.test(a)) verified.put(e.getKey(), a); else rejected.add(e.getKey());
                it.remove();
            } else if (tick - e.getValue() > 100) {
                ProbeCenter.forget(e.getKey());
                noReply.add(e.getKey());
                it.remove();
            }
        }
        carry += perSecond / 20.0;
        int n = Math.min(5, (int) carry);
        carry -= n;
        if (n <= 0 || probing.size() > 40) return;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        for (int i = 0; i < n; i++) {
            long best = Long.MIN_VALUE;
            double bd = Double.MAX_VALUE;
            for (Long c : candidates) {
                if (verified.containsKey(c) || rejected.contains(c) || probing.containsKey(c) || noReply.contains(c)) continue;
                double d = net.minecraft.util.math.BlockPos.fromLong(c).getSquaredDistance(px, py, pz);
                if (d < 49 || d >= bd) continue; // inside ~7 blocks the server already shows the truth
                bd = d; best = c;
            }
            if (best == Long.MIN_VALUE) return;
            probing.put(best, tick);
            ProbeCenter.send(best);
        }
    }
}
