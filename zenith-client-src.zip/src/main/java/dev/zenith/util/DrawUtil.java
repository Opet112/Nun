package dev.zenith.util;

import net.minecraft.client.gui.DrawContext;

public final class DrawUtil {
    private DrawUtil() {}

    public static void line(DrawContext ctx, double x0, double y0, double x1, double y1, int color, int w, int h) {
        double dx = x1 - x0, dy = y1 - y0;
        int steps = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (steps <= 0 || steps > 6000) return;
        double sx = dx / steps, sy = dy / steps;
        double x = x0, y = y0;
        for (int i = 0; i <= steps; i++) {
            if (x >= 0 && y >= 0 && x < w && y < h) ctx.fill((int) x, (int) y, (int) x + 1, (int) y + 1, color);
            x += sx;
            y += sy;
        }
    }

    public static void outline(DrawContext ctx, int x0, int y0, int x1, int y1, int color) {
        ctx.fill(x0, y0, x1 + 1, y0 + 1, color);
        ctx.fill(x0, y1, x1 + 1, y1 + 1, color);
        ctx.fill(x0, y0, x0 + 1, y1 + 1, color);
        ctx.fill(x1, y0, x1 + 1, y1 + 1, color);
    }

    /**
     * Fills the silhouette of a world-space box with a translucent colour (the block looks tinted instead of
     * boxed in). Returns false when a corner is behind the camera so the caller can fall back.
     */
    public static boolean fillBlock(DrawContext ctx, Projector pr, net.minecraft.util.math.Box b, int argb) {
        double[][] p = new double[8][];
        for (int i = 0; i < 8; i++) {
            p[i] = pr.project(new net.minecraft.util.math.Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ));
            if (p[i] == null) return false;
        }
        // convex hull (monotone chain) of the 8 projected corners
        java.util.Arrays.sort(p, (a, c) -> a[0] != c[0] ? Double.compare(a[0], c[0]) : Double.compare(a[1], c[1]));
        double[][] hull = new double[16][];
        int k = 0;
        for (int i = 0; i < 8; i++) {
            while (k >= 2 && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
            hull[k++] = p[i];
        }
        for (int i = 6, t = k + 1; i >= 0; i--) {
            while (k >= t && cross(hull[k - 2], hull[k - 1], p[i]) <= 0) k--;
            hull[k++] = p[i];
        }
        k--; // last point equals the first
        if (k < 3) return true;
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < k; i++) { minY = Math.min(minY, hull[i][1]); maxY = Math.max(maxY, hull[i][1]); }
        int y0 = Math.max(0, (int) Math.floor(minY)), y1 = Math.min(pr.height - 1, (int) Math.ceil(maxY));
        int step = (y1 - y0) > 160 ? 2 : 1;
        for (int y = y0; y <= y1; y += step) {
            double cy = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < k; i++) {
                double[] a = hull[i], c = hull[(i + 1) % k];
                if ((a[1] <= cy && c[1] > cy) || (c[1] <= cy && a[1] > cy)) {
                    double x = a[0] + (cy - a[1]) / (c[1] - a[1]) * (c[0] - a[0]);
                    lo = Math.min(lo, x);
                    hi = Math.max(hi, x);
                }
            }
            if (lo < hi) ctx.fill((int) Math.max(0, lo), y, (int) Math.min(pr.width, Math.ceil(hi)), y + step, argb);
        }
        return true;
    }

    private static double cross(double[] o, double[] a, double[] b) {
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    }
}
