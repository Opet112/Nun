package dev.zenith.util;

import dev.zenith.ZenithClient;
import dev.zenith.gui.ClickGuiScreen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Dark indigo "glass" backdrop used by the title and loading screens: soft glows, drifting stars, wordmark. */
public final class GlassScene {
    private GlassScene() {}

    private static final int TOP = 0xFF06071A, BOTTOM = 0xFF17133F;
    public static final int INDIGO = 0xFF6C63FF, VIOLET = 0xFFB57EDC, ICE = 0xFF5FD0FF;

    /** Letters of the wordmark change colour smoothly between indigo, violet and ice blue. */
    public static int wave(int i, float speed) {
        double t = (System.currentTimeMillis() * speed) / 1000.0 + i * 0.45;
        float f = (float) (Math.sin(t) * 0.5 + 0.5);
        return f < 0.5f ? ZeusTheme.lerp(INDIGO, VIOLET, f * 2f) : ZeusTheme.lerp(VIOLET, ICE, (f - 0.5f) * 2f);
    }

    private static void glow(DrawContext ctx, int cx, int cy, int radius, int color, int maxAlpha) {
        for (int r = radius; r > 4; r -= Math.max(3, radius / 14)) {
            int a = (int) (maxAlpha * Math.pow(1.0 - r / (double) radius, 1.6));
            if (a < 1) continue;
            ClickGuiScreen.rr(ctx, cx - r, cy - r, r * 2, r * 2, r, (a << 24) | (color & 0xFFFFFF));
        }
    }

    public static void background(DrawContext ctx, int w, int h) {
        ctx.fillGradient(0, 0, w, h, TOP, BOTTOM);
        double t = System.currentTimeMillis() / 1000.0;
        glow(ctx, (int) (w * (0.25 + 0.06 * Math.sin(t * 0.35))), (int) (h * (0.35 + 0.05 * Math.cos(t * 0.3))), h / 2, INDIGO, 46);
        glow(ctx, (int) (w * (0.78 + 0.05 * Math.cos(t * 0.28))), (int) (h * (0.65 + 0.06 * Math.sin(t * 0.4))), h * 45 / 100, VIOLET, 34);
        glow(ctx, (int) (w * 0.55), (int) (h * (0.15 + 0.03 * Math.sin(t * 0.5))), h / 3, ICE, 20);

        // twinkling stars drifting upwards, deterministic per index
        Random rnd = new Random(7);
        for (int i = 0; i < 70; i++) {
            double bx = rnd.nextDouble() * w, by = rnd.nextDouble() * h;
            double speed = 2 + rnd.nextDouble() * 6;
            double phase = rnd.nextDouble() * 6.28;
            int x = (int) bx;
            int y = (int) (((by - t * speed) % h + h) % h);
            int a = (int) (60 + 150 * (0.5 + 0.5 * Math.sin(t * 1.4 + phase)));
            int size = i % 9 == 0 ? 2 : 1;
            ctx.fill(x, y, x + size, y + size, (a << 24) | 0xDCE4FF);
        }
        // soft vignette
        ctx.fillGradient(0, 0, w, h / 5, 0x70000000, 0x00000000);
        ctx.fillGradient(0, h * 4 / 5, w, h, 0x00000000, 0x80000000);
    }

    /** Big wordmark made of moving-colour letters. */
    public static void wordmark(DrawContext ctx, TextRenderer tr, int cx, int y, float scale, String text) {
        int total = 0;
        for (int i = 0; i < text.length(); i++) total += tr.getWidth(String.valueOf(text.charAt(i))) + 2;
        total -= 2;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, y);
        m.scale(scale, scale);
        int x = -total / 2;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            ctx.drawText(tr, ch, x, 0, wave(i, 1.3f) | 0xFF000000, true);
            x += tr.getWidth(ch) + 2;
        }
        m.popMatrix();
    }

    /** Rounded progress bar with a moving shine. */
    public static void progress(DrawContext ctx, TextRenderer tr, int cx, int y, int w, float frac, String label) {
        frac = Math.max(0f, Math.min(1f, frac));
        int x0 = cx - w / 2;
        ctx.drawCenteredTextWithShadow(tr, label, cx, y - 14, 0xFFC9CED8);
        ClickGuiScreen.rr(ctx, x0, y, w, 6, 3, 0xB0141733);
        int fw = (int) (w * frac);
        if (fw >= 6) {
            ClickGuiScreen.rr(ctx, x0, y, fw, 6, 3, wave(0, 1.3f) | 0xFF000000);
            int sx = x0 + (int) ((System.currentTimeMillis() % 1400L) / 1400.0 * (fw + 24)) - 12;
            int a = Math.max(x0 + 2, sx), b = Math.min(x0 + fw - 2, sx + 12);
            if (b > a) ctx.fill(a, y + 1, b, y + 5, 0x55FFFFFF);
        }
        ctx.drawCenteredTextWithShadow(tr, (int) (frac * 100) + "%", cx, y + 12, 0xFF8E95A8);
    }

    /** Title screen backdrop: wordmark above the buttons. */
    public static void title(DrawContext ctx, TextRenderer tr, int w, int h) {
        background(ctx, w, h);
        wordmark(ctx, tr, w / 2, Math.max(8, h / 4 - 40), 3.0f, "ZENITH");
        ctx.drawCenteredTextWithShadow(tr, "C L I E N T", w / 2, Math.max(8, h / 4 - 40) + 32, 0xFF8E95A8);
    }

    /** Loading screens: glass card in the middle with a spinner. */
    public static void loading(DrawContext ctx, TextRenderer tr, int w, int h) {
        background(ctx, w, h);
        int cw = Math.min(220, w - 40), ch = 70, x = w / 2 - cw / 2, y = h / 2 - ch / 2;
        ClickGuiScreen.rr(ctx, x - 1, y - 1, cw + 2, ch + 2, 11, 0x30FFFFFF);
        ClickGuiScreen.rr(ctx, x, y, cw, ch, 10, 0xC80B0C1F);
        wordmark(ctx, tr, w / 2, y + 10, 1.6f, "ZENITH");
        int dots = 5;
        long now = System.currentTimeMillis();
        for (int i = 0; i < dots; i++) {
            double ph = (now / 120.0 - i) % dots;
            int a = (int) (60 + 195 * Math.max(0, 1.0 - Math.abs(ph) / 2.0));
            int dx = w / 2 - (dots * 10) / 2 + i * 10 + 2;
            ClickGuiScreen.rr(ctx, dx, y + ch - 20, 6, 6, 3, (Math.min(255, a) << 24) | 0x6C63FF);
        }
    }
}
