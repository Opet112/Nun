package dev.zenith.gui;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.module.ModuleManager;
import dev.zenith.module.impl.HudModule;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/**
 * Zenith ClickGUI. A slim icon rail on the left switches between categories and general pages, the main area shows
 * the modules as a two-column grid of cards (name, description, switch, key bind). A click on a card opens a full
 * settings page for that module.
 *
 * Left click on the switch toggles, click on the card opens settings, middle click binds a key.
 * Mouse and keyboard are polled from GLFW every frame instead of overriding the input callbacks, so the screen does
 * not depend on the (frequently changing) input event classes. Only the mouse wheel uses a screen callback.
 */
public class ClickGuiScreen extends Screen {
    private static final int RAIL_W = 40;
    private static final int P_SETTINGS = 10, P_THEMES = 11, P_CONFIGS = 12, P_KEYBINDS = 13, P_STATS = 14;
    private static final int ROWH = 30, STEP = 33;
    private static final int CARD_H = 46, GAP = 6;
    private static final long START = System.currentTimeMillis();

    private static final int WIN_BG = 0xE608091A;
    private static final int RAIL_BG = 0xF005060F;
    private static final int ROW_BG = 0xB8121528;
    private static final int ROW_HOVER = 0xD01B2040;
    private static final int SUB_BG = 0xB40B0D20;
    private static final int OFF = 0xFF2A2E4A;
    private static final int MUTED = 0xFF5C6384;
    private static final int DESC = 0xFF6F769A;

    private static int wx = Integer.MIN_VALUE, wy;
    private static int page = 0;
    private static String search = "";
    private static boolean onlyEnabled;
    /** Module whose detail page is open (replaces the module list), or null. */
    private static Module OPEN;

    private final boolean[] mouseDown = new boolean[3];
    private final boolean[] keyWasDown = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private boolean closeKeyWasDown = true;
    private boolean escWasDown = true;

    private int winW, winH;
    private boolean dragWin;
    private int dragOffX, dragOffY;
    private Setting.Num draggingSlider;
    private int sliderX, sliderW;
    private Module binding;
    private boolean searchFocused;
    private double scroll;
    private double pendingScroll;
    private boolean inList;
    private boolean draggingBar;
    private String tipText;
    private int tipY;

    private final long openedAt = System.currentTimeMillis();

    public ClickGuiScreen() {
        super(Text.literal("Zenith"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null && !searchFocused; }

    @Override
    public void removed() {
        ZenithClient.config().save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        pendingScroll += verticalAmount;
        return true;
    }

    // ------------------------------------------------------------------------------------------ drawing helpers

    /** Filled rounded rectangle (scan-line corners, no textures). */
    public static void rr(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    private static final java.util.Map<Object, Float> ANIM = new java.util.HashMap<>();

    /** Smoothly chases {@code target}; one value per key, advanced each frame. */
    private static float anim(Object key, float target) {
        float v = ANIM.getOrDefault(key, target);
        v += (target - v) * 0.28f;
        if (Math.abs(target - v) < 0.01f) v = target;
        ANIM.put(key, v);
        return v;
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = 0;
        for (int sh = 24; sh >= 0; sh -= 8) {
            int ca = (a >>> sh) & 0xFF, cb = (b >>> sh) & 0xFF;
            r |= ((int) (ca + (cb - ca) * t) & 0xFF) << sh;
        }
        return r;
    }

    private static void sw(DrawContext ctx, int x, int y, int w, int h, boolean on, int accent, Object key) {
        float t = anim(key, on ? 1f : 0f);
        if (t > 0.05f) rr(ctx, x - 1, y - 1, w + 2, h + 2, (h + 2) / 2, ColorUtil.withAlpha(accent, (int) (0x30 * t))); // glow
        rr(ctx, x, y, w, h, h / 2, mix(OFF, accent, t));
        int k = h - 4;
        int kx = x + 2 + (int) ((w - k - 4) * t);
        rr(ctx, kx, y + 2, k, k, k / 2, mix(0xFF8A90B0, 0xFFFFFFFF, t));
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Hit test that also requires the mouse to be inside the scrolling list. */
    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return inList && inside(mx, my, x, y, w, h);
    }

    private static void bigText(DrawContext ctx, TextRenderer tr, Text t, int x, int y, float scale, int color) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        ctx.drawText(tr, t, 0, 0, color, true);
        m.popMatrix();
    }

    private static Text bold(String s) {
        return Text.literal(s).styled(st -> st.withBold(true));
    }

    private static String pageTitle(int p) {
        if (!search.isEmpty() && p < 10) return "Search";
        if (p < 10) return catLabel(Category.values()[p]);
        return switch (p) {
            case P_SETTINGS -> "Settings";
            case P_THEMES -> "Themes";
            case P_STATS -> "Stats";
            case P_CONFIGS -> "Configs";
            default -> "Keybinds";
        };
    }

    private static String catLabel(Category c) {
        return c == Category.RENDER ? "Visual" : c.label;
    }

    private static String catGlyph(Category c) {
        return switch (c) {
            case COMBAT -> "C";
            case MOVEMENT -> "M";
            case RENDER -> "V";
            case PLAYER -> "P";
            case MISC -> "X";
            default -> "Z";
        };
    }

    // ------------------------------------------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        long window = mc.getWindow().getHandle();
        TextRenderer tr = mc.textRenderer;

        boolean[] pressed = {
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS
        };
        boolean[] clicked = new boolean[3];
        for (int i = 0; i < 3; i++) {
            clicked[i] = pressed[i] && !mouseDown[i];
            mouseDown[i] = pressed[i];
        }
        if (!pressed[0]) { dragWin = false; draggingSlider = null; }

        handleKeys(window);

        winW = Math.min(width - 16, 600);
        winH = Math.min(height - 16, 330);
        if (wx == Integer.MIN_VALUE) { wx = (width - winW) / 2; wy = (height - winH) / 2; }
        if (dragWin) { wx = mx - dragOffX; wy = my - dragOffY; }
        wx = Math.max(0, Math.min(width - winW, wx));
        wy = Math.max(0, Math.min(height - winH, wy));

        if (draggingSlider != null) {
            double t = Math.max(0, Math.min(1, (mx - sliderX) / (double) sliderW));
            draggingSlider.set(draggingSlider.min + t * (draggingSlider.max - draggingSlider.min));
        }

        int accent = ColorUtil.accent(0);
        float op = Math.min(1f, (System.currentTimeMillis() - openedAt) / 260f);
        op = 1f - (1f - op) * (1f - op) * (1f - op); // ease-out
        int slide = dragWin ? 0 : (int) ((1f - op) * 16);
        ctx.fillGradient(0, 0, width, height, (int) (0x40 * op) << 24, (int) (0xA0 * op) << 24); // vignette behind the window
        wy += slide;
        for (int i = 10; i >= 1; i--) rr(ctx, wx - i, wy - i + 5, winW + 2 * i, winH + 2 * i, 12 + i, ((int) (0x0B * op)) << 24); // soft shadow
        rr(ctx, wx - 1, wy - 1, winW + 2, winH + 2, 13, mix(0x30FFFFFF, ColorUtil.withAlpha(accent, 0x80), 0.55f)); // border
        rr(ctx, wx, wy, winW, winH, 12, WIN_BG);
        ctx.fillGradient(wx + 8, wy + 1, wx + winW - 8, wy + 56, ColorUtil.withAlpha(accent, 0x26), 0x00000000);
        ctx.fill(wx + 18, wy, wx + winW - 18, wy + 1, ColorUtil.withAlpha(accent, 0xD0));

        tipText = null;
        drawRail(ctx, tr, mx, my, clicked, accent);
        drawContent(ctx, tr, mx, my, clicked, accent);
        if (tipText != null) { // rail tooltip, drawn last so nothing covers it
            int tw = tr.getWidth(tipText) + 12;
            int tx = wx + RAIL_W + 2, ty = tipY;
            rr(ctx, tx, ty, tw, 16, 6, 0xF0050610);
            rr(ctx, tx, ty, 2, 16, 1, accent);
            ctx.drawText(tr, tipText, tx + 7, ty + 4, ColorUtil.TEXT, true);
        }
        wy -= slide;

        String hint = binding != null
                ? "Press a key for " + binding.name + "  (Esc = cancel, Backspace = clear)"
                : "Switch: toggle   Card: settings   Middle click: bind   Right Shift / Esc: close";
        ctx.drawText(tr, hint, wx + 4, wy + winH + 4, ColorUtil.TEXT_DIM, true);
    }

    // -------------------------------------------------------------------------------------------------- rail

    private void drawRail(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int rx = wx + 5, ry = wy + 5, rw = RAIL_W - 5, rh = winH - 10;
        rr(ctx, rx, ry, rw, rh, 9, RAIL_BG);

        // logo (also the drag handle)
        int lx = rx + (rw - 24) / 2, ly = ry + 6;
        rr(ctx, lx - 1, ly - 1, 26, 26, 8, ColorUtil.withAlpha(accent, 0x38));
        rr(ctx, lx, ly, 24, 24, 7, accent);
        ctx.drawText(tr, Text.literal("Z").styled(s -> s.withBold(true)), lx + 12 - tr.getWidth("Z") / 2 - 1, ly + 8, 0xFFFFFFFF, true);
        if (clicked[0] && inside(mx, my, rx, ry, rw, 34)) {
            dragWin = true;
            dragOffX = mx - wx;
            dragOffY = my - wy;
        }

        int count = Category.values().length + 5;
        int avail = rh - 42 - 8;
        int step = Math.min(27, avail / count);
        int size = step - 2;
        int y = ry + 38;
        for (Category c : Category.values()) {
            y = railItem(ctx, tr, rx, y, rw, size, step, catGlyph(c), catLabel(c) + " (" + ZenithClient.modules().in(c).size() + ")",
                    page == c.ordinal(), mx, my, clicked, accent, c.ordinal());
        }
        ctx.fill(rx + 9, y + 2, rx + rw - 9, y + 3, 0x30FFFFFF);
        y += 6;
        y = railItem(ctx, tr, rx, y, rw, size, step, "S", "Settings", page == P_SETTINGS, mx, my, clicked, accent, P_SETTINGS);
        y = railItem(ctx, tr, rx, y, rw, size, step, "#", "Stats", page == P_STATS, mx, my, clicked, accent, P_STATS);
        y = railItem(ctx, tr, rx, y, rw, size, step, "T", "Themes", page == P_THEMES, mx, my, clicked, accent, P_THEMES);
        y = railItem(ctx, tr, rx, y, rw, size, step, "F", "Configs", page == P_CONFIGS, mx, my, clicked, accent, P_CONFIGS);
        railItem(ctx, tr, rx, y, rw, size, step, "K", "Keybinds", page == P_KEYBINDS, mx, my, clicked, accent, P_KEYBINDS);
    }

    private int railItem(DrawContext ctx, TextRenderer tr, int rx, int y, int rw, int size, int step, String glyph,
                         String label, boolean selected, int mx, int my, boolean[] clicked, int accent, int target) {
        int bx = rx + (rw - 26) / 2, bw = 26;
        boolean hover = inside(mx, my, bx, y, bw, size);
        float sel = anim("rail" + target + "s", selected ? 1f : 0f);
        float hov = anim("rail" + target + "h", hover ? 1f : 0f);
        if (hov > 0.02f) rr(ctx, bx, y, bw, size, 7, ((int) (0x26 * hov)) << 24 | 0xFFFFFF);
        if (sel > 0.02f) {
            rr(ctx, bx, y, bw, size, 7, ColorUtil.withAlpha(accent, (int) (0x55 * sel)));
            rr(ctx, rx, y + size / 2 - 5, 2, 10, 1, ColorUtil.withAlpha(accent, (int) (0xFF * sel)));
        }
        ctx.drawText(tr, glyph, bx + bw / 2 - tr.getWidth(glyph) / 2, y + size / 2 - 4,
                mix(0xFF7E86A8, ColorUtil.TEXT, Math.max(sel, hov * 0.8f)), true);
        if (hover) { tipText = label; tipY = y + size / 2 - 8; }
        if (hover && clicked[0] && !dragWin) {
            if (page != target || OPEN != null) { page = target; scroll = 0; }
            OPEN = null;
            search = "";
            searchFocused = false;
        }
        return y + step;
    }

    // ------------------------------------------------------------------------------------------------ content

    private void drawContent(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int cx = wx + RAIL_W + 10, cw = winW - RAIL_W - 26;
        boolean modulePage = page < 10;
        boolean detailPage = modulePage && OPEN != null;

        // title block (drag handle too)
        String title = detailPage ? OPEN.name : pageTitle(page);
        bigText(ctx, tr, bold(title), cx, wy + 9, 1.35f, ColorUtil.TEXT);
        if (clicked[0] && inside(mx, my, cx, wy, Math.min(cw / 2, 150), 26) && !detailPage) {
            dragWin = true;
            dragOffX = mx - wx;
            dragOffY = my - wy;
        }

        java.util.List<Module> list = new java.util.ArrayList<>();
        if (detailPage) {
            ctx.drawText(tr, OPEN.getSettings().size() + " settings · " + catLabel(OPEN.category), cx, wy + 26, MUTED, false);
            int bw = 52, bx = cx + cw - bw, by = wy + 10;
            boolean bh = inside(mx, my, bx, by, bw, 16);
            float hv = anim("back", bh ? 1f : 0f);
            rr(ctx, bx, by, bw, 16, 7, mix(ROW_BG, ColorUtil.withAlpha(accent, 0xB0), hv));
            ctx.drawText(tr, "< Back", bx + bw / 2 - tr.getWidth("< Back") / 2, by + 4, ColorUtil.TEXT, true);
            if (bh && clicked[0]) { OPEN = null; scroll = 0; search = ""; searchFocused = false; }
        } else if (modulePage) {
            String q = search.toLowerCase(Locale.ROOT);
            java.util.List<Module> source = q.isEmpty() ? ZenithClient.modules().in(Category.values()[page]) : ZenithClient.modules().all();
            for (Module m : source) {
                if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)
                        && !m.description.toLowerCase(Locale.ROOT).contains(q)) continue;
                list.add(m);
            }
            int on = 0;
            for (Module m : list) if (m.isEnabled()) on++;
            ctx.drawText(tr, list.size() + " modules · " + on + " enabled", cx, wy + 26, MUTED, false);

            // search pill
            int bw = Math.min(124, cw / 3), bx = cx + cw - bw, by = wy + 10;
            float sf = anim("searchfocus", searchFocused ? 1f : 0f);
            rr(ctx, bx - 1, by - 1, bw + 2, 18, 9, ColorUtil.withAlpha(accent, (int) (0x70 * sf)));
            rr(ctx, bx, by, bw, 16, 8, mix(ROW_BG, 0xFF171B38, sf));
            rr(ctx, bx + 7, by + 4, 7, 7, 3, mix(MUTED, accent, sf)); // magnifier
            rr(ctx, bx + 8, by + 5, 5, 5, 2, mix(0xFF121528, 0xFF171B38, sf));
            ctx.fill(bx + 13, by + 11, bx + 15, by + 13, mix(MUTED, accent, sf));
            String shown = search.isEmpty() && !searchFocused ? "Search"
                    : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            ctx.drawText(tr, tr.trimToWidth(shown, bw - 26), bx + 20, by + 4, search.isEmpty() ? MUTED : ColorUtil.TEXT, false);
            if (clicked[0]) searchFocused = inside(mx, my, bx, by, bw, 16);

            // All | Enabled segmented control
            String[] seg = {"All", "On"};
            int segW = 0;
            for (String s : seg) segW += tr.getWidth(s) + 16;
            int sx = bx - 8 - segW - 4;
            rr(ctx, sx, by, segW + 4, 16, 8, ROW_BG);
            int tx = sx + 2;
            for (int i = 0; i < 2; i++) {
                int w = tr.getWidth(seg[i]) + 16;
                boolean sel = (i == 1) == onlyEnabled;
                boolean hov = inside(mx, my, tx, by + 2, w, 12);
                float a = anim("seg" + i, sel ? 1f : 0f);
                if (a > 0.02f) rr(ctx, tx, by + 2, w, 12, 6, ColorUtil.withAlpha(accent, (int) (0x90 * a)));
                else if (hov) rr(ctx, tx, by + 2, w, 12, 6, 0x22FFFFFF);
                ctx.drawText(tr, seg[i], tx + 8, by + 4, sel ? 0xFFFFFFFF : ColorUtil.TEXT_DIM, false);
                if (hov && clicked[0]) { onlyEnabled = i == 1; scroll = 0; }
                tx += w;
            }
            if (onlyEnabled) list.removeIf(m -> !m.isEnabled());
        } else {
            ctx.drawText(tr, "Zenith Client", cx, wy + 26, MUTED, false);
        }

        int listTop = wy + 42, listBottom = wy + winH - 9;
        // soft divider under the header
        ctx.fill(cx, listTop - 4, cx + cw, listTop - 3, 0x18FFFFFF);
        inList = inside(mx, my, cx, listTop, cw, listBottom - listTop) && !dragWin;

        scroll -= pendingScroll * 18;
        pendingScroll = 0;

        ctx.enableScissor(cx - 2, listTop, cx + cw + 2, listBottom);
        int start = listTop - (int) scroll;
        int y = start;

        if (detailPage) {
            Module opened = OPEN; // the Back button above may have just closed the page
            if (opened != null) y = detail(ctx, tr, opened, y, cx, cw, mx, my, clicked, accent);
        } else if (modulePage) {
            int cols = cw >= 280 ? 2 : 1;
            int cardW = (cw - GAP * (cols - 1)) / cols;
            for (int i = 0; i < list.size(); i++) {
                moduleCard(ctx, tr, list.get(i), cx + (i % cols) * (cardW + GAP), start + (i / cols) * (CARD_H + GAP),
                        cardW, mx, my, clicked, accent);
            }
            y = start + ((list.size() + cols - 1) / cols) * (CARD_H + GAP);
            if (list.isEmpty()) {
                String none = onlyEnabled ? "No enabled modules here." : "Nothing found.";
                ctx.drawText(tr, none, cx + cw / 2 - tr.getWidth(none) / 2, start + 30, MUTED, false);
            }
        } else if (page == P_SETTINGS) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                for (Setting s : hud.getSettings()) {
                    drawSetting(ctx, tr, s, cx, cw, y, mx, my, clicked, accent);
                    y += 17;
                }
            }
        } else if (page == P_THEMES) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                int cols = cw >= 280 ? 3 : 2;
                int tw = (cw - GAP * (cols - 1)) / cols, i = 0;
                for (String t : hud.theme.modes) {
                    int x = cx + (i % cols) * (tw + GAP), ty = start + (i / cols) * (54 + GAP);
                    boolean sel = hud.theme.is(t);
                    boolean hov = hit(mx, my, x, ty, tw, 54);
                    float hv = anim("th" + t, hov ? 1f : 0f), sv = anim("ths" + t, sel ? 1f : 0f);
                    int col = themeColor(t);
                    rr(ctx, x - 1, ty - 1, tw + 2, 56, 9, ColorUtil.withAlpha(col, (int) (0xA0 * sv)));
                    rr(ctx, x, ty, tw, 54, 8, mix(ROW_BG, ROW_HOVER, hv));
                    ctx.fillGradient(x + 3, ty + 3, x + tw - 3, ty + 26, ColorUtil.withAlpha(col, 0x60), ColorUtil.withAlpha(col, 0x08));
                    rr(ctx, x + 9, ty + 10, 14, 14, 7, col);
                    ctx.drawText(tr, bold(t), x + 9, ty + 33, ColorUtil.TEXT, true);
                    ctx.drawText(tr, sel ? "Selected" : "Click to apply", x + 9, ty + 43, sel ? col : DESC, false);
                    if (hov && clicked[0]) {
                        for (int k = 0; k < hud.theme.modes.length && !hud.theme.is(t); k++) hud.theme.cycle();
                    }
                    i++;
                }
                y = start + ((i + cols - 1) / cols) * (54 + GAP);
            }
        } else if (page == P_STATS) {
            long secs = (System.currentTimeMillis() - START) / 1000;
            int enabled = 0;
            for (Module m : ZenithClient.modules().all()) if (m.isEnabled()) enabled++;
            String[][] rows = {
                    {"Session", String.format("%02d:%02d:%02d", secs / 3600, secs / 60 % 60, secs % 60), "Time since the game started"},
                    {"Modules", String.valueOf(ZenithClient.modules().all().size()), "Registered modules"},
                    {"Enabled", String.valueOf(enabled), "Modules switched on"},
                    {"FPS", String.valueOf(MinecraftClient.getInstance().getCurrentFps()), "Frames per second"},
            };
            int cols = 2, tw = (cw - GAP) / cols;
            for (int i = 0; i < rows.length; i++) {
                int x = cx + (i % cols) * (tw + GAP), ty = start + (i / cols) * (58 + GAP);
                rr(ctx, x, ty, tw, 58, 8, ROW_BG);
                rr(ctx, x, ty + 10, 3, 38, 1, ColorUtil.withAlpha(accent, 0xFF));
                ctx.drawText(tr, rows[i][0].toUpperCase(Locale.ROOT), x + 12, ty + 8, MUTED, false);
                bigText(ctx, tr, bold(rows[i][1]), x + 12, ty + 20, 1.6f, ColorUtil.TEXT);
                ctx.drawText(tr, rows[i][2], x + 12, ty + 45, DESC, false);
            }
            y = start + 2 * (58 + GAP);
        } else if (page == P_CONFIGS) {
            // "+ New" saves the current setup as a named profile; Apply loads it, X deletes it
            if (simpleRow(ctx, tr, "+ New config", "Save your current modules, friends, xray list and waypoints as a new profile.", "Create", y, cx, cw, mx, my, clicked)) {
                int n = 1;
                java.util.List<String> have = ZenithClient.config().profiles();
                while (have.contains("config-" + n)) n++;
                ZenithClient.config().saveProfile("config-" + n);
                ZenithClient.info("Saved config-" + n);
            }
            y += STEP;
            if (simpleRow(ctx, tr, "Default config", "The file loaded automatically at startup (zenith.json).", "Save", y, cx, cw, mx, my, clicked)) {
                ZenithClient.config().save();
                ZenithClient.info("Default config saved.");
            }
            y += STEP;
            for (String prof : ZenithClient.config().profiles()) {
                boolean hov = hit(mx, my, cx, y, cw, ROWH);
                rr(ctx, cx, y, cw, ROWH, 8, mix(ROW_BG, ROW_HOVER, anim("cf" + prof, hov ? 1f : 0f)));
                ctx.drawText(tr, bold(prof), cx + 11, y + 6, ColorUtil.TEXT, true);
                ctx.drawText(tr, tr.trimToWidth(ZenithClient.config().profileInfo(prof), cw - 120), cx + 11, y + 18, DESC, false);
                int bx = cx + cw - 94, by = y + 7;
                boolean hApply = hit(mx, my, bx, by, 48, 16), hDel = hit(mx, my, bx + 54, by, 32, 16);
                rr(ctx, bx, by, 48, 16, 6, hApply ? ColorUtil.withAlpha(accent, 0xFF) : ColorUtil.withAlpha(accent, 0xC0));
                ctx.drawText(tr, "Apply", bx + 24 - tr.getWidth("Apply") / 2, by + 4, 0xFFFFFFFF, true);
                rr(ctx, bx + 54, by, 32, 16, 6, hDel ? 0xFFB23A4A : 0xFF4A2430);
                ctx.drawText(tr, "Del", bx + 70 - tr.getWidth("Del") / 2, by + 4, 0xFFFFFFFF, true);
                if (clicked[0] && hApply) { ZenithClient.config().loadProfile(prof); ZenithClient.info("Applied " + prof); }
                if (clicked[0] && hDel) { ZenithClient.config().deleteProfile(prof); ZenithClient.info("Deleted " + prof); }
                y += STEP;
            }
        } else {
            int cols = cw >= 280 ? 2 : 1, kw = (cw - GAP * (cols - 1)) / cols, i = 0;
            for (Module m : ZenithClient.modules().all()) {
                int x = cx + (i % cols) * (kw + GAP), ky = start + (i / cols) * STEP;
                String key = binding == m ? "Press a key..." : KeyUtil.name(m.getKey());
                if (keyRow(ctx, tr, m, key, x, ky, kw, mx, my, accent) && clicked[0]) binding = m;
                i++;
            }
            y = start + ((i + cols - 1) / cols) * STEP;
        }
        ctx.disableScissor();

        int total = y - start;
        double max = Math.max(0, total - (listBottom - listTop));
        scroll = Math.max(0, Math.min(max, scroll));
        if (max > 0) { // scroll bar: click the track to jump, drag the handle to scroll
            int trackH = listBottom - listTop;
            int barH = Math.max(18, (int) (trackH * (trackH / (double) total)));
            boolean overTrack = inside(mx, my, cx + cw, listTop, 14, trackH);
            if (clicked[0] && overTrack && !dragWin) draggingBar = true;
            if (!mouseDown[0]) draggingBar = false;
            if (draggingBar) {
                double t = (my - listTop - barH / 2.0) / Math.max(1.0, trackH - barH);
                scroll = Math.max(0, Math.min(max, t * max));
            }
            int barY = listTop + (int) ((trackH - barH) * (scroll / max));
            rr(ctx, cx + cw + 5, listTop, 3, trackH, 1, 0x20FFFFFF); // faint track
            rr(ctx, cx + cw + 5, barY, 3, barH, 1, ColorUtil.withAlpha(accent, draggingBar || overTrack ? 0xFF : 0xA0));
        } else {
            draggingBar = false;
        }
    }

    private static int themeColor(String t) {
        return switch (t) {
            case "Storm" -> 0xFFE9B949;
            case "Cyan" -> 0xFF35D6E8;
            case "Purple" -> 0xFFA66BFF;
            case "Crimson" -> 0xFFE8344F;
            case "Emerald" -> 0xFF2FD27E;
            case "Indigo" -> 0xFF6C63FF;
            default -> ColorUtil.rainbow(0, 0.6f);
        };
    }

    private boolean simpleRow(DrawContext ctx, TextRenderer tr, String title, String desc, String right, int y,
                              int cx, int cw, int mx, int my, boolean[] clicked) {
        boolean hov = hit(mx, my, cx, y, cw, ROWH);
        rr(ctx, cx, y, cw, ROWH, 8, mix(ROW_BG, ROW_HOVER, anim("sr" + title, hov ? 1f : 0f)));
        ctx.drawText(tr, bold(title), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(desc, cw - 100), cx + 11, y + 18, DESC, false);
        ctx.drawText(tr, right, cx + cw - 11 - tr.getWidth(right), y + 11, ColorUtil.accent(0), true);
        return hov && clicked[0];
    }

    /** One keybind tile (module name, category, current key). Returns true while hovered. */
    private boolean keyRow(DrawContext ctx, TextRenderer tr, Module m, String key, int x, int y, int w, int mx, int my, int accent) {
        boolean hov = hit(mx, my, x, y, w, ROWH);
        rr(ctx, x, y, w, ROWH, 8, mix(ROW_BG, ROW_HOVER, anim("kr" + m.name, hov ? 1f : 0f)));
        ctx.drawText(tr, bold(m.name), x + 10, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, catLabel(m.category), x + 10, y + 18, DESC, false);
        int kw = tr.getWidth(key) + 12;
        rr(ctx, x + w - 10 - kw, y + 7, kw, 16, 6, ColorUtil.withAlpha(accent, binding == m ? 0x90 : 0x40));
        ctx.drawText(tr, key, x + w - 10 - kw + 6, y + 11, ColorUtil.TEXT, true);
        return hov;
    }

    /** One module card of the grid. */
    private void moduleCard(DrawContext ctx, TextRenderer tr, Module m, int x, int y, int w, int mx, int my,
                            boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, x, y, w, CARD_H);
        float hv = anim(m, hov ? 1f : 0f);
        float en = anim("en" + m.name, m.isEnabled() ? 1f : 0f);

        if (en > 0.02f) rr(ctx, x - 1, y - 1, w + 2, CARD_H + 2, 9, ColorUtil.withAlpha(accent, (int) (0x44 * en))); // outline when on
        rr(ctx, x, y, w, CARD_H, 8, mix(ROW_BG, ROW_HOVER, hv));
        if (en > 0.02f) {
            ctx.fillGradient(x + 2, y + 2, x + w - 2, y + CARD_H - 2, ColorUtil.withAlpha(accent, (int) (0x30 * en)), ColorUtil.withAlpha(accent, 0x04));
            ctx.fill(x + 12, y, x + w - 12, y + 1, ColorUtil.withAlpha(accent, (int) (0xE0 * en)));
        }

        String label = binding == m ? "Press a key..." : m.name;
        ctx.drawText(tr, bold(tr.trimToWidth(label, w - 56)), x + 10, y + 7, mix(0xFFB8BEDD, ColorUtil.TEXT, Math.max(en, hv)), true);
        ctx.drawText(tr, tr.trimToWidth(m.description, w - 20), x + 10, y + 19, DESC, false);

        int n = m.getSettings().size();
        String info = n == 0 ? "no settings" : n + (n == 1 ? " setting" : " settings");
        ctx.drawText(tr, info, x + 10, y + 32, mix(MUTED, ColorUtil.TEXT_DIM, hv), false);
        if (m.getKey() >= 0) {
            String k = KeyUtil.name(m.getKey());
            int kw = tr.getWidth(k) + 8;
            rr(ctx, x + w - 10 - kw, y + 30, kw, 12, 5, ColorUtil.withAlpha(accent, 0x38));
            ctx.drawText(tr, k, x + w - 10 - kw + 4, y + 32, ColorUtil.TEXT_DIM, false);
        }
        sw(ctx, x + w - 34, y + 7, 26, 13, m.isEnabled(), accent, m);

        if (hov && clicked[0]) {
            if (mx >= x + w - 40 && my < y + 24) m.toggle();
            else { OPEN = m; scroll = 0; search = ""; searchFocused = false; }
        }
        if (hov && clicked[1]) { OPEN = m; scroll = 0; search = ""; searchFocused = false; }
        if (hov && clicked[2]) binding = m;
    }

    /** Full-size settings page of one module: a tall card per setting with its own controls. */
    private int detail(DrawContext ctx, TextRenderer tr, Module m, int y, int cx, int cw, int mx, int my,
                       boolean[] clicked, int accent) {
        // header: enable switch
        boolean hh = hit(mx, my, cx, y, cw, 34);
        rr(ctx, cx, y, cw, 34, 8, mix(ROW_BG, ROW_HOVER, anim("dh", hh ? 1f : 0f)));
        rr(ctx, cx, y + 7, 3, 20, 1, ColorUtil.withAlpha(accent, m.isEnabled() ? 0xFF : 0x40));
        ctx.drawText(tr, Text.literal(m.name).styled(st -> st.withBold(true)), cx + 11, y + 7, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(m.description, cw - 70), cx + 11, y + 20, DESC, false);
        sw(ctx, cx + cw - 38, y + 10, 28, 14, m.isEnabled(), accent, m);
        if (hh && clicked[0]) m.toggle();
        y += 38;

        // keybind card
        boolean kh = hit(mx, my, cx, y, cw, 30);
        rr(ctx, cx, y, cw, 30, 8, mix(ROW_BG, ROW_HOVER, anim("dk", kh ? 1f : 0f)));
        ctx.drawText(tr, Text.literal("Keybind").styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, "Click, then press a key (Backspace clears)", cx + 11, y + 18, DESC, false);
        String key = binding == m ? "Press a key..." : KeyUtil.name(m.getKey());
        int kw = tr.getWidth(key) + 14;
        rr(ctx, cx + cw - 11 - kw, y + 7, kw, 16, 5, ColorUtil.withAlpha(accent, 0x40));
        ctx.drawText(tr, key, cx + cw - 11 - kw + 7, y + 11, ColorUtil.TEXT, true);
        if (kh && clicked[0]) binding = m;
        y += 34;

        for (Setting st : m.getSettings()) {
            if (st instanceof Setting.Bool b) {
                boolean h = hit(mx, my, cx, y, cw, 30);
                rr(ctx, cx, y, cw, 30, 8, mix(ROW_BG, ROW_HOVER, anim(b, h ? 1f : 0f)));
                ctx.drawText(tr, Text.literal(b.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                ctx.drawText(tr, b.get() ? "Enabled" : "Disabled", cx + 11, y + 18, b.get() ? accent : DESC, false);
                sw(ctx, cx + cw - 38, y + 8, 28, 14, b.get(), accent, b);
                if (h && clicked[0]) b.toggle();
                y += 34;
            } else if (st instanceof Setting.Mode mo) {
                // option chips, wrapped onto as many lines as needed
                int per = cw - 22, lines = 1, lx = 0;
                for (String o : mo.modes) {
                    int w = tr.getWidth(o) + 14;
                    if (lx + w > per && lx > 0) { lines++; lx = 0; }
                    lx += w + 4;
                }
                int h = 26 + lines * 19;
                rr(ctx, cx, y, cw, h, 8, ROW_BG);
                ctx.drawText(tr, Text.literal(mo.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                String cur = mo.get();
                ctx.drawText(tr, cur, cx + cw - 11 - tr.getWidth(cur), y + 6, accent, true);
                int ox = cx + 11, oy = y + 20;
                lx = 0;
                for (String o : mo.modes) {
                    int w = tr.getWidth(o) + 14;
                    if (lx + w > per && lx > 0) { lx = 0; oy += 19; }
                    boolean sel = mo.is(o), oh = hit(mx, my, ox + lx, oy, w, 15);
                    int bg = sel ? ColorUtil.withAlpha(accent, 0xB0) : mix(SUB_BG, ROW_HOVER, anim("o" + mo.name + o, oh ? 1f : 0f));
                    rr(ctx, ox + lx, oy, w, 15, 5, bg);
                    ctx.drawText(tr, o, ox + lx + 7, oy + 3, sel ? 0xFFFFFFFF : ColorUtil.TEXT_DIM, true);
                    if (oh && clicked[0]) for (int i = 0; i < mo.modes.length && !mo.is(o); i++) mo.cycle();
                    lx += w + 4;
                }
                y += h + 4;
            } else if (st instanceof Setting.BlockSet bs) {
                y = blockPicker(ctx, tr, bs, y, cx, cw, mx, my, clicked, accent);
            } else if (st instanceof Setting.Num n) {
                boolean h = hit(mx, my, cx, y, cw, 44);
                boolean drag = draggingSlider == n;
                float hv = anim(n, h || drag ? 1f : 0f);
                rr(ctx, cx, y, cw, 44, 8, mix(ROW_BG, ROW_HOVER, hv));
                ctx.drawText(tr, Text.literal(n.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                String val = format(n);
                ctx.drawText(tr, val, cx + cw - 11 - tr.getWidth(val), y + 6, accent, true);
                ctx.drawText(tr, format(n.min, n) + " - " + format(n.max, n) + "  ·  step " + (n.step >= 1 ? String.valueOf((int) n.step) : String.valueOf(n.step)),
                        cx + 11, y + 18, DESC, false);
                int tx = cx + 11, tw = cw - 22;
                double t = (n.get() - n.min) / (n.max - n.min);
                int fill = Math.max(2, (int) (tw * t));
                rr(ctx, tx, y + 33, tw, 4, 2, 0xFF1A1E3A);
                rr(ctx, tx, y + 33, fill, 4, 2, accent);
                int kr = 4 + (int) (hv * 2);
                rr(ctx, tx + fill - kr, y + 35 - kr, kr * 2, kr * 2, kr, 0xFFFFFFFF);
                if (h && clicked[0] && draggingSlider == null) { draggingSlider = n; sliderX = tx; sliderW = tw; }
                y += 48;
            }
        }
        return y;
    }

    private static java.util.List<String> ALL_BLOCKS;

    private static java.util.List<String> allBlocks() {
        if (ALL_BLOCKS == null) {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (net.minecraft.util.Identifier id : net.minecraft.registry.Registries.BLOCK.getIds()) {
                String p = id.getPath();
                if (p.equals("air") || p.equals("cave_air") || p.equals("void_air")) continue;
                l.add(id.toString());
            }
            java.util.Collections.sort(l);
            ALL_BLOCKS = l;
        }
        return ALL_BLOCKS;
    }

    /** Searchable list of every block in the game; click a row to tick it. */
    private int blockPicker(DrawContext ctx, TextRenderer tr, Setting.BlockSet bs, int y, int cx, int cw, int mx, int my,
                            boolean[] clicked, int accent) {
        rr(ctx, cx, y, cw, 50, 8, ROW_BG);
        ctx.drawText(tr, Text.literal(bs.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        String cnt = bs.ids().size() + " selected";
        ctx.drawText(tr, cnt, cx + cw - 11 - tr.getWidth(cnt), y + 6, accent, true);
        int bx = cx + 11, by = y + 26, bw = cw - 22 - 46;
        rr(ctx, bx, by, bw, 16, 5, searchFocused ? 0xC81D2145 : 0xFF151833);
        String shown = search.isEmpty() && !searchFocused ? "Search all blocks..."
                : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        ctx.drawText(tr, shown, bx + 6, by + 4, search.isEmpty() ? MUTED : ColorUtil.TEXT, false);
        if (clicked[0] && hit(mx, my, bx, by, bw, 16)) searchFocused = true;
        int clx = cx + cw - 11 - 40;
        boolean ch = hit(mx, my, clx, by, 40, 16);
        rr(ctx, clx, by, 40, 16, 5, ch ? ColorUtil.withAlpha(accent, 0xA0) : 0xFF151833);
        ctx.drawText(tr, "Clear", clx + 20 - tr.getWidth("Clear") / 2, by + 4, ColorUtil.TEXT, true);
        if (ch && clicked[0]) bs.clear();
        y += 54;

        java.util.List<String> rows = new java.util.ArrayList<>(bs.ids());
        String[] tokens = search.trim().toLowerCase(Locale.ROOT).split("\\s+");
        if (!search.isBlank()) {
            int added = 0;
            for (String id : allBlocks()) {
                if (bs.has(id)) continue;
                String name = id.substring(id.indexOf(':') + 1).replace('_', ' ');
                boolean all = true;
                for (String t : tokens) if (!name.contains(t)) { all = false; break; }
                if (all && added++ < 60) rows.add(id);
            }
        } else {
            ctx.drawText(tr, "Type to search all " + allBlocks().size() + " blocks. Ticked blocks are listed here.", cx + 4, y, DESC, false);
            y += 13;
        }
        for (String id : rows) {
            boolean on = bs.has(id), h = hit(mx, my, cx, y, cw, 15);
            rr(ctx, cx, y, cw, 15, 5, mix(0x00000000, ROW_HOVER, anim("bp" + id, h ? 1f : 0f)));
            rr(ctx, cx + 8, y + 3, 9, 9, 3, on ? accent : 0xFF2A2F55);
            String name = id.substring(id.indexOf(':') + 1).replace('_', ' ');
            ctx.drawText(tr, name, cx + 23, y + 3, on ? ColorUtil.TEXT : ColorUtil.TEXT_DIM, false);
            if (h && clicked[0]) bs.toggle(id);
            y += 16;
        }
        return y + 2;
    }

    private static String format(double v, Setting.Num n) {
        return n.step >= 1 ? String.valueOf((int) Math.round(v)) : String.format("%.2f", v);
    }

    /** One setting row (height 16) laid out inside [x, x+w). */
    private void drawSetting(DrawContext ctx, TextRenderer tr, Setting s, int x, int w, int y, int mx, int my,
                             boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, x, y, w, 16);
        if (s instanceof Setting.Bool b) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, b.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            sw(ctx, x + w - 26, y + 2, 20, 12, b.get(), accent, b);
            if (hov && clicked[0]) b.toggle();
        } else if (s instanceof Setting.Mode mo) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, mo.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            String v = mo.get();
            ctx.drawText(tr, v, x + w - 6 - tr.getWidth(v), y + 4, accent, true);
            if (hov && clicked[0]) mo.cycle();
        } else if (s instanceof Setting.Num n) {
            int rx = x + 2, rw = w - 4;
            double t = (n.get() - n.min) / (n.max - n.min);
            boolean drag = draggingSlider == n;
            float sh = anim(n, hov || drag ? 1f : 0f);
            if (sh > 0.02f) rr(ctx, x, y, w, 16, 4, ((int) (0x18 * sh)) << 24 | 0xFFFFFF);
            ctx.drawText(tr, n.name, rx + 4, y + 1, ColorUtil.TEXT_DIM, true);
            String val = format(n);
            ctx.drawText(tr, val, rx + rw - 4 - tr.getWidth(val), y + 1, mix(ColorUtil.TEXT_DIM, ColorUtil.TEXT, sh), true);
            int fill = Math.max(2, (int) ((rw - 8) * t));
            rr(ctx, rx + 4, y + 12, rw - 8, 3, 1, 0xFF1A1E3A);
            rr(ctx, rx + 4, y + 12, fill, 3, 1, accent);
            int kr = 3 + (int) (sh * 1.5f);
            rr(ctx, rx + 4 + fill - kr, y + 13 - kr, kr * 2, kr * 2, kr, 0xFFFFFFFF);
            if (hov && clicked[0] && draggingSlider == null) {
                draggingSlider = n;
                sliderX = rx;
                sliderW = rw;
            }
        }
    }

    private static String format(Setting.Num n) {
        return n.step >= 1 ? String.valueOf(n.getInt()) : String.format("%.2f", n.get());
    }

    // -------------------------------------------------------------------------------------------------- keys

    private void handleKeys(long window) {
        boolean closeDown = GLFW.glfwGetKey(window, ModuleManager.GUI_KEY) == GLFW.GLFW_PRESS;
        boolean escDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS;

        if (binding != null) {
            if (escDown && !escWasDown) {
                binding = null;
            } else if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
                binding.setKey(-1);
                binding = null;
            } else {
                for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                    boolean down = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
                    if (down && !keyWasDown[k] && k != GLFW.GLFW_KEY_ESCAPE && k != GLFW.GLFW_KEY_BACKSPACE) {
                        binding.setKey(k);
                        binding = null;
                        break;
                    }
                }
            }
            snapshot(window, closeDown, escDown);
            return;
        }

        if (searchFocused) {
            if (escDown && !escWasDown) searchFocused = false;
            for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_Z; k++) {
                if (edge(window, k)) { search += (char) ('a' + (k - GLFW.GLFW_KEY_A)); scroll = 0; }
            }
            for (int k = GLFW.GLFW_KEY_0; k <= GLFW.GLFW_KEY_9; k++) {
                if (edge(window, k)) { search += (char) ('0' + (k - GLFW.GLFW_KEY_0)); scroll = 0; }
            }
            if (edge(window, GLFW.GLFW_KEY_SPACE) && !search.isEmpty()) search += ' ';
            if (edge(window, GLFW.GLFW_KEY_BACKSPACE) && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                scroll = 0;
            }
        }

        if (closeDown && !closeKeyWasDown) {
            close();
            return;
        }
        snapshot(window, closeDown, escDown);
    }

    private boolean edge(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS && !keyWasDown[key];
    }

    private void snapshot(long window, boolean closeDown, boolean escDown) {
        closeKeyWasDown = closeDown;
        escWasDown = escDown;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            keyWasDown[k] = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
        }
    }
}
