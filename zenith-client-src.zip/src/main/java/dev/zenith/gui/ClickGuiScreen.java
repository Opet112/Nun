package dev.zenith.gui;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.module.ModuleManager;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Category-panel ClickGUI.
 * Left click: toggle module / change setting. Right click: expand settings.
 * Middle click: set keybind (press a key, ESC cancels, Backspace clears).
 *
 * Mouse and keyboard are polled from GLFW every frame instead of overriding the input
 * callbacks, so the screen does not depend on the (frequently changing) input event classes.
 */
public class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 112;
    private static final int HEADER_H = 16;
    private static final int ROW_H = 14;
    private static final int SETTING_H = 12;

    /** Panel positions survive closing/opening the GUI. */
    private static final Map<Category, int[]> POSITIONS = new LinkedHashMap<>();
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final boolean[] mouseDown = new boolean[3];
    private int[] draggingPanel;
    private int dragOffX, dragOffY;
    private Setting.Num draggingSlider;
    private int sliderX, sliderW;
    private Module binding;
    private boolean closeKeyWasDown = true;
    private boolean escWasDown = true;
    private final boolean[] keyWasDown = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public ClickGuiScreen() {
        super(Text.literal("Zenith"));
    }

    @Override
    protected void init() {
        if (!POSITIONS.isEmpty()) return;
        int x = 8, y = 10;
        for (Category c : Category.values()) {
            if (x + PANEL_W > width - 4) { x = 8; y += 190; }
            POSITIONS.put(c, new int[]{x, y});
            x += PANEL_W + 6;
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null; }

    @Override
    public void removed() {
        ZenithClient.config().save();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        long window = mc.getWindow().getHandle();
        TextRenderer tr = mc.textRenderer;

        boolean[] pressed = {
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS
        };
        boolean[] clicked = new boolean[3];
        for (int i = 0; i < 3; i++) {
            clicked[i] = pressed[i] && !mouseDown[i];
            mouseDown[i] = pressed[i];
        }
        if (!pressed[0]) { draggingPanel = null; draggingSlider = null; }

        handleKeys(window);

        // Dragging
        if (draggingPanel != null) {
            draggingPanel[0] = mx - dragOffX;
            draggingPanel[1] = my - dragOffY;
        }
        if (draggingSlider != null) {
            double t = Math.max(0, Math.min(1, (mx - sliderX) / (double) sliderW));
            draggingSlider.set(draggingSlider.min + t * (draggingSlider.max - draggingSlider.min));
        }

        for (Map.Entry<Category, int[]> entry : POSITIONS.entrySet()) {
            drawPanel(ctx, tr, entry.getKey(), entry.getValue(), mx, my, clicked);
        }

        String hint = binding != null
                ? "Press a key for " + binding.name + "  (Esc = cancel, Backspace = clear)"
                : "Left: toggle   Right: settings   Middle: bind   Right Shift / Esc: close";
        ctx.drawText(tr, hint, 6, height - 12, ColorUtil.TEXT_DIM, true);
    }

    private void drawPanel(DrawContext ctx, TextRenderer tr, Category cat, int[] pos, int mx, int my, boolean[] clicked) {
        int x = pos[0], y = pos[1];
        int accent = ColorUtil.accent(cat.ordinal());

        // Header
        ctx.fill(x, y, x + PANEL_W, y + HEADER_H, ColorUtil.PANEL_HEADER);
        ctx.fill(x, y + HEADER_H - 1, x + PANEL_W, y + HEADER_H, accent);
        ctx.drawText(tr, cat.label, x + 6, y + 4, accent, true);
        if (clicked[0] && inside(mx, my, x, y, PANEL_W, HEADER_H) && draggingPanel == null) {
            draggingPanel = pos;
            dragOffX = mx - x;
            dragOffY = my - y;
        }

        int cy = y + HEADER_H;
        for (Module m : ZenithClient.modules().in(cat)) {
            boolean hover = inside(mx, my, x, cy, PANEL_W, ROW_H);
            ctx.fill(x, cy, x + PANEL_W, cy + ROW_H, hover ? ColorUtil.ROW_HOVER : ColorUtil.ROW);
            if (m.isEnabled()) ctx.fill(x, cy, x + 2, cy + ROW_H, accent);

            String label = binding == m ? "Press a key..." : m.name;
            ctx.drawText(tr, label, x + 6, cy + 3, m.isEnabled() ? ColorUtil.TEXT : ColorUtil.TEXT_DIM, true);
            if (!m.getSettings().isEmpty()) {
                String arrow = EXPANDED.contains(m) ? "-" : "+";
                ctx.drawText(tr, arrow, x + PANEL_W - tr.getWidth(arrow) - 5, cy + 3, ColorUtil.TEXT_DIM, true);
            }

            if (hover && clicked[0] && draggingPanel == null) m.toggle();
            if (hover && clicked[1] && !m.getSettings().isEmpty()) {
                if (!EXPANDED.remove(m)) EXPANDED.add(m);
            }
            if (hover && clicked[2]) binding = m;
            cy += ROW_H;

            if (EXPANDED.contains(m)) {
                // keybind row
                drawSettingBackground(ctx, x, cy, mx, my);
                String bind = "Bind: " + KeyUtil.name(m.getKey());
                ctx.drawText(tr, bind, x + 8, cy + 2, ColorUtil.TEXT_DIM, true);
                if (clicked[0] && inside(mx, my, x, cy, PANEL_W, SETTING_H)) binding = m;
                cy += SETTING_H;

                for (Setting s : m.getSettings()) {
                    drawSettingBackground(ctx, x, cy, mx, my);
                    drawSetting(ctx, tr, s, x, cy, mx, my, clicked, accent);
                    cy += SETTING_H;
                }
            }
        }
        ctx.fill(x, cy, x + PANEL_W, cy + 1, accent);
    }

    private void drawSettingBackground(DrawContext ctx, int x, int y, int mx, int my) {
        ctx.fill(x, y, x + PANEL_W, y + SETTING_H, inside(mx, my, x, y, PANEL_W, SETTING_H) ? 0xC01B1F27 : 0xC00E1015);
    }

    private void drawSetting(DrawContext ctx, TextRenderer tr, Setting s, int x, int y, int mx, int my, boolean[] clicked, int accent) {
        boolean hover = inside(mx, my, x, y, PANEL_W, SETTING_H);
        if (s instanceof Setting.Bool b) {
            ctx.drawText(tr, b.name, x + 8, y + 2, ColorUtil.TEXT_DIM, true);
            int bx = x + PANEL_W - 16, by = y + 3;
            ctx.fill(bx, by, bx + 8, by + 6, 0xFF2A2F3A);
            if (b.get()) ctx.fill(bx + 1, by + 1, bx + 7, by + 5, accent);
            if (hover && clicked[0] && draggingPanel == null) b.toggle();
        } else if (s instanceof Setting.Mode mo) {
            ctx.drawText(tr, mo.name, x + 8, y + 2, ColorUtil.TEXT_DIM, true);
            String v = mo.get();
            ctx.drawText(tr, v, x + PANEL_W - tr.getWidth(v) - 6, y + 2, accent, true);
            if (hover && clicked[0] && draggingPanel == null) mo.cycle();
        } else if (s instanceof Setting.Num n) {
            int sx = x + 6, sw = PANEL_W - 12;
            double t = (n.get() - n.min) / (n.max - n.min);
            ctx.fill(sx, y, sx + (int) (sw * t), y + SETTING_H, ColorUtil.withAlpha(accent, 0x55));
            String text = n.name + " " + format(n);
            ctx.drawText(tr, text, x + 8, y + 2, ColorUtil.TEXT, true);
            if (hover && clicked[0] && draggingPanel == null && draggingSlider == null) {
                draggingSlider = n;
                sliderX = sx;
                sliderW = sw;
            }
        }
    }

    private static String format(Setting.Num n) {
        return n.step >= 1 ? String.valueOf(n.getInt()) : String.format("%.2f", n.get());
    }

    private void handleKeys(long window) {
        boolean closeDown = GLFW.glfwGetKey(window, ModuleManager.GUI_KEY) == GLFW.GLFW_PRESS;
        boolean escDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS;

        if (binding != null) {
            if (escDown && !escWasDown) {
                binding = null;
            } else if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
                binding.setKey(-1);
                binding = null;
            } else {
                for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                    boolean down = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
                    if (down && !keyWasDown[k] && k != GLFW.GLFW_KEY_ESCAPE && k != GLFW.GLFW_KEY_BACKSPACE) {
                        binding.setKey(k);
                        binding = null;
                        break;
                    }
                }
            }
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                keyWasDown[k] = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
            }
            closeKeyWasDown = closeDown;
            escWasDown = escDown;
            return;
        }

        if (closeDown && !closeKeyWasDown) {
            close();
            return;
        }
        closeKeyWasDown = closeDown;
        escWasDown = escDown;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            keyWasDown[k] = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
        }
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
