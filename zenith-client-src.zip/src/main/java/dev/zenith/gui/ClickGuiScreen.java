package dev.zenith.gui;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.module.ModuleManager;
import dev.zenith.module.impl.HudModule;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Single-window ClickGUI: category sidebar on the left, module list with search and switches on the right
 * (layout inspired by the "Prestige" style menu).
 *
 * Left click on a switch toggles the module, click on the row body expands its settings, middle click binds a key.
 * Mouse and keyboard are polled from GLFW every frame instead of overriding the input callbacks, so the screen does
 * not depend on the (frequently changing) input event classes. Only the mouse wheel uses a screen callback.
 */
public class ClickGuiScreen extends Screen {
    private static final int SIDE_W = 118;
    private static final int P_SETTINGS = 10, P_THEMES = 11, P_CONFIGS = 12, P_KEYBINDS = 13, P_STATS = 14;
    private static final int ROWH = 30, STEP = 33;
    private static final long START = System.currentTimeMillis();

    private static final int WIN_BG = 0xC80B0C1F;
    private static final int SIDE_BG = 0xD2090A19;
    private static final int ROW_BG = 0xB4151833;
    private static final int ROW_HOVER = 0xC81D2145;
    private static final int SUB_BG = 0xB40C0E22;
    private static final int OFF = 0xFF2A2E4A;
    private static final int MUTED = 0xFF5C6384;
    private static final int DESC = 0xFF6A7194;

    private static int wx = Integer.MIN_VALUE, wy;
    private static int page = 0;
    private static String search = "";
    private static boolean onlyEnabled;
    /** Module whose detail page is open (replaces the module list), or null. */
    private static Module OPEN;

    private final boolean[] mouseDown = new boolean[3];
    private final boolean[] keyWasDown = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private boolean closeKeyWasDown = true;
    private boolean escWasDown = true;

    private int winW, winH;
    private boolean dragWin;
    private int dragOffX, dragOffY;
    private Setting.Num draggingSlider;
    private int sliderX, sliderW;
    private Module binding;
    private boolean searchFocused;
    private double scroll;
    private double pendingScroll;
    private boolean inList;
    private boolean draggingBar;

    private final long openedAt = System.currentTimeMillis();

    public ClickGuiScreen() {
        super(Text.literal("Zenith"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null && !searchFocused; }

    @Override
    public void removed() {
        ZenithClient.config().save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        pendingScroll += verticalAmount;
        return true;
    }

    // ------------------------------------------------------------------------------------------ drawing helpers

    /** Filled rounded rectangle (scan-line corners, no textures). */
    public static void rr(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    private static final java.util.Map<Object, Float> ANIM = new java.util.HashMap<>();

    /** Smoothly chases {@code target}; one value per key, advanced each frame. */
    private static float anim(Object key, float target) {
        float v = ANIM.getOrDefault(key, target);
        v += (target - v) * 0.28f;
        if (Math.abs(target - v) < 0.01f) v = target;
        ANIM.put(key, v);
        return v;
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = 0;
        for (int sh = 24; sh >= 0; sh -= 8) {
            int ca = (a >>> sh) & 0xFF, cb = (b >>> sh) & 0xFF;
            r |= ((int) (ca + (cb - ca) * t) & 0xFF) << sh;
        }
        return r;
    }

    private static void sw(DrawContext ctx, int x, int y, int w, int h, boolean on, int accent, Object key) {
        float t = anim(key, on ? 1f : 0f);
        if (t > 0.05f) rr(ctx, x - 1, y - 1, w + 2, h + 2, (h + 2) / 2, ColorUtil.withAlpha(accent, (int) (0x30 * t))); // glow
        rr(ctx, x, y, w, h, h / 2, mix(OFF, accent, t));
        int k = h - 4;
        int kx = x + 2 + (int) ((w - k - 4) * t);
        rr(ctx, kx, y + 2, k, k, k / 2, mix(0xFF8A90B0, 0xFFFFFFFF, t));
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Hit test that also requires the mouse to be inside the scrolling list. */
    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return inList && inside(mx, my, x, y, w, h);
    }

    private static String pageTitleA(int p) {
        if (!search.isEmpty() && p < 10) return "Search";
        if (p < 10) return p == Category.RENDER.ordinal() ? "Visual" : Category.values()[p].label;
        return switch (p) {
            case P_SETTINGS -> "Settings";
            case P_THEMES -> "Themes";
            case P_STATS -> "Stats";
            case P_CONFIGS -> "Configs";
            default -> "Keybinds";
        };
    }

    private static String pageTitleB(int p) {
        if (!search.isEmpty() && p < 10) return " Results";
        return p < 10 ? " Modules" : "";
    }

    private static String catLabel(Category c) {
        return c == Category.RENDER ? "Visual" : c.label;
    }

    // ------------------------------------------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        long window = mc.getWindow().getHandle();
        TextRenderer tr = mc.textRenderer;

        boolean[] pressed = {
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS
        };
        boolean[] clicked = new boolean[3];
        for (int i = 0; i < 3; i++) {
            clicked[i] = pressed[i] && !mouseDown[i];
            mouseDown[i] = pressed[i];
        }
        if (!pressed[0]) { dragWin = false; draggingSlider = null; }

        handleKeys(window);

        winW = Math.min(width - 16, 520);
        winH = Math.min(height - 16, 290);
        if (wx == Integer.MIN_VALUE) { wx = (width - winW) / 2; wy = (height - winH) / 2; }
        if (dragWin) { wx = mx - dragOffX; wy = my - dragOffY; }
        wx = Math.max(0, Math.min(width - winW, wx));
        wy = Math.max(0, Math.min(height - winH, wy));

        if (draggingSlider != null) {
            double t = Math.max(0, Math.min(1, (mx - sliderX) / (double) sliderW));
            draggingSlider.set(draggingSlider.min + t * (draggingSlider.max - draggingSlider.min));
        }

        int accent = ColorUtil.accent(0);
        float op = Math.min(1f, (System.currentTimeMillis() - openedAt) / 240f);
        op = 1f - (1f - op) * (1f - op) * (1f - op); // ease-out
        int slide = dragWin ? 0 : (int) ((1f - op) * 14);
        ctx.fillGradient(0, 0, width, height, (int) (0x50 * op) << 24, (int) (0x90 * op) << 24); // vignette behind the panel
        wy += slide;
        for (int i = 9; i >= 1; i--) rr(ctx, wx - i, wy - i + 4, winW + 2 * i, winH + 2 * i, 10 + i, ((int) (0x0A * op)) << 24); // soft shadow
        rr(ctx, wx - 1, wy - 1, winW + 2, winH + 2, 11, mix(0x40FFFFFF, ColorUtil.withAlpha(accent, 0x70), 0.5f));
        rr(ctx, wx, wy, winW, winH, 10, WIN_BG);
        ctx.fillGradient(wx + 6, wy + 1, wx + winW - 6, wy + 40, ColorUtil.withAlpha(accent, 0x2A), 0x00000000);
        ctx.fill(wx + 14, wy, wx + winW - 14, wy + 1, ColorUtil.withAlpha(accent, 0xC0));

        drawSidebar(ctx, tr, mx, my, clicked, accent);
        drawContent(ctx, tr, mx, my, clicked, accent);
        wy -= slide;

        String hint = binding != null
                ? "Press a key for " + binding.name + "  (Esc = cancel, Backspace = clear)"
                : "Switch: toggle   Row: settings   Middle click: bind   Right Shift / Esc: close";
        ctx.drawText(tr, hint, wx + 4, wy + winH + 4, ColorUtil.TEXT_DIM, true);
    }

    private void drawSidebar(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int sx = wx + 5, sy = wy + 5, sw = SIDE_W - 5, sh = winH - 10;
        rr(ctx, sx, sy, sw, sh, 9, SIDE_BG);

        // logo block (also the drag handle)
        rr(ctx, sx + 8, sy + 9, 10, 10, 3, accent);
        Text zen = Text.literal("Zenith").styled(s -> s.withBold(true));
        Text cli = Text.literal("Client").styled(s -> s.withItalic(true));
        ctx.drawText(tr, zen, sx + 23, sy + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, cli, sx + 23 + tr.getWidth(zen) + 3, sy + 6, accent, true);
        ctx.drawText(tr, "BUILD 1.0.0", sx + 23, sy + 17, MUTED, false);
        if (clicked[0] && inside(mx, my, sx, sy, sw, 28)) {
            dragWin = true;
            dragOffX = mx - wx;
            dragOffY = my - wy;
        }

        int y = sy + 34;
        ctx.drawText(tr, "MODULES", sx + 10, y, MUTED, false);
        y += 12;
        for (Category c : Category.values()) {
            int count = ZenithClient.modules().in(c).size();
            y = sideItem(ctx, tr, sx, y, sw, catLabel(c), String.valueOf(count), page == c.ordinal(), mx, my, clicked, accent, c.ordinal());
        }
        y += 4;
        ctx.drawText(tr, "GENERAL", sx + 10, y, MUTED, false);
        y += 12;
        y = sideItem(ctx, tr, sx, y, sw, "Settings", "", page == P_SETTINGS, mx, my, clicked, accent, P_SETTINGS);
        y = sideItem(ctx, tr, sx, y, sw, "Stats", "", page == P_STATS, mx, my, clicked, accent, P_STATS);
        y = sideItem(ctx, tr, sx, y, sw, "Themes", "", page == P_THEMES, mx, my, clicked, accent, P_THEMES);
        y = sideItem(ctx, tr, sx, y, sw, "Configs", "", page == P_CONFIGS, mx, my, clicked, accent, P_CONFIGS);
        sideItem(ctx, tr, sx, y, sw, "Keybinds", "", page == P_KEYBINDS, mx, my, clicked, accent, P_KEYBINDS);
    }

    private int sideItem(DrawContext ctx, TextRenderer tr, int sx, int y, int sw, String label, String count,
                         boolean selected, int mx, int my, boolean[] clicked, int accent, int target) {
        boolean hover = inside(mx, my, sx + 4, y, sw - 8, 15);
        float sel = anim("side" + target + "s", selected ? 1f : 0f);
        float hov = anim("side" + target + "h", hover ? 1f : 0f);
        if (hov > 0.02f) rr(ctx, sx + 4, y, sw - 8, 15, 5, ((int) (0x22 * hov)) << 24 | 0xFFFFFF);
        if (sel > 0.02f) {
            rr(ctx, sx + 4, y, sw - 8, 15, 5, ColorUtil.withAlpha(accent, (int) (0x48 * sel)));
            rr(ctx, sx + 4, y + 3, 2, 9, 1, ColorUtil.withAlpha(accent, (int) (0xFF * sel)));
        }
        rr(ctx, sx + 10, y + 5, 5, 5, 2, mix(MUTED, accent, sel));
        ctx.drawText(tr, label, sx + 19 + (int) (2 * sel), y + 4, mix(ColorUtil.TEXT_DIM, ColorUtil.TEXT, sel), true);
        if (!count.isEmpty()) ctx.drawText(tr, count, sx + sw - 10 - tr.getWidth(count), y + 4, MUTED, false);
        if (hover && clicked[0] && !dragWin) {
            if (page != target || OPEN != null) { page = target; scroll = 0; }
            OPEN = null;
            search = "";
            searchFocused = false;
        }
        return y + 16;
    }

    private void drawContent(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int cx = wx + SIDE_W + 8, cw = winW - SIDE_W - 18;
        boolean modulePage = page < 10;

        // title
        boolean detailPage = page < 10 && OPEN != null;
        Text a = Text.literal(detailPage ? OPEN.name : pageTitleA(page)).styled(s -> s.withItalic(true));
        Text b = Text.literal(detailPage ? " Settings" : pageTitleB(page)).styled(s -> s.withBold(true));
        ctx.drawText(tr, a, cx, wy + 12, ColorUtil.TEXT, true);
        ctx.drawText(tr, b, cx + tr.getWidth(a), wy + 12, ColorUtil.TEXT, true);

        java.util.List<Module> list = new java.util.ArrayList<>();
        if (detailPage) {
            ctx.drawText(tr, OPEN.getSettings().size() + " settings · " + OPEN.category.label, cx, wy + 25, MUTED, false);
            int bw = 54, bx = cx + cw - bw, by = wy + 10;
            boolean bh = inside(mx, my, bx, by, bw, 14);
            rr(ctx, bx, by, bw, 14, 6, bh ? ColorUtil.withAlpha(accent, 0xA0) : ROW_BG);
            ctx.drawText(tr, "< Back", bx + bw / 2 - tr.getWidth("< Back") / 2, by + 3, ColorUtil.TEXT, true);
            if (bh && clicked[0]) { OPEN = null; scroll = 0; }
        } else if (modulePage) {
            String q = search.toLowerCase(Locale.ROOT);
            java.util.List<Module> source = q.isEmpty() ? ZenithClient.modules().in(Category.values()[page]) : ZenithClient.modules().all();
            for (Module m : source) {
                if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)
                        && !m.description.toLowerCase(Locale.ROOT).contains(q)) continue;
                list.add(m);
            }
            int on = 0;
            for (Module m : list) if (m.isEnabled()) on++;
            ctx.drawText(tr, list.size() + " modules · " + on + " enabled", cx, wy + 25, MUTED, false);

            // search box
            int bw = Math.min(120, cw / 2), bx = cx + cw - bw, by = wy + 10;
            rr(ctx, bx, by, bw, 14, 6, searchFocused ? 0xC81D2145 : ROW_BG);
            rr(ctx, bx + 5, by + 3, 6, 6, 3, MUTED);          // magnifier
            rr(ctx, bx + 6, by + 4, 4, 4, 2, searchFocused ? 0xFF1D2145 : 0xFF151833);
            ctx.fill(bx + 10, by + 9, bx + 12, by + 11, MUTED);
            String shown = search.isEmpty() && !searchFocused ? "Search modules" : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            ctx.drawText(tr, tr.trimToWidth(shown, bw - 22), bx + 16, by + 3, search.isEmpty() ? MUTED : ColorUtil.TEXT, false);
            if (clicked[0]) searchFocused = inside(mx, my, bx, by, bw, 14);

            // filter tabs
            int tx = cx, ty = wy + 37;
            for (int i = 0; i < 2; i++) {
                String label = i == 0 ? "All" : "Enabled";
                int w = tr.getWidth(label) + 14;
                boolean sel = (i == 1) == onlyEnabled;
                boolean hov = inside(mx, my, tx, ty, w, 12);
                rr(ctx, tx, ty, w, 12, 5, sel ? ColorUtil.withAlpha(accent, 0x55) : hov ? ROW_HOVER : ROW_BG);
                ctx.drawText(tr, label, tx + 7, ty + 2, sel ? ColorUtil.TEXT : ColorUtil.TEXT_DIM, false);
                if (hov && clicked[0]) { onlyEnabled = i == 1; scroll = 0; }
                tx += w + 4;
            }
            if (onlyEnabled) list.removeIf(m -> !m.isEnabled());
        }

        int listTop = wy + (modulePage && !detailPage ? 54 : 36), listBottom = wy + winH - 9;
        inList = inside(mx, my, cx, listTop, cw, listBottom - listTop) && !dragWin;

        scroll -= pendingScroll * 18;
        pendingScroll = 0;

        ctx.enableScissor(cx - 2, listTop, cx + cw + 2, listBottom);
        int start = listTop - (int) scroll;
        int y = start;

        if (detailPage) {
            Module opened = OPEN; // the Back button above may have just closed the page
            if (opened != null) y = detail(ctx, tr, opened, y, cx, cw, mx, my, clicked, accent);
        } else if (modulePage) {
            for (Module m : list) y = moduleRow(ctx, tr, m, y, cx, cw, mx, my, clicked, accent);
        } else if (page == P_SETTINGS) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                for (Setting s : hud.getSettings()) {
                    drawSetting(ctx, tr, s, cx, cw, y, mx, my, clicked, accent);
                    y += 17;
                }
            }
        } else if (page == P_THEMES) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                for (String t : hud.theme.modes) {
                    boolean sel = hud.theme.is(t);
                    boolean hov = hit(mx, my, cx, y, cw, 22);
                    rr(ctx, cx, y, cw, 22, 5, hov ? ROW_HOVER : ROW_BG);
                    rr(ctx, cx + 8, y + 6, 10, 10, 3, themeColor(t));
                    ctx.drawText(tr, t, cx + 24, y + 7, ColorUtil.TEXT, true);
                    if (sel) ctx.drawText(tr, "Selected", cx + cw - 8 - tr.getWidth("Selected"), y + 7, accent, true);
                    if (hov && clicked[0]) {
                        for (int i = 0; i < hud.theme.modes.length && !hud.theme.is(t); i++) hud.theme.cycle();
                    }
                    y += 25;
                }
            }
        } else if (page == P_STATS) {
            long secs = (System.currentTimeMillis() - START) / 1000;
            int enabled = 0;
            for (Module m : ZenithClient.modules().all()) if (m.isEnabled()) enabled++;
            String[][] rows = {
                    {"Session", String.format("%02d:%02d:%02d", secs / 3600, secs / 60 % 60, secs % 60), "Time since the game started."},
                    {"Modules", String.valueOf(ZenithClient.modules().all().size()), "Registered modules."},
                    {"Enabled", String.valueOf(enabled), "Modules currently switched on."},
                    {"FPS", String.valueOf(MinecraftClient.getInstance().getCurrentFps()), "Frames per second."},
            };
            for (String[] r : rows) { simpleRow(ctx, tr, r[0], r[2], r[1], y, cx, cw, mx, my, new boolean[3]); y += STEP; }
        } else if (page == P_CONFIGS) {
            // "+ New" saves the current setup as a named profile; Apply loads it, X deletes it
            if (simpleRow(ctx, tr, "+ New config", "Save your current modules, friends, xray list and waypoints as a new profile.", "Create", y, cx, cw, mx, my, clicked)) {
                int n = 1;
                java.util.List<String> have = ZenithClient.config().profiles();
                while (have.contains("config-" + n)) n++;
                ZenithClient.config().saveProfile("config-" + n);
                ZenithClient.info("Saved config-" + n);
            }
            y += STEP;
            if (simpleRow(ctx, tr, "Default config", "The file loaded automatically at startup (zenith.json).", "Save", y, cx, cw, mx, my, clicked)) {
                ZenithClient.config().save();
                ZenithClient.info("Default config saved.");
            }
            y += STEP;
            for (String prof : ZenithClient.config().profiles()) {
                boolean hov = hit(mx, my, cx, y, cw, ROWH);
                rr(ctx, cx, y, cw, ROWH, 7, hov ? ROW_HOVER : ROW_BG);
                ctx.drawText(tr, Text.literal(prof).styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                ctx.drawText(tr, ZenithClient.config().profileInfo(prof), cx + 11, y + 18, DESC, false);
                int bx = cx + cw - 94, by = y + 7;
                boolean hApply = hit(mx, my, bx, by, 48, 16), hDel = hit(mx, my, bx + 54, by, 32, 16);
                rr(ctx, bx, by, 48, 16, 5, hApply ? ColorUtil.withAlpha(accent, 0xFF) : ColorUtil.withAlpha(accent, 0xC0));
                ctx.drawText(tr, "Apply", bx + 24 - tr.getWidth("Apply") / 2, by + 4, 0xFFFFFFFF, true);
                rr(ctx, bx + 54, by, 32, 16, 5, hDel ? 0xFFB23A4A : 0xFF4A2430);
                ctx.drawText(tr, "Del", bx + 70 - tr.getWidth("Del") / 2, by + 4, 0xFFFFFFFF, true);
                if (clicked[0] && hApply) { ZenithClient.config().loadProfile(prof); ZenithClient.info("Applied " + prof); }
                if (clicked[0] && hDel) { ZenithClient.config().deleteProfile(prof); ZenithClient.info("Deleted " + prof); }
                y += STEP;
            }
        } else {
            for (Module m : ZenithClient.modules().all()) {
                String key = binding == m ? "Press a key..." : KeyUtil.name(m.getKey());
                if (simpleRow(ctx, tr, m.name, m.category.label, key, y, cx, cw, mx, my, clicked)) binding = m;
                y += STEP;
            }
        }
        ctx.disableScissor();

        int total = y - start;
        double max = Math.max(0, total - (listBottom - listTop));
        scroll = Math.max(0, Math.min(max, scroll));
        if (max > 0) { // scroll bar: click the track to jump, drag the handle to scroll
            int trackH = listBottom - listTop;
            int barH = Math.max(18, (int) (trackH * (trackH / (double) total)));
            boolean overTrack = inside(mx, my, cx + cw, listTop, 14, trackH);
            if (clicked[0] && overTrack && !dragWin) draggingBar = true;
            if (!mouseDown[0]) draggingBar = false;
            if (draggingBar) {
                double t = (my - listTop - barH / 2.0) / Math.max(1.0, trackH - barH);
                scroll = Math.max(0, Math.min(max, t * max));
            }
            int barY = listTop + (int) ((trackH - barH) * (scroll / max));
            rr(ctx, cx + cw + 4, listTop, 4, trackH, 2, 0x28FFFFFF); // faint track
            rr(ctx, cx + cw + 4, barY, 4, barH, 2, ColorUtil.withAlpha(accent, draggingBar || overTrack ? 0xFF : 0xB0));
        } else {
            draggingBar = false;
        }
    }

    private static int themeColor(String t) {
        return switch (t) {
            case "Storm" -> 0xFFE9B949;
            case "Cyan" -> 0xFF35D6E8;
            case "Purple" -> 0xFFA66BFF;
            case "Crimson" -> 0xFFE8344F;
            case "Emerald" -> 0xFF2FD27E;
            case "Indigo" -> 0xFF6C63FF;
            default -> ColorUtil.rainbow(0, 0.6f);
        };
    }

    private boolean simpleRow(DrawContext ctx, TextRenderer tr, String title, String desc, String right, int y,
                              int cx, int cw, int mx, int my, boolean[] clicked) {
        boolean hov = hit(mx, my, cx, y, cw, ROWH);
        rr(ctx, cx, y, cw, ROWH, 7, hov ? ROW_HOVER : ROW_BG);
        ctx.drawText(tr, Text.literal(title).styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(desc, cw - 100), cx + 11, y + 18, DESC, false);
        ctx.drawText(tr, right, cx + cw - 11 - tr.getWidth(right), y + 11, ColorUtil.accent(0), true);
        return hov && clicked[0];
    }

    private int moduleRow(DrawContext ctx, TextRenderer tr, Module m, int y, int cx, int cw, int mx, int my,
                          boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, cx, y, cw, ROWH);
        float hv = anim(m, hov ? 1f : 0f);
        float en = anim("en" + m.name, m.isEnabled() ? 1f : 0f);
        rr(ctx, cx, y, cw, ROWH, 7, mix(ROW_BG, ROW_HOVER, hv));
        if (en > 0.02f) {
            rr(ctx, cx, y, cw, ROWH, 7, ColorUtil.withAlpha(accent, (int) (0x1C * en)));
            rr(ctx, cx, y + 6, 3, ROWH - 12, 1, ColorUtil.withAlpha(accent, (int) (0xFF * en)));
        }

        String label = binding == m ? "Press a key..." : m.name;
        ctx.drawText(tr, Text.literal(label).styled(st -> st.withBold(true)), cx + 11, y + 6, mix(0xFFB8BEDD, ColorUtil.TEXT, en), true);
        ctx.drawText(tr, tr.trimToWidth(m.description, cw - 84), cx + 11, y + 18, DESC, false);
        ctx.drawText(tr, ">", cx + cw - 50 + (int) (2 * hv), y + 11, mix(MUTED, ColorUtil.TEXT, hv), false);
        sw(ctx, cx + cw - 36, y + 8, 27, 14, m.isEnabled(), accent, m);

        if (hov && clicked[0]) {
            if (mx >= cx + cw - 40) m.toggle();
            else { OPEN = m; scroll = 0; }
        }
        if (hov && clicked[1]) { OPEN = m; scroll = 0; }
        if (hov && clicked[2]) binding = m;
        y += STEP;

        return y;
    }

    /** Full-size settings page of one module: a tall card per setting with its own controls. */
    private int detail(DrawContext ctx, TextRenderer tr, Module m, int y, int cx, int cw, int mx, int my,
                       boolean[] clicked, int accent) {
        // header: enable switch
        boolean hh = hit(mx, my, cx, y, cw, 34);
        rr(ctx, cx, y, cw, 34, 7, mix(ROW_BG, ROW_HOVER, anim("dh", hh ? 1f : 0f)));
        rr(ctx, cx, y + 7, 3, 20, 1, ColorUtil.withAlpha(accent, m.isEnabled() ? 0xFF : 0x40));
        ctx.drawText(tr, Text.literal(m.name).styled(st -> st.withBold(true)), cx + 11, y + 7, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(m.description, cw - 70), cx + 11, y + 20, DESC, false);
        sw(ctx, cx + cw - 38, y + 10, 28, 14, m.isEnabled(), accent, m);
        if (hh && clicked[0]) m.toggle();
        y += 38;

        // keybind card
        boolean kh = hit(mx, my, cx, y, cw, 30);
        rr(ctx, cx, y, cw, 30, 7, mix(ROW_BG, ROW_HOVER, anim("dk", kh ? 1f : 0f)));
        ctx.drawText(tr, Text.literal("Keybind").styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, "Click, then press a key (Backspace clears)", cx + 11, y + 18, DESC, false);
        String key = binding == m ? "Press a key..." : KeyUtil.name(m.getKey());
        int kw = tr.getWidth(key) + 14;
        rr(ctx, cx + cw - 11 - kw, y + 7, kw, 16, 5, ColorUtil.withAlpha(accent, 0x40));
        ctx.drawText(tr, key, cx + cw - 11 - kw + 7, y + 11, ColorUtil.TEXT, true);
        if (kh && clicked[0]) binding = m;
        y += 34;

        for (Setting st : m.getSettings()) {
            if (st instanceof Setting.Bool b) {
                boolean h = hit(mx, my, cx, y, cw, 30);
                rr(ctx, cx, y, cw, 30, 7, mix(ROW_BG, ROW_HOVER, anim(b, h ? 1f : 0f)));
                ctx.drawText(tr, Text.literal(b.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                ctx.drawText(tr, b.get() ? "Enabled" : "Disabled", cx + 11, y + 18, b.get() ? accent : DESC, false);
                sw(ctx, cx + cw - 38, y + 8, 28, 14, b.get(), accent, b);
                if (h && clicked[0]) b.toggle();
                y += 34;
            } else if (st instanceof Setting.Mode mo) {
                // option chips, wrapped onto as many lines as needed
                int per = cw - 22, lines = 1, lx = 0;
                for (String o : mo.modes) {
                    int w = tr.getWidth(o) + 14;
                    if (lx + w > per && lx > 0) { lines++; lx = 0; }
                    lx += w + 4;
                }
                int h = 26 + lines * 19;
                rr(ctx, cx, y, cw, h, 7, ROW_BG);
                ctx.drawText(tr, Text.literal(mo.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                String cur = mo.get();
                ctx.drawText(tr, cur, cx + cw - 11 - tr.getWidth(cur), y + 6, accent, true);
                int ox = cx + 11, oy = y + 20;
                lx = 0;
                for (String o : mo.modes) {
                    int w = tr.getWidth(o) + 14;
                    if (lx + w > per && lx > 0) { lx = 0; oy += 19; }
                    boolean sel = mo.is(o), oh = hit(mx, my, ox + lx, oy, w, 15);
                    int bg = sel ? ColorUtil.withAlpha(accent, 0xB0) : mix(SUB_BG, ROW_HOVER, anim("o" + mo.name + o, oh ? 1f : 0f));
                    rr(ctx, ox + lx, oy, w, 15, 5, bg);
                    ctx.drawText(tr, o, ox + lx + 7, oy + 3, sel ? 0xFFFFFFFF : ColorUtil.TEXT_DIM, true);
                    if (oh && clicked[0]) for (int i = 0; i < mo.modes.length && !mo.is(o); i++) mo.cycle();
                    lx += w + 4;
                }
                y += h + 4;
            } else if (st instanceof Setting.Num n) {
                boolean h = hit(mx, my, cx, y, cw, 44);
                boolean drag = draggingSlider == n;
                float hv = anim(n, h || drag ? 1f : 0f);
                rr(ctx, cx, y, cw, 44, 7, mix(ROW_BG, ROW_HOVER, hv));
                ctx.drawText(tr, Text.literal(n.name).styled(x -> x.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
                String val = format(n);
                ctx.drawText(tr, val, cx + cw - 11 - tr.getWidth(val), y + 6, accent, true);
                ctx.drawText(tr, format(n.min, n) + " - " + format(n.max, n) + "  ·  step " + (n.step >= 1 ? String.valueOf((int) n.step) : String.valueOf(n.step)),
                        cx + 11, y + 18, DESC, false);
                int tx = cx + 11, tw = cw - 22;
                double t = (n.get() - n.min) / (n.max - n.min);
                int fill = Math.max(2, (int) (tw * t));
                rr(ctx, tx, y + 33, tw, 4, 2, 0xFF1A1E3A);
                rr(ctx, tx, y + 33, fill, 4, 2, accent);
                int kr = 4 + (int) (hv * 2);
                rr(ctx, tx + fill - kr, y + 35 - kr, kr * 2, kr * 2, kr, 0xFFFFFFFF);
                if (h && clicked[0] && draggingSlider == null) { draggingSlider = n; sliderX = tx; sliderW = tw; }
                y += 48;
            }
        }
        return y;
    }

    private static String format(double v, Setting.Num n) {
        return n.step >= 1 ? String.valueOf((int) Math.round(v)) : String.format("%.2f", v);
    }

    /** One setting row (height 16) laid out inside [x, x+w). */
    private void drawSetting(DrawContext ctx, TextRenderer tr, Setting s, int x, int w, int y, int mx, int my,
                             boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, x, y, w, 16);
        if (s instanceof Setting.Bool b) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, b.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            sw(ctx, x + w - 26, y + 2, 20, 12, b.get(), accent, b);
            if (hov && clicked[0]) b.toggle();
        } else if (s instanceof Setting.Mode mo) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, mo.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            String v = mo.get();
            ctx.drawText(tr, v, x + w - 6 - tr.getWidth(v), y + 4, accent, true);
            if (hov && clicked[0]) mo.cycle();
        } else if (s instanceof Setting.Num n) {
            int rx = x + 2, rw = w - 4;
            double t = (n.get() - n.min) / (n.max - n.min);
            boolean drag = draggingSlider == n;
            float sh = anim(n, hov || drag ? 1f : 0f);
            if (sh > 0.02f) rr(ctx, x, y, w, 16, 4, ((int) (0x18 * sh)) << 24 | 0xFFFFFF);
            ctx.drawText(tr, n.name, rx + 4, y + 1, ColorUtil.TEXT_DIM, true);
            String val = format(n);
            ctx.drawText(tr, val, rx + rw - 4 - tr.getWidth(val), y + 1, mix(ColorUtil.TEXT_DIM, ColorUtil.TEXT, sh), true);
            int fill = Math.max(2, (int) ((rw - 8) * t));
            rr(ctx, rx + 4, y + 12, rw - 8, 3, 1, 0xFF1A1E3A);
            rr(ctx, rx + 4, y + 12, fill, 3, 1, accent);
            int kr = 3 + (int) (sh * 1.5f);
            rr(ctx, rx + 4 + fill - kr, y + 13 - kr, kr * 2, kr * 2, kr, 0xFFFFFFFF);
            if (hov && clicked[0] && draggingSlider == null) {
                draggingSlider = n;
                sliderX = rx;
                sliderW = rw;
            }
        }
    }

    private static String format(Setting.Num n) {
        return n.step >= 1 ? String.valueOf(n.getInt()) : String.format("%.2f", n.get());
    }

    // -------------------------------------------------------------------------------------------------- keys

    private void handleKeys(long window) {
        boolean closeDown = GLFW.glfwGetKey(window, ModuleManager.GUI_KEY) == GLFW.GLFW_PRESS;
        boolean escDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS;

        if (binding != null) {
            if (escDown && !escWasDown) {
                binding = null;
            } else if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
                binding.setKey(-1);
                binding = null;
            } else {
                for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                    boolean down = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
                    if (down && !keyWasDown[k] && k != GLFW.GLFW_KEY_ESCAPE && k != GLFW.GLFW_KEY_BACKSPACE) {
                        binding.setKey(k);
                        binding = null;
                        break;
                    }
                }
            }
            snapshot(window, closeDown, escDown);
            return;
        }

        if (searchFocused) {
            if (escDown && !escWasDown) searchFocused = false;
            for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_Z; k++) {
                if (edge(window, k)) { search += (char) ('a' + (k - GLFW.GLFW_KEY_A)); scroll = 0; }
            }
            for (int k = GLFW.GLFW_KEY_0; k <= GLFW.GLFW_KEY_9; k++) {
                if (edge(window, k)) { search += (char) ('0' + (k - GLFW.GLFW_KEY_0)); scroll = 0; }
            }
            if (edge(window, GLFW.GLFW_KEY_SPACE) && !search.isEmpty()) search += ' ';
            if (edge(window, GLFW.GLFW_KEY_BACKSPACE) && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                scroll = 0;
            }
        }

        if (closeDown && !closeKeyWasDown) {
            close();
            return;
        }
        snapshot(window, closeDown, escDown);
    }

    private boolean edge(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS && !keyWasDown[key];
    }

    private void snapshot(long window, boolean closeDown, boolean escDown) {
        closeKeyWasDown = closeDown;
        escWasDown = escDown;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            keyWasDown[k] = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
        }
    }
}
