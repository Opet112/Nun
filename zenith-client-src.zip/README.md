# Zenith (Fabric, Minecraft 1.21.11)

Modüler client: ClickGUI, HUD (watermark / array list / FPS / koordinat), chat komutları, kayıtlı config.

## Derleme
Gereksinim: JDK 21, internet (Fabric Maven).

    gradle wrapper --gradle-version 9.2.1   # bir kerelik (veya IntelliJ ile aç)
    ./gradlew build                          # çıktı: build/libs/zenith-1.0.0.jar

Jar'ı `.minecraft/mods` içine at (Fabric Loader + Fabric API gerekli).
Sürüm numaraları `gradle.properties` içinde; https://fabricmc.net/develop adresinden 1.21.11 için güncel değerleri alabilirsin.

## Kullanım
- **Right Shift**: ClickGUI. Sol tık aç/kapa, sağ tık ayarlar, orta tık keybind (Backspace = temizle).
- Chat komutları (`.` ile başlar, sunucuya gitmez): `.help .list .toggle <modül> .bind <modül> <tuş|none> .friend .panic .spammer .save .load`
- Config: `.minecraft/config/zenith.json`

## Modüller (88)
- **Combat:** KillAura, TriggerBot, AimAssist, AutoClicker, AutoTotem, AutoArmor, AutoWeapon, JumpReset, WTap, Criticals, CrystalAura, AnchorAura, Surround, Velocity*, HitBoxes*
- **Movement:** Sprint, Flight, Speed, Step, Spider, NoFall, Glide, Jesus, Eagle, Parkour, FastLadder, AutoWalk, AutoJump, Sneak, ElytraFly, ElytraSwap, NoSlow*, Timer*, NoJumpDelay*
- **Render:** Fullbright, ESP (glow), Zoom, NoWeather, Radar, TargetHUD, ArmorHUD, Keystrokes, BoxESP, Tracers, NameTags, Freecam*, Xray*
- **Player:** AutoRespawn, AntiAFK, AutoEat, AutoTool, AutoReplenish, AutoLog, AutoFish, FastPlace*, NoBreakDelay*, NoPush*
- **Misc:** Scaffold, ChestStealer, Spammer, PlayerAlert, DeathCoords, Spinbot, InventoryMove, Freeze, HighJump, Blink*, AutoReconnect
- **Client:** HUD

`*` = mixin / paket hook kullanır (`src/main/java/dev/zenith/mixin`). Bir mixin hedefi bu sürümde bulunamazsa
`require = 0` sayesinde oyun çökmez, sadece ilgili modül etkisiz kalır (latest.log'da "Mixin ... failed" satırına bak).

## Freecam / Xray
- **Freecam:** kamerayı karakterden ayırır; karakter yerinde durur (hareket tuşları her tick bırakılır), fare kamerayı döndürür, Sprint = 2x hız.
  Dünyadan çıkınca otomatik kapanır ve açılışta asla "açık" başlamaz.
- **Xray:** Preset = Ores / Valuable / Storage / Netherite / Custom. Custom için `.xray add diamond_ore`, `.xray remove`, `.xray list`.
  Vanilla + Fabric Indigo yolunda `Block.shouldDrawSide` üzerinden, Sodium kuruluysa ayrı bir mixin ile çalışır
  (`zenith.sodium.mixins.json`, sadece Sodium varsa yüklenir). Mağara-occlusion culling kapatıldığı için yer altı chunk'ları da çizilir.
  Sodium'un sıvı (su/lav) çizicisi kapsam dışı: Sodium ile su görünür kalabilir.
- Hook noktaları Meteor Client'ın 1.21.11 dalındaki yaklaşımdan öğrenildi; kod özgün olarak yazıldı (GPL kodu kopyalanmadı).

## Rotasyon / bypass altyapısı
`util/RotationManager`: KillAura ve CrystalAura sunucuya giden rotasyonu kademeli (tick başına en fazla N derece),
fare hassasiyetinin GCD'sine yuvarlanmış şekilde döndürür; kamera hiç oynamaz. Vuruş / kristal kırma sadece sunucunun
bildiği rotasyon hedefin kutusuna bakarken yapılır. Ayrıca şarj eşiği ve CPS rastgele (jitter) seçilir,
kristal yerleştirmede gerçekten görünen yüze tıklanır.

Yeni modül: `module/impl` içine `Module` extend eden bir sınıf yaz, `ModuleManager.init()` içine `register(...)` ekle.

Not: Combat/Movement modülleri çoğu çok oyunculu sunucunun kurallarına aykırıdır; kendi dünyanda/izinli sunucularda kullan.

## Tema
HUD (filigran, modül listesi), ana ekran ve yükleme ekranları şimşek/fırtına temalıdır. HUD modülünde Theme: Storm (varsayılan) veya eski temalar. Yükleme (SplashOverlay) mixin ile, ana ekran/bağlanma ekranları Fabric ScreenEvents ile çizilir.

## Schematic (Printer)
`.minecraft/zenith/schematics` klasörüne .litematic, .schem veya .nbt koy. Oyunda `.schem list`, `.schem load <dosya>`, sonra yapının köşesi olacak yerde `.schem start`. Printer modülü blokları alttan yukarı koyar, eksik blokları envanterden hotbar a alır, envanterde yoksa yakındaki sandık/fıçı/shulker lardan alır ve bloklara kendisi yürür (AFK çalışır). Blok yönleri (merdiven, tabela vb.) korunmaz, sadece blok türü.

Önizleme: `.schem load` sonrası yapının köşesi olacak yerde `.schem here` yaz, blok yerleri ekranda çerçeve olarak görünür (yarı saydam dolgulu, her blok türü ayrı renkte; kırmızı: yerinde başka blok var). `.schem start` o noktadan başlar.

## Yeni (bu sürüm)
- **HUD**: HUD modülünde Style: Modern (varsayılan, tek satır "pill" filigran + renkli modül listesi) veya Classic.
- **Scaffold (legit)**: her blok öncesi eğilir (Sneak on place), bloğun yüzüne bakar (server-side rotasyon insan gibi adım adım döner, hedefe varmadan yerleştirmez), yüzde her seferinde biraz farklı noktayı hedefler, bloklar arası rastgele 1-3 tick bekler.
- **NameTags**: isim, can, mesafe, ping; altında sol el | kask-göğüslük-pantolon-bot | sağ el eşyaları ve dayanıklılık çubuğu.
- **BoxESP**: Corners / Box / Filled stilleri, can barı, isim; oyuncuya çok yaklaşınca kaybolmaz. **ItemESP**, **LogoutSpots**, **Trajectories** eklendi.
- **Printer**: `.schem builtin` ile hazır planlar: starter_base, bunker, wheat_farm, sugarcane_farm, animal_pen, storage_room, nether_portal, lookout_tower, bridge, wall. `.schem builtin <ad>` yükler, `.schem here` / `.schem start` ile kurulur.
- Yeni modüller: AutoTrap, AutoWeb, HoleFill, FastFall, AutoXP, MiddleClick (orta tık: arkadaş ekle / pearl at), Nuker.

## Ana ekran / yükleme
Ana ekran ve yükleme ekranları boyalı fırtına sahnesi (altın ışık, bulutlar, yüzen adalar, tapınak, şimşek) ile çizilir; ana ekran butonları altın çerçeveli, açılış yüklemesinde altın çerçeveli ilerleme çubuğu ve yüzde gösterilir. `ScreenBackgroundMixin` (Screen.renderBackground) ve `SplashOverlayMixin` kullanır; tutmazsa vanilla görünüm kalır.
