package dev.zenith.hud;

import dev.zenith.ZenithClient;
import dev.zenith.module.Module;
import dev.zenith.module.impl.HudModule;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.CpsCounter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Comparator;
import java.util.List;

public final class HudRenderer {
    private HudRenderer() {}

    private static final int PANEL = 0xA00B0E14;
    private static final Map<Module, Float> ANIM = new HashMap<>();

    public static void render(DrawContext ctx) {
        CpsCounter.update();
        MinecraftClient mc = MinecraftClient.getInstance();
        HudModule hud = ZenithClient.modules().get(HudModule.class);
        if (hud == null || !hud.isEnabled() || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        boolean modern = hud.style.is("Modern");

        int y = modern ? renderWatermarkModern(ctx, tr, mc, hud) : renderWatermarkClassic(ctx, tr, hud);

        List<String> lines = new ArrayList<>();
        if (hud.coords.get()) {
            lines.add(String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (hud.speed.get()) lines.add(String.format("%.1f b/s", hud.bps));
        if (hud.direction.get()) {
            String f = mc.player.getHorizontalFacing().asString();
            lines.add(Character.toUpperCase(f.charAt(0)) + f.substring(1));
        }
        if (hud.cps.get()) lines.add(CpsCounter.left() + " | " + CpsCounter.right() + " CPS");
        if (hud.totems.get()) {
            int n = 0;
            for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING)) n += 1;
            if (mc.player.getOffHandStack().isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING)) n++;
            if (n > 0) lines.add(n + (n == 1 ? " totem" : " totems"));
        }
        if (!modern) {
            if (hud.fps.get()) lines.add(0, mc.getCurrentFps() + " FPS");
            if (hud.ping.get() && mc.getNetworkHandler() != null) {
                var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (entry != null) lines.add(entry.getLatency() + " ms");
            }
        }
        for (String line : lines) {
            if (modern) {
                int w = tr.getWidth(line);
                ctx.fill(3, y - 1, 9 + w, y + 10, PANEL);
                ctx.fill(3, y - 1, 5, y + 10, ColorUtil.accent(y / 10));
                ctx.drawText(tr, line, 8, y, ColorUtil.TEXT, true);
                y += 12;
            } else {
                ctx.drawText(tr, line, 4, y, ColorUtil.TEXT, true);
                y += 10;
            }
        }

        if (hud.potions.get()) y = renderEffects(ctx, tr, mc, y + 2, modern);

        if (hud.arrayList.get()) {
            if (modern) renderArrayModern(ctx, tr, mc.getWindow().getScaledWidth());
            else renderArrayClassic(ctx, tr, mc.getWindow().getScaledWidth());
        }

        dev.zenith.module.impl.Printer printer = ZenithClient.modules().get(dev.zenith.module.impl.Printer.class);
        if (printer != null) {
            try { printer.previewRender(ctx); } catch (Throwable t) { /* preview is cosmetic */ }
        }
        for (Module m : ZenithClient.modules().all()) {
            if (!m.isEnabled()) continue;
            try {
                m.onRender(ctx);
            } catch (Throwable t) {
                ZenithClient.LOGGER.error("Module {} failed while rendering and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    /** One pill: gradient client name, then FPS, ping and player name separated by thin bars. */
    private static int renderWatermarkModern(DrawContext ctx, TextRenderer tr, MinecraftClient mc, HudModule hud) {
        if (!hud.watermark.get()) return 4;
        String title = ZenithClient.NAME;
        List<String> parts = new ArrayList<>();
        if (hud.fps.get()) parts.add(mc.getCurrentFps() + " fps");
        if (hud.ping.get() && mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) parts.add(entry.getLatency() + " ms");
        }
        parts.add(mc.player.getName().getString());
        int w = 8 + tr.getWidth(title) + 4;
        for (String p : parts) w += 10 + tr.getWidth(p);
        int x = 4, y = 4, h = 15;
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y + h - 1, x + w, y + h, ColorUtil.accent(0));
        int cx = x + 6;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            ctx.drawText(tr, ch, cx, y + 4, ColorUtil.accent(i), true);
            cx += tr.getWidth(ch);
        }
        cx += 4;
        for (String p : parts) {
            ctx.fill(cx + 3, y + 3, cx + 4, y + h - 4, 0xFF3A4152);
            ctx.drawText(tr, p, cx + 8, y + 4, ColorUtil.TEXT_DIM, true);
            cx += 10 + tr.getWidth(p);
        }
        return y + h + 4;
    }

    private static int renderWatermarkClassic(DrawContext ctx, TextRenderer tr, HudModule hud) {
        if (!hud.watermark.get()) return 4;
        String title = ZenithClient.NAME;
        int accent = ColorUtil.accent(0);
        ctx.fill(2, 2, 8 + tr.getWidth(title) + 4 + tr.getWidth(ZenithClient.VERSION) + 4, 15, 0x90101216);
        ctx.fill(2, 2, 4, 15, accent);
        ctx.drawText(tr, title, 8, 5, accent, true);
        ctx.drawText(tr, ZenithClient.VERSION, 8 + tr.getWidth(title) + 4, 5, ColorUtil.TEXT_DIM, true);
        return 19;
    }

    /** Active status effects under the info lines: name, level and time left, green for good and red for bad ones. */
    private static int renderEffects(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int y, boolean modern) {
        for (var e : mc.player.getStatusEffects()) {
            String name = e.getEffectType().value().getName().getString();
            String time = e.isInfinite() ? "inf" : String.format("%d:%02d", e.getDuration() / 1200, e.getDuration() / 20 % 60);
            String line = name + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "") + "  " + time;
            int col = e.getEffectType().value().isBeneficial() ? 0xFF6FE39A : 0xFFFF6B6B;
            if (modern) {
                ctx.fill(3, y - 1, 9 + tr.getWidth(line), y + 10, PANEL);
                ctx.fill(3, y - 1, 5, y + 10, col);
                ctx.drawText(tr, line, 8, y, col, true);
                y += 12;
            } else {
                ctx.drawText(tr, line, 4, y, col, true);
                y += 10;
            }
        }
        return y;
    }

    private static List<Module> activeModules(TextRenderer tr) {
        List<Module> active = new ArrayList<>();
        for (Module m : ZenithClient.modules().all()) if (m.isEnabled() && m.visible) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(label(m))));
        return active;
    }

    /** Right side list: dark rows, coloured bar on the edge; entries slide and fade in and out. */
    private static void renderArrayModern(DrawContext ctx, TextRenderer tr, int screenWidth) {
        HudModule hud = ZenithClient.modules().get(HudModule.class);
        boolean animate = hud != null && hud.animations.get();
        List<Module> shown = new ArrayList<>();
        for (Module m : ZenithClient.modules().all()) {
            if (!m.visible) continue;
            float a = ANIM.getOrDefault(m, 0f);
            float target = m.isEnabled() ? 1f : 0f;
            a = animate ? a + (target - a) * 0.22f : target;
            if (Math.abs(a - target) < 0.02f) a = target;
            ANIM.put(m, a);
            if (a > 0f) shown.add(m);
        }
        shown.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(label(m))));
        int y = 3, i = 0;
        for (Module m : shown) {
            float a = ANIM.get(m);
            String suffix = m.getSuffix();
            int nameW = tr.getWidth(m.name);
            int w = nameW + (suffix == null ? 0 : tr.getWidth(" " + suffix));
            int slide = (int) ((1f - a) * (w + 14));
            int x = screenWidth - w - 8 + slide;
            int color = ColorUtil.accent(i++);
            int alpha = Math.max(5, (int) (255 * a));
            int rowH = Math.max(1, (int) (12 * a));
            ctx.fill(x - 3, y, screenWidth + slide - 2, y + rowH, ColorUtil.withAlpha(PANEL, (int) (0xA0 * a)));
            ctx.fill(screenWidth - 2 + slide, y, screenWidth + slide, y + rowH, ColorUtil.withAlpha(color, alpha));
            if (a > 0.3f) {
                ctx.drawText(tr, m.name, x, y + 2, ColorUtil.withAlpha(color, alpha), true);
                if (suffix != null) ctx.drawText(tr, " " + suffix, x + nameW, y + 2, ColorUtil.withAlpha(ColorUtil.TEXT_DIM, alpha), true);
            }
            y += rowH;
        }
    }

    private static void renderArrayClassic(DrawContext ctx, TextRenderer tr, int screenWidth) {
        int y = 2, i = 0;
        for (Module m : activeModules(tr)) {
            String text = label(m);
            int w = tr.getWidth(text);
            int x = screenWidth - w - 6;
            int color = ColorUtil.accent(i++);
            ctx.fill(x - 2, y, screenWidth, y + 11, 0x90101216);
            ctx.fill(screenWidth - 2, y, screenWidth, y + 11, color);
            ctx.drawText(tr, text, x, y + 2, color, true);
            y += 11;
        }
    }

    private static String label(Module m) {
        String suffix = m.getSuffix();
        return suffix == null ? m.name : m.name + " " + suffix;
    }
}
