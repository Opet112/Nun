package dev.zenith.hud;

import dev.zenith.ZenithClient;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.ZeusTheme;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.ReconfiguringScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;
import net.minecraft.client.gui.widget.ClickableWidget;

/** Painted storm scene behind the title and loading screens, gold frames on the title buttons. */
public final class ZeusScreens {
    private ZeusScreens() {}

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> titleOverlay(ctx, s));
            }
        });
    }

    private static boolean loading(Screen s) {
        return s instanceof ConnectScreen || s instanceof LevelLoadingScreen
                || s instanceof ReconfiguringScreen || s instanceof ProgressScreen;
    }

    /** Called from ScreenBackgroundMixin after the vanilla background, before the widgets are drawn. */
    public static void background(Screen s, DrawContext ctx) {
        if (s instanceof TitleScreen) ZeusTheme.scene(ctx, s.width, s.height, true);
        else if (loading(s)) ZeusTheme.scene(ctx, s.width, s.height, false);
    }

    private static void titleOverlay(DrawContext ctx, Screen s) {
        for (ClickableWidget b : Screens.getButtons(s)) {
            int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
            DrawUtil.outline(ctx, x, y, x + w - 1, y + h - 1, 0xFFC99A2E);
            ctx.fill(x, y, x + 2, y + 2, 0xFFFFE680);
            ctx.fill(x + w - 2, y, x + w, y + 2, 0xFFFFE680);
            ctx.fill(x, y + h - 2, x + 2, y + h, 0xFFFFE680);
            ctx.fill(x + w - 2, y + h - 2, x + w, y + h, 0xFFFFE680);
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        String tag = ZenithClient.NAME + " Client " + ZenithClient.VERSION;
        ctx.drawText(mc.textRenderer, tag, s.width - mc.textRenderer.getWidth(tag) - 4, s.height - 12, ZeusTheme.GOLD, true);
    }

    /** Start-up loading screen (replaces the Mojang logo). */
    public static void splash(DrawContext ctx, int w, int h, float progress) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ZeusTheme.scene(ctx, w, h, true);
        int bw = Math.min(260, w * 6 / 10);
        ZeusTheme.progressBar(ctx, mc.textRenderer, w / 2, h * 56 / 100, bw, progress, "Yükleniyor...");
        ctx.drawCenteredTextWithShadow(mc.textRenderer, ZenithClient.NAME + " Client", w / 2, h * 38 / 100, ZeusTheme.accent(0));
    }
}
