package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Scans the blocks the server actually sent and only reports ore clusters. Anti-xray plugins scatter single fake
 * ores through hidden stone, so requiring a minimum cluster size filters most of them out.
 */
public class OreFinder extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 24, 8, 48, 4));
    private final Setting.Num minCluster = add(new Setting.Num("Min cluster", 2, 1, 6, 1));
    private final Setting.Bool lowValue = add(new Setting.Bool("Iron/Gold/Lapis", false));

    private final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    private final Setting.Bool nearestLabel = add(new Setting.Bool("Nearest label", true));
    private final Map<Long, Block> next = new HashMap<>();
    private volatile Map<Long, Block> shown = new HashMap<>();
    private int layer;

    public OreFinder() {
        super("OreFinder", "Shows ore clusters through walls; ignores lone (likely fake) ores.", Category.RENDER);
    }

    @Override
    protected void onEnable() { layer = 0; next.clear(); shown = new HashMap<>(); }

    private boolean wanted(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE || b == Blocks.ANCIENT_DEBRIS
                || b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return true;
        if (!lowValue.get()) return false;
        return b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE
                || b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE
                || b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE;
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        int r = range.getInt();
        int px = (int) Math.floor(mc.player.getX()), py = (int) Math.floor(mc.player.getY()), pz = (int) Math.floor(mc.player.getZ());
        int dx = layer - r;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dz = -r; dz <= r; dz++) {
            for (int dy = -r; dy <= r; dy++) {
                m.set(px + dx, py + dy, pz + dz);
                Block b = mc.world.getBlockState(m).getBlock();
                if (wanted(b)) next.put(m.asLong(), b);
            }
        }
        layer++;
        if (layer > r * 2) {
            layer = 0;
            shown = filter(new HashMap<>(next));
            next.clear();
        }
    }

    private Map<Long, Block> filter(Map<Long, Block> all) {
        int min = minCluster.getInt();
        if (min <= 1) return all;
        Map<Long, Block> keep = new HashMap<>();
        Set<Long> seen = new HashSet<>();
        for (Long start : all.keySet()) {
            if (seen.contains(start)) continue;
            Set<Long> group = new HashSet<>();
            ArrayDeque<Long> queue = new ArrayDeque<>();
            queue.add(start);
            seen.add(start);
            while (!queue.isEmpty()) {
                long cur = queue.poll();
                group.add(cur);
                BlockPos p = BlockPos.fromLong(cur);
                for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) for (int z = -1; z <= 1; z++) {
                    long n = BlockPos.asLong(p.getX() + x, p.getY() + y, p.getZ() + z);
                    if (all.containsKey(n) && seen.add(n)) queue.add(n);
                }
            }
            if (group.size() >= min) for (Long g : group) keep.put(g, all.get(g));
        }
        return keep;
    }

    private static int colorOf(Block b) {
        if (b == Blocks.ANCIENT_DEBRIS) return 0xFFB5651D;
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return 0xFF2FD27E;
        if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return 0xFFFFD84A;
        if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return 0xFFD8B08C;
        if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return 0xFF3F6BFF;
        return 0xFF35D6E8; // diamond
    }

    private static String nameOf(Block b) {
        if (b == Blocks.ANCIENT_DEBRIS) return "Debris";
        if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return "Emerald";
        if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return "Gold";
        if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return "Iron";
        if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return "Lapis";
        return "Diamond";
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;
        long nearestKey = 0;
        double nearest = Double.MAX_VALUE;
        for (Map.Entry<Long, Block> e : shown.entrySet()) {
            BlockPos bp = BlockPos.fromLong(e.getKey());
            double d = bp.getSquaredDistance(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            if (d < nearest) { nearest = d; nearestKey = e.getKey(); }
            double[] s = pr.box(new Box(bp));
            if (s == null) continue;
            int color = colorOf(e.getValue());
            if (fill.get()) ctx.fill((int) s[0], (int) s[1], (int) s[2] + 1, (int) s[3] + 1, 0x38000000 | (color & 0xFFFFFF));
            DrawUtil.outline(ctx, (int) s[0], (int) s[1], (int) s[2], (int) s[3], color);
        }
        if (nearestLabel.get() && nearest < Double.MAX_VALUE) {
            BlockPos bp = BlockPos.fromLong(nearestKey);
            double[] s = pr.box(new Box(bp));
            if (s != null) {
                String t = nameOf(shown.get(nearestKey)) + " " + (int) Math.sqrt(nearest) + "m";
                int w = mc.textRenderer.getWidth(t);
                int x = (int) ((s[0] + s[2]) / 2) - w / 2, y = (int) s[1] - 11;
                ctx.fill(x - 2, y - 1, x + w + 2, y + 9, 0x90101216);
                ctx.drawText(mc.textRenderer, t, x, y, colorOf(shown.get(nearestKey)), true);
            }
        }
    }
}
