package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.InventoryUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/** Middle mouse button: on a player it adds/removes a friend, anywhere else it throws an ender pearl. */
public class MiddleClick extends Module {
    private final Setting.Bool friend = add(new Setting.Bool("Friend", true));
    private final Setting.Bool pearl = add(new Setting.Bool("Pearl", true));
    private boolean was;

    public MiddleClick() {
        super("MiddleClick", "Middle click a player to friend them, or to throw an ender pearl.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.getWindow() == null) return;
        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        boolean click = down && !was && mc.currentScreen == null;
        was = down;
        if (!click) return;

        if (friend.get() && mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity other) {
            String name = other.getName().getString().toLowerCase(Locale.ROOT);
            if (ZenithClient.friends().remove(name)) ZenithClient.info("Removed friend " + name);
            else { ZenithClient.friends().add(name); ZenithClient.info("Added friend " + name); }
            ZenithClient.config().save();
            return;
        }
        if (pearl.get() && mc.interactionManager != null) {
            int slot = InventoryUtil.findHotbar(Items.ENDER_PEARL);
            if (slot < 0) return;
            int previous = p.getInventory().getSelectedSlot();
            InventoryUtil.select(slot);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            InventoryUtil.select(previous);
        }
    }
}
