package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.BlockUtil;
import dev.zenith.util.EntityUtil;
import dev.zenith.util.InventoryUtil;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

/** Fills 1x1 holes near you so enemies cannot hide in them. */
public class HoleFill extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 4, 2, 5, 1));
    private final Setting.Bool onlyEnemy = add(new Setting.Bool("Only with enemy near", true));
    private final Setting.Num enemyRange = add(new Setting.Num("Enemy range", 10, 4, 24, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 10, 1));
    private int wait;

    public HoleFill() {
        super("HoleFill", "Fills safe holes (obsidian/bedrock pits) around you.", Category.COMBAT);
    }

    private static boolean solid(Block b) { return b == Blocks.BEDROCK || b == Blocks.OBSIDIAN; }

    private boolean isHole(BlockPos m) {
        int x = m.getX(), y = m.getY(), z = m.getZ();
        if (!mc.world.getBlockState(m).isAir() || !mc.world.getBlockState(new BlockPos(x, y + 1, z)).isAir()) return false;
        return solid(mc.world.getBlockState(new BlockPos(x, y - 1, z)).getBlock())
                && solid(mc.world.getBlockState(new BlockPos(x + 1, y, z)).getBlock())
                && solid(mc.world.getBlockState(new BlockPos(x - 1, y, z)).getBlock())
                && solid(mc.world.getBlockState(new BlockPos(x, y, z + 1)).getBlock())
                && solid(mc.world.getBlockState(new BlockPos(x, y, z - 1)).getBlock());
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;
        if (onlyEnemy.get() && EntityUtil.nearestPlayer(enemyRange.get()) == null) return;
        int slot = InventoryUtil.findHotbar(Items.OBSIDIAN);
        if (slot < 0) slot = InventoryUtil.findHotbar(Items.COBBLESTONE);
        if (slot < 0) return;

        int r = range.getInt();
        int px = (int) Math.floor(p.getX()), py = (int) Math.floor(p.getY()), pz = (int) Math.floor(p.getZ());
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = new BlockPos(px + x, py + y, pz + z);
            if (pos.getX() == px && pos.getZ() == pz) continue; // never fill the hole you are standing in
            double d = x * x + y * y + z * z;
            if (d < bestD && isHole(pos)) { bestD = d; best = pos; }
        }
        if (best == null) return;
        int previous = p.getInventory().getSelectedSlot();
        InventoryUtil.select(slot);
        if (BlockUtil.place(best, Hand.MAIN_HAND, true)) wait = delay.getInt();
        InventoryUtil.select(previous);
    }
}
