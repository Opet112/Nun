package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;

/** Boxes and labels for dropped items (good for spotting death piles and loot). */
public class ItemEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 64, 8, 160, 4));
    private final Setting.Bool names = add(new Setting.Bool("Names", true));

    public ItemEsp() {
        super("ItemESP", "Highlights dropped items through walls.", Category.RENDER);
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        int shown = 0;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity item) || mc.player.distanceTo(e) > range.get()) continue;
            if (++shown > 150) break;
            double[] b = pr.boxClamped(Projector.lerpedBox(e, partial));
            if (b == null) continue;
            int color = ColorUtil.accent(shown);
            DrawUtil.outline(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], color);
            if (names.get()) {
                ItemStack st = item.getStack();
                String text = st.getName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                int w = mc.textRenderer.getWidth(text);
                int x = (int) ((b[0] + b[2]) / 2) - w / 2, y = (int) b[1] - 11;
                ctx.fill(x - 2, y - 1, x + w + 2, y + 9, 0x90101216);
                ctx.drawText(mc.textRenderer, text, x, y, color, true);
            }
        }
    }
}
