package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Predicts the flight path of the bow, crossbow, trident, ender pearl, snowball, egg, XP bottle and potions you hold. */
public class Trajectories extends Module {
    public Trajectories() {
        super("Trajectories", "Shows where thrown items and arrows will land.", Category.RENDER);
    }

    /** {speed, gravity} for the held item, or null. */
    private double[] physics(ItemStack st) {
        var p = mc.player;
        if (st.isOf(Items.BOW)) {
            double f = p.isUsingItem() ? p.getItemUseTime() / 20.0 : 1.0;
            f = Math.min(1.0, (f * f + f * 2.0) / 3.0);
            return f < 0.1 ? null : new double[]{3.0 * f, 0.05};
        }
        if (st.isOf(Items.CROSSBOW)) return new double[]{3.15, 0.05};
        if (st.isOf(Items.TRIDENT)) return new double[]{2.5, 0.05};
        if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) return new double[]{1.5, 0.03};
        if (st.isOf(Items.EXPERIENCE_BOTTLE)) return new double[]{0.7, 0.07};
        if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) return new double[]{0.5, 0.05};
        return null;
    }

    @Override
    public void onRender(DrawContext ctx) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        double[] ph = physics(p.getMainHandStack());
        if (ph == null) ph = physics(p.getOffHandStack());
        if (ph == null) return;
        Projector pr = Projector.create(ZenithClient.partial());
        if (pr == null) return;

        double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
        Vec3d dir = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d vel = dir.multiply(ph[0]);
        Vec3d pos = p.getEyePos().add(0, -0.1, 0);
        double[] last = pr.project(pos);
        int color = ColorUtil.accent(0);
        for (int i = 0; i < 160; i++) {
            Vec3d next = pos.add(vel);
            boolean hit = !mc.world.getBlockState(BlockPos.ofFloored(next.x, next.y, next.z)).isReplaceable();
            double[] s = pr.project(next);
            if (s != null && last != null) DrawUtil.line(ctx, last[0], last[1], s[0], s[1], color, pr.width, pr.height);
            last = s;
            if (hit) {
                if (s != null) ctx.fill((int) s[0] - 2, (int) s[1] - 2, (int) s[0] + 3, (int) s[1] + 3, 0xFFE8344F);
                return;
            }
            pos = next;
            vel = vel.multiply(0.99).add(0, -ph[1], 0);
            if (pos.y < mc.world.getBottomY() - 8) return;
        }
    }
}
