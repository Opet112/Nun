package dev.zenith.gui;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.module.ModuleManager;
import dev.zenith.module.impl.HudModule;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Single-window ClickGUI: category sidebar on the left, module list with search and switches on the right
 * (layout inspired by the "Prestige" style menu).
 *
 * Left click on a switch toggles the module, click on the row body expands its settings, middle click binds a key.
 * Mouse and keyboard are polled from GLFW every frame instead of overriding the input callbacks, so the screen does
 * not depend on the (frequently changing) input event classes. Only the mouse wheel uses a screen callback.
 */
public class ClickGuiScreen extends Screen {
    private static final int SIDE_W = 118;
    private static final int P_SETTINGS = 10, P_THEMES = 11, P_CONFIGS = 12, P_KEYBINDS = 13, P_STATS = 14;
    private static final int ROWH = 30, STEP = 33;
    private static final long START = System.currentTimeMillis();

    private static final int WIN_BG = 0xC80B0C1F;
    private static final int SIDE_BG = 0xD2090A19;
    private static final int ROW_BG = 0xB4151833;
    private static final int ROW_HOVER = 0xC81D2145;
    private static final int SUB_BG = 0xB40C0E22;
    private static final int OFF = 0xFF2A2E4A;
    private static final int MUTED = 0xFF5C6384;
    private static final int DESC = 0xFF6A7194;

    private static int wx = Integer.MIN_VALUE, wy;
    private static int page = 0;
    private static String search = "";
    private static boolean onlyEnabled;
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final boolean[] mouseDown = new boolean[3];
    private final boolean[] keyWasDown = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private boolean closeKeyWasDown = true;
    private boolean escWasDown = true;

    private int winW, winH;
    private boolean dragWin;
    private int dragOffX, dragOffY;
    private Setting.Num draggingSlider;
    private int sliderX, sliderW;
    private Module binding;
    private boolean searchFocused;
    private double scroll;
    private double pendingScroll;
    private boolean inList;

    public ClickGuiScreen() {
        super(Text.literal("Zenith"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null && !searchFocused; }

    @Override
    public void removed() {
        ZenithClient.config().save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        pendingScroll += verticalAmount;
        return true;
    }

    // ------------------------------------------------------------------------------------------ drawing helpers

    /** Filled rounded rectangle (scan-line corners, no textures). */
    static void rr(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    private static void sw(DrawContext ctx, int x, int y, int w, int h, boolean on, int accent) {
        rr(ctx, x, y, w, h, h / 2, on ? accent : OFF);
        int k = h - 2;
        rr(ctx, on ? x + w - k - 1 : x + 1, y + 1, k, k, k / 2, 0xFFFFFFFF);
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Hit test that also requires the mouse to be inside the scrolling list. */
    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return inList && inside(mx, my, x, y, w, h);
    }

    private static String pageTitleA(int p) {
        if (!search.isEmpty() && p < 10) return "Search";
        if (p < 10) return p == Category.RENDER.ordinal() ? "Visual" : Category.values()[p].label;
        return switch (p) {
            case P_SETTINGS -> "Settings";
            case P_THEMES -> "Themes";
            case P_STATS -> "Stats";
            case P_CONFIGS -> "Configs";
            default -> "Keybinds";
        };
    }

    private static String pageTitleB(int p) {
        if (!search.isEmpty() && p < 10) return " Results";
        return p < 10 ? " Modules" : "";
    }

    private static String catLabel(Category c) {
        return c == Category.RENDER ? "Visual" : c.label;
    }

    // ------------------------------------------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        long window = mc.getWindow().getHandle();
        TextRenderer tr = mc.textRenderer;

        boolean[] pressed = {
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS,
                GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS
        };
        boolean[] clicked = new boolean[3];
        for (int i = 0; i < 3; i++) {
            clicked[i] = pressed[i] && !mouseDown[i];
            mouseDown[i] = pressed[i];
        }
        if (!pressed[0]) { dragWin = false; draggingSlider = null; }

        handleKeys(window);

        winW = Math.min(width - 16, 520);
        winH = Math.min(height - 16, 290);
        if (wx == Integer.MIN_VALUE) { wx = (width - winW) / 2; wy = (height - winH) / 2; }
        if (dragWin) { wx = mx - dragOffX; wy = my - dragOffY; }
        wx = Math.max(0, Math.min(width - winW, wx));
        wy = Math.max(0, Math.min(height - winH, wy));

        if (draggingSlider != null) {
            double t = Math.max(0, Math.min(1, (mx - sliderX) / (double) sliderW));
            draggingSlider.set(draggingSlider.min + t * (draggingSlider.max - draggingSlider.min));
        }

        int accent = ColorUtil.accent(0);
        ctx.fill(0, 0, width, height, 0x60000000); // dim the world behind the glass panel
        rr(ctx, wx - 1, wy - 1, winW + 2, winH + 2, 11, 0x30FFFFFF);
        rr(ctx, wx, wy, winW, winH, 10, WIN_BG);

        drawSidebar(ctx, tr, mx, my, clicked, accent);
        drawContent(ctx, tr, mx, my, clicked, accent);

        String hint = binding != null
                ? "Press a key for " + binding.name + "  (Esc = cancel, Backspace = clear)"
                : "Switch: toggle   Row: settings   Middle click: bind   Right Shift / Esc: close";
        ctx.drawText(tr, hint, wx + 4, wy + winH + 4, ColorUtil.TEXT_DIM, true);
    }

    private void drawSidebar(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int sx = wx + 5, sy = wy + 5, sw = SIDE_W - 5, sh = winH - 10;
        rr(ctx, sx, sy, sw, sh, 9, SIDE_BG);

        // logo block (also the drag handle)
        rr(ctx, sx + 8, sy + 9, 10, 10, 3, accent);
        Text zen = Text.literal("Zenith").styled(s -> s.withBold(true));
        Text cli = Text.literal("Client").styled(s -> s.withItalic(true));
        ctx.drawText(tr, zen, sx + 23, sy + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, cli, sx + 23 + tr.getWidth(zen) + 3, sy + 6, accent, true);
        ctx.drawText(tr, "BUILD 1.0.0", sx + 23, sy + 17, MUTED, false);
        if (clicked[0] && inside(mx, my, sx, sy, sw, 28)) {
            dragWin = true;
            dragOffX = mx - wx;
            dragOffY = my - wy;
        }

        int y = sy + 34;
        ctx.drawText(tr, "MODULES", sx + 10, y, MUTED, false);
        y += 12;
        for (Category c : Category.values()) {
            int count = ZenithClient.modules().in(c).size();
            y = sideItem(ctx, tr, sx, y, sw, catLabel(c), String.valueOf(count), page == c.ordinal(), mx, my, clicked, accent, c.ordinal());
        }
        y += 4;
        ctx.drawText(tr, "GENERAL", sx + 10, y, MUTED, false);
        y += 12;
        y = sideItem(ctx, tr, sx, y, sw, "Settings", "", page == P_SETTINGS, mx, my, clicked, accent, P_SETTINGS);
        y = sideItem(ctx, tr, sx, y, sw, "Stats", "", page == P_STATS, mx, my, clicked, accent, P_STATS);
        y = sideItem(ctx, tr, sx, y, sw, "Themes", "", page == P_THEMES, mx, my, clicked, accent, P_THEMES);
        y = sideItem(ctx, tr, sx, y, sw, "Configs", "", page == P_CONFIGS, mx, my, clicked, accent, P_CONFIGS);
        sideItem(ctx, tr, sx, y, sw, "Keybinds", "", page == P_KEYBINDS, mx, my, clicked, accent, P_KEYBINDS);
    }

    private int sideItem(DrawContext ctx, TextRenderer tr, int sx, int y, int sw, String label, String count,
                         boolean selected, int mx, int my, boolean[] clicked, int accent, int target) {
        boolean hover = inside(mx, my, sx + 4, y, sw - 8, 15);
        if (selected) rr(ctx, sx + 4, y, sw - 8, 15, 5, ColorUtil.withAlpha(accent, 0x45));
        else if (hover) rr(ctx, sx + 4, y, sw - 8, 15, 5, 0x20FFFFFF);
        ctx.fill(sx + 10, y + 6, sx + 13, y + 9, selected ? accent : MUTED);
        ctx.drawText(tr, label, sx + 18, y + 4, selected ? ColorUtil.TEXT : ColorUtil.TEXT_DIM, true);
        if (!count.isEmpty()) ctx.drawText(tr, count, sx + sw - 10 - tr.getWidth(count), y + 4, MUTED, false);
        if (hover && clicked[0] && !dragWin) {
            if (page != target) { page = target; scroll = 0; }
            search = "";
            searchFocused = false;
        }
        return y + 16;
    }

    private void drawContent(DrawContext ctx, TextRenderer tr, int mx, int my, boolean[] clicked, int accent) {
        int cx = wx + SIDE_W + 8, cw = winW - SIDE_W - 18;
        boolean modulePage = page < 10;

        // title
        Text a = Text.literal(pageTitleA(page)).styled(s -> s.withItalic(true));
        Text b = Text.literal(pageTitleB(page)).styled(s -> s.withBold(true));
        ctx.drawText(tr, a, cx, wy + 12, ColorUtil.TEXT, true);
        ctx.drawText(tr, b, cx + tr.getWidth(a), wy + 12, ColorUtil.TEXT, true);

        java.util.List<Module> list = new java.util.ArrayList<>();
        if (modulePage) {
            String q = search.toLowerCase(Locale.ROOT);
            java.util.List<Module> source = q.isEmpty() ? ZenithClient.modules().in(Category.values()[page]) : ZenithClient.modules().all();
            for (Module m : source) {
                if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)
                        && !m.description.toLowerCase(Locale.ROOT).contains(q)) continue;
                list.add(m);
            }
            int on = 0;
            for (Module m : list) if (m.isEnabled()) on++;
            ctx.drawText(tr, list.size() + " modules · " + on + " enabled", cx, wy + 25, MUTED, false);

            // search box
            int bw = Math.min(120, cw / 2), bx = cx + cw - bw, by = wy + 10;
            rr(ctx, bx, by, bw, 14, 6, searchFocused ? 0xC81D2145 : ROW_BG);
            rr(ctx, bx + 5, by + 3, 6, 6, 3, MUTED);          // magnifier
            rr(ctx, bx + 6, by + 4, 4, 4, 2, searchFocused ? 0xFF1D2145 : 0xFF151833);
            ctx.fill(bx + 10, by + 9, bx + 12, by + 11, MUTED);
            String shown = search.isEmpty() && !searchFocused ? "Search modules" : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
            ctx.drawText(tr, tr.trimToWidth(shown, bw - 22), bx + 16, by + 3, search.isEmpty() ? MUTED : ColorUtil.TEXT, false);
            if (clicked[0]) searchFocused = inside(mx, my, bx, by, bw, 14);

            // filter tabs
            int tx = cx, ty = wy + 37;
            for (int i = 0; i < 2; i++) {
                String label = i == 0 ? "All" : "Enabled";
                int w = tr.getWidth(label) + 14;
                boolean sel = (i == 1) == onlyEnabled;
                boolean hov = inside(mx, my, tx, ty, w, 12);
                rr(ctx, tx, ty, w, 12, 5, sel ? ColorUtil.withAlpha(accent, 0x55) : hov ? ROW_HOVER : ROW_BG);
                ctx.drawText(tr, label, tx + 7, ty + 2, sel ? ColorUtil.TEXT : ColorUtil.TEXT_DIM, false);
                if (hov && clicked[0]) { onlyEnabled = i == 1; scroll = 0; }
                tx += w + 4;
            }
            if (onlyEnabled) list.removeIf(m -> !m.isEnabled());
        }

        int listTop = wy + (modulePage ? 54 : 32), listBottom = wy + winH - 9;
        inList = inside(mx, my, cx, listTop, cw, listBottom - listTop) && !dragWin;

        scroll -= pendingScroll * 18;
        pendingScroll = 0;

        ctx.enableScissor(cx - 2, listTop, cx + cw + 2, listBottom);
        int start = listTop - (int) scroll;
        int y = start;

        if (modulePage) {
            for (Module m : list) y = moduleRow(ctx, tr, m, y, cx, cw, mx, my, clicked, accent);
        } else if (page == P_SETTINGS) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                for (Setting s : hud.getSettings()) {
                    drawSetting(ctx, tr, s, cx, cw, y, mx, my, clicked, accent);
                    y += 17;
                }
            }
        } else if (page == P_THEMES) {
            HudModule hud = ZenithClient.modules().get(HudModule.class);
            if (hud != null) {
                for (String t : hud.theme.modes) {
                    boolean sel = hud.theme.is(t);
                    boolean hov = hit(mx, my, cx, y, cw, 22);
                    rr(ctx, cx, y, cw, 22, 5, hov ? ROW_HOVER : ROW_BG);
                    rr(ctx, cx + 8, y + 6, 10, 10, 3, themeColor(t));
                    ctx.drawText(tr, t, cx + 24, y + 7, ColorUtil.TEXT, true);
                    if (sel) ctx.drawText(tr, "Selected", cx + cw - 8 - tr.getWidth("Selected"), y + 7, accent, true);
                    if (hov && clicked[0]) {
                        for (int i = 0; i < hud.theme.modes.length && !hud.theme.is(t); i++) hud.theme.cycle();
                    }
                    y += 25;
                }
            }
        } else if (page == P_STATS) {
            long secs = (System.currentTimeMillis() - START) / 1000;
            int enabled = 0;
            for (Module m : ZenithClient.modules().all()) if (m.isEnabled()) enabled++;
            String[][] rows = {
                    {"Session", String.format("%02d:%02d:%02d", secs / 3600, secs / 60 % 60, secs % 60), "Time since the game started."},
                    {"Modules", String.valueOf(ZenithClient.modules().all().size()), "Registered modules."},
                    {"Enabled", String.valueOf(enabled), "Modules currently switched on."},
                    {"FPS", String.valueOf(MinecraftClient.getInstance().getCurrentFps()), "Frames per second."},
            };
            for (String[] r : rows) { simpleRow(ctx, tr, r[0], r[2], r[1], y, cx, cw, mx, my, new boolean[3]); y += STEP; }
        } else if (page == P_CONFIGS) {
            if (simpleRow(ctx, tr, "Save config", "Write all module settings, friends, xray list and waypoints to disk.", "Save", y, cx, cw, mx, my, clicked)) {
                ZenithClient.config().save();
                ZenithClient.info("Config saved.");
            }
            y += STEP;
            if (simpleRow(ctx, tr, "Load config", "Reload everything from the saved file.", "Load", y, cx, cw, mx, my, clicked)) {
                ZenithClient.config().load();
                ZenithClient.info("Config loaded.");
            }
            y += STEP;
        } else {
            for (Module m : ZenithClient.modules().all()) {
                String key = binding == m ? "Press a key..." : KeyUtil.name(m.getKey());
                if (simpleRow(ctx, tr, m.name, m.category.label, key, y, cx, cw, mx, my, clicked)) binding = m;
                y += STEP;
            }
        }
        ctx.disableScissor();

        int total = y - start;
        double max = Math.max(0, total - (listBottom - listTop));
        scroll = Math.max(0, Math.min(max, scroll));
        if (max > 0) { // slim scroll bar
            int barH = Math.max(14, (int) ((listBottom - listTop) * ((listBottom - listTop) / (double) total)));
            int barY = listTop + (int) ((listBottom - listTop - barH) * (scroll / max));
            rr(ctx, cx + cw + 3, barY, 2, barH, 1, ColorUtil.withAlpha(accent, 0x90));
        }
    }

    private static int themeColor(String t) {
        return switch (t) {
            case "Storm" -> 0xFFE9B949;
            case "Cyan" -> 0xFF35D6E8;
            case "Purple" -> 0xFFA66BFF;
            case "Crimson" -> 0xFFE8344F;
            case "Emerald" -> 0xFF2FD27E;
            case "Indigo" -> 0xFF6C63FF;
            default -> ColorUtil.rainbow(0, 0.6f);
        };
    }

    private boolean simpleRow(DrawContext ctx, TextRenderer tr, String title, String desc, String right, int y,
                              int cx, int cw, int mx, int my, boolean[] clicked) {
        boolean hov = hit(mx, my, cx, y, cw, ROWH);
        rr(ctx, cx, y, cw, ROWH, 7, hov ? ROW_HOVER : ROW_BG);
        ctx.drawText(tr, Text.literal(title).styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(desc, cw - 100), cx + 11, y + 18, DESC, false);
        ctx.drawText(tr, right, cx + cw - 11 - tr.getWidth(right), y + 11, ColorUtil.accent(0), true);
        return hov && clicked[0];
    }

    private int moduleRow(DrawContext ctx, TextRenderer tr, Module m, int y, int cx, int cw, int mx, int my,
                          boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, cx, y, cw, ROWH);
        boolean exp = EXPANDED.contains(m);
        rr(ctx, cx, y, cw, ROWH, 7, hov ? ROW_HOVER : ROW_BG);
        if (m.isEnabled()) rr(ctx, cx, y + 7, 2, 16, 1, accent);

        String label = binding == m ? "Press a key..." : m.name;
        ctx.drawText(tr, Text.literal(label).styled(st -> st.withBold(true)), cx + 11, y + 6, ColorUtil.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(m.description, cw - 84), cx + 11, y + 18, DESC, false);
        ctx.drawText(tr, exp ? "v" : ">", cx + cw - 50, y + 11, ColorUtil.TEXT_DIM, false);
        sw(ctx, cx + cw - 33, y + 9, 24, 12, m.isEnabled(), accent);

        if (hov && clicked[0]) {
            if (mx >= cx + cw - 40) m.toggle();
            else if (!EXPANDED.remove(m)) EXPANDED.add(m);
        }
        if (hov && clicked[1] && !EXPANDED.remove(m)) EXPANDED.add(m);
        if (hov && clicked[2]) binding = m;
        y += STEP;

        if (exp) {
            int rows = m.getSettings().size() + 1;
            int h = rows * 17 + 6;
            rr(ctx, cx + 5, y - 2, cw - 10, h, 5, SUB_BG);
            int ry = y + 1;
            // keybind row
            boolean bhov = hit(mx, my, cx + 5, ry, cw - 10, 16);
            if (bhov) rr(ctx, cx + 8, ry, cw - 16, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, "Keybind", cx + 14, ry + 4, ColorUtil.TEXT_DIM, true);
            String key = KeyUtil.name(m.getKey());
            ctx.drawText(tr, key, cx + cw - 14 - tr.getWidth(key), ry + 4, accent, true);
            if (bhov && clicked[0]) binding = m;
            ry += 17;
            for (Setting s : m.getSettings()) {
                drawSetting(ctx, tr, s, cx + 8, cw - 16, ry, mx, my, clicked, accent);
                ry += 17;
            }
            y += h + 1;
        }
        return y;
    }

    /** One setting row (height 16) laid out inside [x, x+w). */
    private void drawSetting(DrawContext ctx, TextRenderer tr, Setting s, int x, int w, int y, int mx, int my,
                             boolean[] clicked, int accent) {
        boolean hov = hit(mx, my, x, y, w, 16);
        if (s instanceof Setting.Bool b) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, b.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            sw(ctx, x + w - 24, y + 3, 18, 10, b.get(), accent);
            if (hov && clicked[0]) b.toggle();
        } else if (s instanceof Setting.Mode mo) {
            if (hov) rr(ctx, x, y, w, 16, 4, 0x18FFFFFF);
            ctx.drawText(tr, mo.name, x + 6, y + 4, ColorUtil.TEXT_DIM, true);
            String v = mo.get();
            ctx.drawText(tr, v, x + w - 6 - tr.getWidth(v), y + 4, accent, true);
            if (hov && clicked[0]) mo.cycle();
        } else if (s instanceof Setting.Num n) {
            int rx = x + 2, rw = w - 4;
            double t = (n.get() - n.min) / (n.max - n.min);
            rr(ctx, rx, y + 1, rw, 14, 4, 0xFF1A1E3A);
            rr(ctx, rx, y + 1, Math.max(6, (int) (rw * t)), 14, 4, ColorUtil.withAlpha(accent, 0x90));
            ctx.drawText(tr, n.name, rx + 5, y + 4, ColorUtil.TEXT, true);
            String val = format(n);
            ctx.drawText(tr, val, rx + rw - 5 - tr.getWidth(val), y + 4, ColorUtil.TEXT, true);
            if (hov && clicked[0] && draggingSlider == null) {
                draggingSlider = n;
                sliderX = rx;
                sliderW = rw;
            }
        }
    }

    private static String format(Setting.Num n) {
        return n.step >= 1 ? String.valueOf(n.getInt()) : String.format("%.2f", n.get());
    }

    // -------------------------------------------------------------------------------------------------- keys

    private void handleKeys(long window) {
        boolean closeDown = GLFW.glfwGetKey(window, ModuleManager.GUI_KEY) == GLFW.GLFW_PRESS;
        boolean escDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS;

        if (binding != null) {
            if (escDown && !escWasDown) {
                binding = null;
            } else if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
                binding.setKey(-1);
                binding = null;
            } else {
                for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                    boolean down = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
                    if (down && !keyWasDown[k] && k != GLFW.GLFW_KEY_ESCAPE && k != GLFW.GLFW_KEY_BACKSPACE) {
                        binding.setKey(k);
                        binding = null;
                        break;
                    }
                }
            }
            snapshot(window, closeDown, escDown);
            return;
        }

        if (searchFocused) {
            if (escDown && !escWasDown) searchFocused = false;
            for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_Z; k++) {
                if (edge(window, k)) { search += (char) ('a' + (k - GLFW.GLFW_KEY_A)); scroll = 0; }
            }
            for (int k = GLFW.GLFW_KEY_0; k <= GLFW.GLFW_KEY_9; k++) {
                if (edge(window, k)) { search += (char) ('0' + (k - GLFW.GLFW_KEY_0)); scroll = 0; }
            }
            if (edge(window, GLFW.GLFW_KEY_SPACE) && !search.isEmpty()) search += ' ';
            if (edge(window, GLFW.GLFW_KEY_BACKSPACE) && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                scroll = 0;
            }
        }

        if (closeDown && !closeKeyWasDown) {
            close();
            return;
        }
        snapshot(window, closeDown, escDown);
    }

    private boolean edge(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS && !keyWasDown[key];
    }

    private void snapshot(long window, boolean closeDown, boolean escDown) {
        closeKeyWasDown = closeDown;
        escWasDown = escDown;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            keyWasDown[k] = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
        }
    }
}
